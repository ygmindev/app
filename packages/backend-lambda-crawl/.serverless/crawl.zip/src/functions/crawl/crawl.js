"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/crawl/crawl.ts
var crawl_exports = {};
__export(crawl_exports, {
  main: () => main
});
module.exports = __toCommonJS(crawl_exports);

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var import_server = require("@apollo/server");
var import_aws_lambda = require("@as-integrations/aws-lambda");
var import_client_apigatewaymanagementapi = require("@aws-sdk/client-apigatewaymanagementapi");

// ../../node_modules/.pnpm/tslib@2.6.2/node_modules/tslib/tslib.es6.mjs
function __decorate(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
    r = Reflect.decorate(decorators, target, key, desc);
  else
    for (var i = decorators.length - 1; i >= 0; i--)
      if (d = decorators[i])
        r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
__name(__decorate, "__decorate");

// ../lib-backend/src/auth/utils/JwtImplementation/_JwtImplementation.ts
var import_firebase_admin = __toESM(require("firebase-admin"));
var import_toString = __toESM(require("lodash/toString"));

// ../lib-shared/src/user/resources/User/User.constants.ts
var USER_RESOURCE_NAME = "User";

// ../lib-shared/src/auth/resources/SignIn/SignIn.constants.ts
var SIGN_IN_RESOURCE_NAME = "SignIn";
var SIGN_IN_USER = `${SIGN_IN_RESOURCE_NAME}${USER_RESOURCE_NAME}`;
var SIGN_IN_USERNAME = `${SIGN_IN_RESOURCE_NAME}Username`;
var SIGN_IN_TOKEN_CLAIM_KEYS = [
  "email",
  "phone",
  "first",
  "last"
];

// ../lib-shared/src/core/utils/pick/_pick.ts
var import_pick = __toESM(require("lodash/pick"));
var _pick = /* @__PURE__ */ __name((...[value, keys]) => (0, import_pick.default)(value, keys), "_pick");

// ../lib-shared/src/core/utils/pick/pick.ts
var pick2 = /* @__PURE__ */ __name((...params) => _pick(...params), "pick");

// ../lib-backend/src/auth/utils/JwtImplementation/_JwtImplementation.ts
var _JwtImplementation = class {
  static {
    __name(this, "_JwtImplementation");
  }
  constructor() {
    !import_firebase_admin.default.apps.length && import_firebase_admin.default.initializeApp({
      credential: import_firebase_admin.default.credential.cert({
        clientEmail: process.env.SERVER_FIREBASE_ADMIN_EMAIL,
        privateKey: process.env.SERVER_FIREBASE_ADMIN_SECRET.replace(/\\n/gm, "\n"),
        projectId: process.env.SERVER_FIREBASE_ADMIN_PROJECT_ID
      })
    });
  }
  createToken = async (_id, claims) => import_firebase_admin.default.auth().createCustomToken((0, import_toString.default)(_id), claims);
  verifyToken = async (token) => {
    const decoded = await import_firebase_admin.default.auth().verifyIdToken(token);
    return {
      _id: decoded.uid,
      claims: {
        ...decoded.additionalClaims ?? {},
        ...pick2(decoded, SIGN_IN_TOKEN_CLAIM_KEYS)
      }
    };
  };
};

// ../lib-backend/src/core/utils/Container/_Container.ts
var import_reflect_metadata = require("reflect-metadata");
var import_inversify = require("inversify");
var import_isFunction = __toESM(require("lodash/isFunction"));
var container = new import_inversify.Container({
  autoBindInjectable: true,
  defaultScope: "Singleton",
  skipBaseClassChecks: true
});
var _Container = {
  get: (type, name) => name ? container.getNamed(type, name) : container.get(type),
  set: (type, value, name) => {
    const valueF = (0, import_isFunction.default)(value) ? container.bind(type).to(value) : container.bind(type).toDynamicValue(() => value);
    name && valueF.whenTargetNamed(name);
  }
};

// ../lib-backend/src/core/utils/withContainer/_withContainer.ts
var import_inversify2 = require("inversify");
var _withContainer = import_inversify2.injectable;

// ../lib-backend/src/core/utils/withContainer/withContainer.ts
var withContainer = /* @__PURE__ */ __name(({ name } = {}) => (target) => {
  _withContainer()(target);
  name && _Container.set(name, target);
  return target;
}, "withContainer");

// ../lib-backend/src/auth/utils/JwtImplementation/JwtImplementation.ts
var JwtImplementation = class JwtImplementation2 extends _JwtImplementation {
  static {
    __name(this, "JwtImplementation");
  }
};
JwtImplementation = __decorate([
  withContainer()
], JwtImplementation);

// ../lib-backend/src/auth/utils/getUserFromHeader/getUserFromHeader.ts
var getUserFromHeader = /* @__PURE__ */ __name(async (params) => {
  if (params) {
    const [, token] = params.split(" ");
    return token && token !== "null" ? _Container.get(JwtImplementation).verifyToken(token) : null;
  }
  return null;
}, "getUserFromHeader");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.constants.ts
var CLEAN_OBJECT_KEYS = ["toJSON"];

// ../lib-shared/src/core/utils/filterNil/filterNil.ts
var filterNil = /* @__PURE__ */ __name((params) => params?.filter(Boolean), "filterNil");

// ../lib-shared/src/core/utils/isPrimitive/isPrimitive.ts
var isPrimitive = /* @__PURE__ */ __name((params) => params !== Object(params) || params instanceof Date, "isPrimitive");

// ../lib-shared/src/core/utils/toPlainObject/_toPlainObject.ts
var import_toPlainObject = __toESM(require("lodash/toPlainObject"));
var _toPlainObject = /* @__PURE__ */ __name((params) => (0, import_toPlainObject.default)(params), "_toPlainObject");

// ../lib-shared/src/core/utils/toPlainObject/toPlainObject.ts
var toPlainObject2 = /* @__PURE__ */ __name((params) => _toPlainObject(params), "toPlainObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.base.ts
var import_every = __toESM(require("lodash/every"));
var import_isArray = __toESM(require("lodash/isArray"));
var import_isObject = __toESM(require("lodash/isObject"));
var cleanObject = /* @__PURE__ */ __name((...[value, options, depth = 0]) => {
  if (isPrimitive(value)) {
    return value;
  }
  if ((0, import_isArray.default)(value)) {
    return filterNil(value.map((vv) => cleanObject(vv, options, depth)));
  }
  if ((0, import_isObject.default)(value) && (!options?.primitiveTypes || (0, import_every.default)(options?.primitiveTypes, (type) => !(value instanceof type)))) {
    const valueF = options?.objectTransformer ? options.objectTransformer(value, depth) : toPlainObject2(value);
    Object.keys(valueF).forEach((k) => {
      let v2 = valueF[k];
      v2 = options?.keyValueTransformer ? options.keyValueTransformer(v2, k, depth) : v2;
      if (CLEAN_OBJECT_KEYS.includes(k) || v2 === void 0) {
        delete valueF[k];
      } else {
        valueF[k] = cleanObject(v2, options, depth + 1);
      }
    });
    return valueF;
  }
  return value;
}, "cleanObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.ts
var import_toPlainObject4 = __toESM(require("lodash/toPlainObject"));
var import_mongodb = require("mongodb");
var cleanObject2 = /* @__PURE__ */ __name((...[value, options, depth]) => cleanObject(
  value,
  {
    ...options,
    objectTransformer: (v2) => {
      const { beforeCreate } = v2;
      beforeCreate && void beforeCreate.bind(v2)();
      return (0, import_toPlainObject4.default)(v2);
    },
    primitiveTypes: [...options?.primitiveTypes ?? [], import_mongodb.ObjectId]
  },
  depth
), "cleanObject");

// ../lib-backend/src/database/utils/cleanDocument/cleanDocument.ts
var import_isArray2 = __toESM(require("lodash/isArray"));
var import_isEqual = __toESM(require("lodash/isEqual"));
var import_isPlainObject = __toESM(require("lodash/isPlainObject"));
var import_isString = __toESM(require("lodash/isString"));
var import_last = __toESM(require("lodash/last"));
var import_reduce = __toESM(require("lodash/reduce"));
var import_mongodb2 = require("mongodb");
var resolveObjectId = /* @__PURE__ */ __name((value) => (0, import_isString.default)(value) ? new import_mongodb2.ObjectId(value) : (0, import_isPlainObject.default)(value) ? (0, import_reduce.default)(value, (result2, v2, k) => ({ ...result2, [k]: resolveObjectId(v2) }), {}) : value, "resolveObjectId");
var cleanDocument = /* @__PURE__ */ __name((value) => cleanObject2(value, {
  keyValueTransformer: (v2, k, depth) => {
    let vF = v2;
    if (vF.entity) {
      vF = vF.entity;
    }
    return depth === 0 && (0, import_isPlainObject.default)(vF) && (0, import_isEqual.default)(Object.keys(vF), ["_id"]) ? resolveObjectId(vF._id) : (0, import_isString.default)(vF) && (0, import_last.default)(k.split("."))?.startsWith("_") ? (0, import_isArray2.default)(vF) ? vF.map(resolveObjectId) : new import_mongodb2.ObjectId(vF) : vF;
  }
}), "cleanDocument");

// ../lib-backend/src/database/utils/getConnection/getConnection.ts
var import_graphql_relay = require("graphql-relay");
var getConnection = /* @__PURE__ */ __name(async ({
  count: count2,
  getMany,
  input = {},
  pagination = {}
}) => {
  const { after, before, first, last: last3 } = pagination;
  const beforeOffset = (0, import_graphql_relay.getOffsetWithDefault)(before, count2);
  const afterOffset = (0, import_graphql_relay.getOffsetWithDefault)(after, -1);
  let startOffset = Math.max(-1, afterOffset) + 1;
  let endOffset = Math.min(beforeOffset, count2);
  first && (endOffset = Math.min(endOffset, startOffset + first));
  last3 && (startOffset = Math.max(startOffset, endOffset - last3));
  const skip = Math.max(startOffset, 0);
  const take = Math.max(endOffset - startOffset, 1);
  const { result: result2, root: root2 } = await getMany({ ...input, options: { skip, take } });
  if (result2 && result2.length) {
    const edges = result2.map((node, index) => ({
      cursor: (0, import_graphql_relay.offsetToCursor)(startOffset + index),
      node
    }));
    const { 0: firstEdge, length, [length - 1]: lastEdge } = edges;
    const lowerBound = after ? afterOffset + 1 : 0;
    const upperBound = before ? Math.min(beforeOffset, count2) : count2;
    const pageInfo = {
      endCursor: lastEdge.cursor,
      hasNextPage: first ? endOffset < upperBound : false,
      hasPreviousPage: last3 ? startOffset > lowerBound : false,
      startCursor: firstEdge.cursor
    };
    return { result: { edges, pageInfo }, root: root2 };
  }
  return {
    result: {
      edges: [],
      pageInfo: { endCursor: "", hasNextPage: false, hasPreviousPage: false, startCursor: "" }
    },
    root: root2
  };
}, "getConnection");

// ../lib-shared/src/core/utils/slug/slug.ts
var slug = /* @__PURE__ */ __name((params) => params.normalize("NFKD").replace(/(.+)([A-Z])/g, "$1-$2").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^(\w|?)-]+/g, "").replace(/_/g, "-").replace(/--+/g, "-").replace(/-$/g, ""), "slug");

// ../lib-frontend/src/route/utils/trimPathname/trimPathname.ts
var import_trim = __toESM(require("lodash/trim"));
var trimPathname = /* @__PURE__ */ __name((value) => {
  const pathname = filterNil(value.split("/")).map((char) => (0, import_trim.default)(char, "/").replace(/\w\S*/g, slug)).join("/");
  return `/${(0, import_trim.default)(pathname, "/")}`;
}, "trimPathname");

// ../lib-shared/src/http/utils/uri/uri.ts
var uri = /* @__PURE__ */ __name(({
  host = "",
  isProtocol = true,
  params,
  pathname,
  port
}) => {
  let uri2 = `${host}${port ? `:${port}` : ""}${pathname ? trimPathname(pathname) : ""}`;
  if (params) {
    const queryParams = Object.entries(params).map(([k, v2]) => `${encodeURIComponent(k)}=${encodeURIComponent(v2)}`).join("&");
    uri2 = `${uri2}?${queryParams}`;
  }
  !isProtocol && ([, uri2] = uri2.split("://"));
  return uri2;
}, "uri");

// ../lib-shared/src/http/http.constants.ts
var HTTP_STATUS_CODE = {
  BAD_REQUEST: 400,
  CONFLICT: 409,
  FORBIDDEN: 403,
  GATEWAY_TIMEOUT: 504,
  INTERNAL_SERVER_ERROR: 500,
  NETWORK_CONNECT_TIMEOUT: 599,
  SERVICE_UNAVAILABLE: 503,
  SUCCESS: 200,
  UNAUTHORIZED: 401
};
var APP_URI = uri({ host: process.env.APP_HOST, port: process.env.APP_PORT });
var SERVER_APP_URI = uri({
  host: process.env.SERVER_APP_HOST,
  port: process.env.SERVER_APP_PORT
});

// ../lib-shared/src/http/errors/HttpError/HttpError.ts
var HttpError = class _HttpError extends Error {
  static {
    __name(this, "HttpError");
  }
  statusCode;
  constructor(statusCode, message, stack) {
    super();
    Object.setPrototypeOf(this, _HttpError.prototype);
    this.statusCode = statusCode ?? HTTP_STATUS_CODE.INTERNAL_SERVER_ERROR;
    this.message = message ?? "HttpError";
    this.stack = stack;
  }
};

// ../lib-shared/src/core/errors/DuplicateError/DuplicateError.ts
var DuplicateError = class extends HttpError {
  static {
    __name(this, "DuplicateError");
  }
  constructor(message) {
    super(HTTP_STATUS_CODE.CONFLICT, message);
  }
};

// ../lib-shared/src/core/errors/UninitializedError/UninitializedError.ts
var UninitializedError = class extends Error {
  static {
    __name(this, "UninitializedError");
  }
  constructor(value) {
    super(`not initialized: ${value}`);
  }
};

// ../lib-shared/src/logging/utils/logger/logger.ts
var import_isArray3 = __toESM(require("lodash/isArray"));
var import_isPlainObject2 = __toESM(require("lodash/isPlainObject"));

// ../lib-shared/src/core/utils/stringify/stringify.ts
var import_isString2 = __toESM(require("lodash/isString"));

// ../lib-shared/src/core/utils/stringify/_stringify.ts
var import_json_stringify_safe = __toESM(require("json-stringify-safe"));
var _stringify = /* @__PURE__ */ __name((...[params, options]) => options?.isMinify ?? true ? (0, import_json_stringify_safe.default)(params) : (0, import_json_stringify_safe.default)(params, null, "  "), "_stringify");

// ../lib-shared/src/core/utils/stringify/stringify.ts
var stringify2 = /* @__PURE__ */ __name((...[params, options]) => (0, import_isString2.default)(params) ? params : params ? _stringify(params, options) : "undefined", "stringify");

// ../lib-shared/src/data/utils/dateTimeFormat/_dateTimeFormat.ts
var import_date_fns = require("date-fns");
var _dateTimeFormat = /* @__PURE__ */ __name((...[value, format2 = "M/d/yyyy" /* DATE */]) => value && (0, import_date_fns.format)(value, format2), "_dateTimeFormat");

// ../lib-shared/src/data/utils/dateTimeFormat/dateTimeFormat.ts
var dateTimeFormat = /* @__PURE__ */ __name((...[value, format2]) => _dateTimeFormat(value, format2), "dateTimeFormat");

// ../lib-shared/src/logging/utils/logger/_logger.node.ts
var import_winston = require("winston");
var enumerateErrorFormat = (0, import_winston.format)((info3) => {
  if (info3 instanceof Error) {
    Object.assign(info3, { message: info3.stack });
  }
  return info3;
});
var logger = (0, import_winston.createLogger)({
  format: import_winston.format.combine(
    enumerateErrorFormat(),
    import_winston.format.colorize(),
    import_winston.format.splat(),
    import_winston.format.printf(
      ({ level, message }) => `[${dateTimeFormat(/* @__PURE__ */ new Date(), "M/d/yy HH:mm:ss" /* DATE_TIME_SECONDS_SHORT */)}] ${level}: ${message}`
    )
  ),
  level: process.env.NODE_ENV === "development" ? "debug" : "info",
  transports: [new import_winston.transports.Console({ stderrLevels: ["error"] })]
});
var { debug, error, info, warn } = {
  debug: (message) => logger.debug.bind(logger)(message),
  error: (message) => logger.error.bind(logger)(message),
  info: (message) => logger.info.bind(logger)(message),
  warn: (message) => logger.warn.bind(logger)(message)
};

// ../lib-shared/src/logging/utils/logger/logger.ts
var stringifyF = /* @__PURE__ */ __name((params) => params.map(
  (value) => (0, import_isPlainObject2.default)(value) ? stringify2(value) : (0, import_isArray3.default)(value) ? value.map((v2) => stringifyF([v2])) : value
).join(" "), "stringifyF");
var { debug: debug2, error: error2, info: info2, warn: warn2 } = {
  debug: (...params) => debug(stringifyF(params)),
  error: (...params) => error(stringifyF(params)),
  info: (...params) => info(stringifyF(params)),
  warn: (...params) => warn(stringifyF(params))
};

// ../lib-backend/src/database/utils/Database/_Database.ts
var import_core = require("@mikro-orm/core");
var import_isString3 = __toESM(require("lodash/isString"));
var import_last2 = __toESM(require("lodash/last"));
var import_mongodb3 = require("mongodb");
var getFilter = /* @__PURE__ */ __name((filters, prefix) => filters ? filters.reduce((result2, v2) => {
  const conditionF = v2.condition ?? "$eq" /* EQUAL */;
  return {
    ...result2,
    [prefix ? `${prefix}.${v2.field}` : v2.field]: [
      "$contains" /* CONTAINS */,
      "$notcontains" /* NOT_CONTAINS */
    ].includes(conditionF) ? {
      $options: "i",
      $regex: conditionF === "$contains" /* CONTAINS */ ? `${v2.value}` : `^((?!${v2.value}).)*$`
    } : {
      [conditionF]: (0, import_last2.default)(v2.field.split("."))?.startsWith("_") && (0, import_isString3.default)(v2.value) ? new import_mongodb3.ObjectId(v2.value) : v2.value
    }
  };
}, {}) : {}, "getFilter");
var _Database = class {
  static {
    __name(this, "_Database");
  }
  _config;
  _entityManager;
  constructor(config3) {
    this._config = config3;
  }
  async flush() {
    const em = this._getEntityManager();
    await em.flush();
  }
  async isConnected() {
    return this._entityManager?.getConnection().isConnected() ?? false;
  }
  async connect() {
    if (await this.isConnected()) {
      info2("reusing connection", this._config.clientUrl);
    } else {
      info2("connecting", this._config.clientUrl);
      this._entityManager = (await import_core.MikroORM.init(this._config)).em;
    }
  }
  _getEntityManager = () => {
    const em = this._entityManager;
    if (em) {
      return em.fork();
    }
    throw new UninitializedError("database");
  };
  getRepository = ({
    name
  }) => {
    const implementation = {
      clear: async () => {
        await this._getEntityManager().getRepository(name).nativeDelete({});
      },
      count: async () => this._getEntityManager().getRepository(name).count(),
      create: async ({ form, options } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = cleanDocument(form);
          const result2 = em.create(name, formF);
          !options?.isCommitted && await em.persistAndFlush(result2);
          return { result: result2 };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      createMany: async ({ form } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = form?.map(cleanDocument);
          const result2 = await em.insertMany(name, formF);
          return { result: result2 };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      get: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const collection = em.getCollection(name);
        const result2 = await (options?.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? filterNil([
            options.project && { $project: options.project },
            ...options.aggregate ?? []
          ]) : []
        ]).next() : collection.findOne(
          filterF,
          options && { projection: options.project }
        ));
        return { result: result2 ?? void 0 };
      },
      getConnection: async ({ filter, pagination } = {}) => {
        const { result: result2 } = await getConnection({
          count: await implementation.count(),
          getMany: implementation.getMany,
          input: { filter },
          pagination
        });
        return { result: result2 ?? void 0 };
      },
      getMany: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const collection = em.getCollection(name);
        const filterF = cleanDocument(getFilter(filter));
        const result2 = await (options && options.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? [
            options.project && { $project: options.project },
            options.take && { $limit: options.take + (options.skip ?? 0) },
            options.skip && { $skip: options.skip },
            ...options.aggregate ?? []
          ] : []
        ]).toArray() : collection.find(
          filterF,
          options && { limit: options.take, projection: options.project, skip: options.skip }
        ).toArray());
        return { result: result2 ?? void 0 };
      },
      remove: async ({ filter } = {}) => {
        const em = this._getEntityManager();
        const filterF = getFilter(filter);
        const entity = await implementation.get({ filter });
        await em.getRepository(name).nativeDelete(filterF);
        return entity;
      },
      update: async ({ filter, options, update } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const updateF = cleanDocument(update);
        updateF && Object.keys(updateF).forEach((key) => {
          const keyF = key;
          if (!key.startsWith("$")) {
            updateF["$set"] = {
              ...updateF["$set"] ?? {},
              [key]: updateF[keyF]
            };
            delete updateF[keyF];
          }
        });
        const { value: result2 } = await em.getConnection().getCollection(name).findOneAndUpdate(filterF, updateF, {
          projection: options?.project,
          returnDocument: "after",
          upsert: true
        });
        return { result: result2 };
      }
    };
    return implementation;
  };
  close = async () => {
    debug2("closing connections", this._config.clientUrl);
    if (await this.isConnected()) {
      await this._getEntityManager().getConnection()?.close();
    }
  };
};

// ../lib-backend/src/database/utils/Database/Database.ts
var Database = class extends _Database {
  static {
    __name(this, "Database");
  }
};

// ../lib-backend/src/setup/utils/initialize/initialize.ts
var initialize = /* @__PURE__ */ __name(async ({ config: config3 }) => {
  const result2 = {};
  if (config3) {
    const database = new Database(config3);
    await database.connect();
    _Container.set(Database, database, "mongo" /* MONGO */);
    result2.database = database;
  }
  return result2;
}, "initialize");

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var _createLambdaHandler = /* @__PURE__ */ __name(({
  context: contextDefault = {},
  databaseConfig,
  graphQlConfig,
  handler,
  plugins,
  type,
  websocketUri
}) => {
  const getContext = /* @__PURE__ */ __name(async ({
    context: context2,
    event
  }) => {
    const contextF = { ...contextDefault, ...context2 };
    contextF.callbackWaitsForEmptyEventLoop = false;
    contextF.pathname = event.requestContext.routeKey;
    if (plugins?.includes("authentication" /* AUTHENTICATION */)) {
      const eventF = event;
      const authorization = eventF.headers?.authorization ?? eventF.queryStringParameters?.Authorization;
      const user = await getUserFromHeader(authorization);
      user && (contextF.user = user);
      eventF.headers?.group && (contextF.group = eventF.headers.group);
    }
    if (databaseConfig && !contextF.database) {
      const { database } = await initialize({ config: databaseConfig() });
      database && (contextDefault.database = database);
    }
    contextF.requestId = type === "websocket" /* WEBSOCKET */ ? event.requestContext.connectionId : contextF.requestId;
    return contextF;
  }, "getContext");
  return async (event, context2, callback) => {
    if (type === "graphql" /* GRAPHQL */ && graphQlConfig) {
      const server = new import_server.ApolloServer({
        allowBatchedHttpRequests: true,
        formatError: (e, originalError) => {
          const originalErrorF = originalError?.originalError;
          const errorF = new HttpError(
            originalErrorF?.statusCode,
            e.message ?? originalErrorF?.message,
            e.extensions?.stacktrace ?? e?.stack ?? originalErrorF.stack
          );
          console.error(e);
          console.error(errorF);
          return errorF;
        },
        schema: graphQlConfig()
      });
      const handlerF = (0, import_aws_lambda.startServerAndCreateLambdaHandler)(
        server,
        import_aws_lambda.handlers.createAPIGatewayProxyEventV2RequestHandler(),
        {
          context: async ({ context: context3, event: event2 }) => getContext({ context: context3, event: event2 })
        }
      );
      return handlerF(event, context2, callback);
    }
    const contextF = await getContext({ context: context2, event });
    const result2 = {
      statusCode: HTTP_STATUS_CODE.SUCCESS,
      ...handler && await handler({ body: event.body, context: contextF })
    };
    switch (type) {
      case "websocket" /* WEBSOCKET */: {
        if (contextF.pathname === "$default" && result2.requestId && result2.body) {
          const api = new import_client_apigatewaymanagementapi.ApiGatewayManagementApiClient({ endpoint: websocketUri });
          const command = new import_client_apigatewaymanagementapi.PostToConnectionCommand({
            ConnectionId: result2.requestId,
            Data: Buffer.from(result2.body)
          });
          await api.send(command);
          return { statusCode: HTTP_STATUS_CODE.SUCCESS };
        }
        return result2;
      }
      default: {
        result2.body && (result2.body = stringify2(result2.body));
        return result2;
      }
    }
  };
}, "_createLambdaHandler");

// ../lib-backend/src/serverless/utils/createLambdaHandler/createLambdaHandler.ts
var createLambdaHandler = /* @__PURE__ */ __name(({
  ...params
}) => _createLambdaHandler({
  ...params,
  websocketUri: uri({
    host: process.env.SERVER_APP_HOST,
    port: process.env.SERVER_APP_WEBSOCKET_PORT
  })
}), "createLambdaHandler");

// ../lib-backend/src/file/utils/joinPaths/joinPaths.ts
var import_trimStart = __toESM(require("lodash/trimStart"));
var import_path = require("path");
var joinPaths = /* @__PURE__ */ __name((...[paths, options]) => {
  let path = (0, import_path.join)(...filterNil(paths));
  options?.extension && (path = `${path}.${(0, import_trimStart.default)(options.extension, ".")}`);
  return path;
}, "joinPaths");

// ../lib-backend/src/file/utils/getRoot/_getRoot.ts
var import_app_root_path = __toESM(require("app-root-path"));
var _getRoot = /* @__PURE__ */ __name(() => import_app_root_path.default.toString(), "_getRoot");

// ../lib-backend/src/file/utils/getRoot/getRoot.ts
var getRoot = /* @__PURE__ */ __name(() => _getRoot(), "getRoot");

// ../lib-backend/src/file/utils/fromRoot/fromRoot.ts
var fromRoot = /* @__PURE__ */ __name((...paths) => joinPaths([getRoot(), ...paths]), "fromRoot");

// ../lib-config/src/core/utils/defineConfig/defineConfig.ts
var import_isFunction2 = __toESM(require("lodash/isFunction"));

// ../lib-shared/src/core/utils/merge/merge.ts
var import_isArray4 = __toESM(require("lodash/isArray"));
var import_isPlainObject3 = __toESM(require("lodash/isPlainObject"));
var import_mergeWith = __toESM(require("lodash/mergeWith"));
var import_uniq = __toESM(require("lodash/uniq"));
var merge = /* @__PURE__ */ __name((...[values, strategy = "DEEP" /* DEEP */]) => (0, import_mergeWith.default)({}, ...values, (x, y) => {
  switch (strategy) {
    case "DEEP" /* DEEP */:
      return (0, import_isPlainObject3.default)(x) && (0, import_isPlainObject3.default)(y) ? merge([x, y], strategy) : x === void 0 ? y : x;
    case "DEEP_APPEND" /* DEEP_APPEND */:
    case "DEEP_PREPEND" /* DEEP_PREPEND */:
      return (0, import_isArray4.default)(x) && (0, import_isArray4.default)(y) ? (0, import_uniq.default)(
        strategy === "DEEP_APPEND" /* DEEP_APPEND */ ? [...y, ...x] : [...x, ...y]
      ) : (0, import_isPlainObject3.default)(x) && (0, import_isPlainObject3.default)(y) ? merge([x, y], strategy) : x === void 0 ? y : x;
    default:
      return x === void 0 ? y : x;
  }
}), "merge");

// ../lib-config/src/core/utils/defineConfig/defineConfig.ts
var getConfigs = /* @__PURE__ */ __name(({
  config: config3,
  overrides,
  strategy
}) => merge(
  [
    ...overrides ? (0, import_isFunction2.default)(overrides) ? overrides() : overrides : [],
    (0, import_isFunction2.default)(config3) ? config3() : config3
  ],
  strategy
), "getConfigs");
var defineConfig = /* @__PURE__ */ __name(({
  _config,
  config: config3,
  overrides,
  strategy = "DEEP_PREPEND" /* DEEP_PREPEND */
}) => ({
  _config: _config ? (0, import_isFunction2.default)(config3) ? (params) => _config(
    getConfigs({
      config: config3,
      overrides: [
        params,
        ...overrides ? overrides() : []
      ],
      strategy
    })
  ) : _config(getConfigs({ config: config3, overrides, strategy })) : void 0,
  config: (0, import_isFunction2.default)(config3) ? () => getConfigs({ config: config3, overrides, strategy }) : getConfigs({ config: config3, overrides, strategy })
}), "defineConfig");

// ../lib-config/src/core/file/file.ts
var BUILD_PATH = ".build";
var DIST_PATH = ".dist";
var CACHE_PATH = ".cache";
var PUBLIC_PATH = "assets";
var CLEAN_PATTERNS = [
  BUILD_PATH,
  CACHE_PATH,
  ".vite",
  ".esbuild",
  ".eslintcache",
  ".swc",
  "*.log*",
  ".DS_Store",
  "coverage"
];
var PRUNE_PATTERNS = [
  "node_modules/rxjs/src/**",
  "node_modules/rxjs/bundles/**",
  "node_modules/rxjs/_esm5/**",
  "node_modules/rxjs/_esm2015/**",
  "node_modules/grpc/deps/grpc/third_party/**",
  "node_modules/@aws-sdk",
  "node_modules/aws-sdk",
  "node_modules/**/*.md",
  "node_modules/**/*.flow",
  "node_modules/**/*.patch",
  "node_modules/**/*.conf",
  "node_modules/**/*.markdown",
  "node_modules/**/*.coffee",
  "node_modules/**/jsdoc_conf.json",
  "node_modules/**/*Makefile",
  "node_modules/**/Dockerfile",
  "node_modules/**/*.txt",
  "node_modules/**/*.yml",
  "node_modules/**/*.xml",
  "node_modules/**/*.html",
  "node_modules/**/test/**",
  "node_modules/**/tests/**",
  "node_modules/**/examples/**",
  "node_modules/**/coverage/**",
  "node_modules/**/.nyc_output/**",
  "node_modules/**/(!chromium)/bin/**",
  "node_modules/**/bower.json",
  "node_modules/**/karma.conf.js",
  "node_modules/**/Gruntfile.js",
  "node_modules/**/rollup.config.*",
  "node_modules/**/yarn.lock",
  "node_modules/**/sonar-project.properties",
  "node_modules/**/package-lock.json",
  "node_modules/**/*.d.ts",
  "node_modules/**/*.map",
  "node_modules/**/tsconfig.json",
  "node_modules/**/AUTHORS",
  "node_modules/**/CODEOWNERS",
  "node_modules/**/OWNERS",
  "node_modules/**/*.iml",
  "node_module/**/*.bash_completion.in",
  "node_modules/**/*.gif",
  "node_modules/**/*.png",
  "node_modules/**/*.jpg",
  "node_modules/**/*.jpeg",
  "node_modules/**/winston/scratch/**",
  "node_modules/**/sshpk/man/**",
  "node_modules/**/bluebird/js/browser/**",
  "node_modules/**/date-fns/docs.json",
  "node_modules/**/aws-xray-sdk-core/doc-src/**"
];
var { config } = defineConfig({
  config: {
    backupDir: fromRoot("../backups"),
    buildPath: BUILD_PATH,
    cachePath: CACHE_PATH,
    cleanPatterns: CLEAN_PATTERNS,
    distPath: DIST_PATH,
    excludePatterns: [...CLEAN_PATTERNS, ".git", "ios/Pods", "node_modules"],
    packagePrefixes: ["app", "backend", "lib", "tool"],
    prunePatterns: PRUNE_PATTERNS,
    publicPath: PUBLIC_PATH
  }
});

// ../lib-config/src/crawling/screen/screen.ts
var { config: config2 } = defineConfig({
  config: {
    delay: 4e3,
    delayDefault: 500,
    // dimension: { height: 2000, width: 1200 },
    dimension: { height: 1e4, width: 5e3 },
    isHeadless: false,
    isIgnoreImage: true,
    isIgnoreStyle: true,
    snapshotPath: joinPaths([config.buildPath, "snapshots"]),
    timeout: 3e4
  }
});

// ../lib-backend/src/file/utils/fromWorking/fromWorking.ts
var fromWorking = /* @__PURE__ */ __name((...paths) => joinPaths([process.cwd(), ...paths]), "fromWorking");

// ../lib-shared/src/core/errors/InvalidArgumentError/InvalidArgumentError.ts
var InvalidArgumentError = class extends Error {
  static {
    __name(this, "InvalidArgumentError");
  }
};

// ../lib-shared/src/core/errors/NotFoundError/NotFoundError.ts
var NotFoundError = class extends Error {
  static {
    __name(this, "NotFoundError");
  }
  constructor(message) {
    super(`not found: ${message}`);
  }
};

// ../lib-shared/src/core/utils/sleep/sleep.ts
var sleep = /* @__PURE__ */ __name((...[duration = 0, options]) => {
  const isVerboseF = options?.isVerbose || process.env.NODE_ENV === "development";
  let countdown = duration / 1e3;
  const timer = isVerboseF && setInterval(() => {
    debug2(`${countdown}s`);
    countdown--;
    if (countdown <= 0) {
      clearInterval(timer);
    }
  }, 1e3);
  return new Promise((resolve) => {
    setTimeout(() => {
      isVerboseF && clearInterval(timer);
      return resolve();
    }, duration);
  });
}, "sleep");

// ../lib-shared/src/crawling/utils/withScreen/_withScreen.ts
var import_chromium = __toESM(require("@sparticuz/chromium"));
var import_fs = require("fs");
var import_isNumber = __toESM(require("lodash/isNumber"));
var import_puppeteer_extra = __toESM(require("puppeteer-extra"));
var import_puppeteer_extra_plugin_stealth = __toESM(require("puppeteer-extra-plugin-stealth"));
import_puppeteer_extra.default.use((0, import_puppeteer_extra_plugin_stealth.default)());
var _withScreen = /* @__PURE__ */ __name(async (...[
  callback,
  { delay, delayDefault, dimension, isHeadless, snapshotPath, timeout }
]) => {
  const browser = await import_puppeteer_extra.default.launch({
    args: [
      ...import_chromium.default.args,
      "--no-sandbox",
      "--incognito",
      dimension && `--window-size-${dimension.width},${dimension.height}`
    ].filter(Boolean),
    defaultViewport: dimension,
    executablePath: await import_chromium.default.executablePath(),
    // headless: isHeadless ? 'new' : false,
    headless: "new",
    ignoreDefaultArgs: ["--hide-scrollbars", "--disable-web-security"],
    ignoreHTTPSErrors: true,
    protocolTimeout: 0
  });
  const page = await browser.newPage();
  await page.setUserAgent(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"
  );
  await page.setRequestInterception(true);
  await page.setExtraHTTPHeaders({ "Accept-Language": "en-US,en;q=0.9" });
  page.on("request", (req) => {
    const type = req.resourceType();
    if (type === "image" || type === "font") {
      void req.abort();
    } else {
      void req.continue();
    }
  });
  const getSelector = /* @__PURE__ */ __name((selector) => {
    switch (selector.type) {
      case "data" /* DATA */:
        return `[${selector.key}="${selector.value}"]`;
      case "id" /* ID */:
        return `#${selector.value}`;
      case "text" /* TEXT */:
        return `::-p-text(${selector.value})`;
      default:
        return selector.value;
    }
  }, "getSelector");
  const findF = /* @__PURE__ */ __name(async (selector, {
    index = -1,
    isDelay,
    isThrow = false,
    timeout: timeoutF = true
  } = {}, handle) => {
    await sleep(isDelay ? delay : delayDefault);
    const selectorF = getSelector(selector);
    try {
      info2(`Finding ${stringify2(selector)}...`);
      timeout && await (handle ?? page).waitForSelector(selectorF, {
        timeout: (0, import_isNumber.default)(timeoutF) ? timeoutF : timeout
      });
    } catch (e) {
      console.warn(e);
    }
    let selected;
    if (index >= 0) {
      selected = (await (handle ?? page).$$(selectorF))?.[index];
    } else {
      selected = await (handle ?? page).$(selectorF);
    }
    if (selected) {
      info2(`Found ${stringify2(selector)}!`);
      return new _Handle(selected);
    }
    isThrow && new NotFoundError(stringify2(selector));
    return null;
  }, "findF");
  const findAllF = /* @__PURE__ */ __name(async (selector, { isDelay, isThrow = true, timeout: timeoutF = true } = {}, handle) => {
    await sleep(isDelay ? delay : delayDefault);
    const selectorF = getSelector(selector);
    try {
      info2(`Finding all ${stringify2(selector)}...`);
      timeout && await (handle ?? page).waitForSelector(selectorF, {
        timeout: (0, import_isNumber.default)(timeoutF) ? timeoutF : timeout
      });
    } catch (e) {
    }
    const selected = await (handle ?? page).$$(selectorF);
    if (selected) {
      info2(`Found all ${stringify2(selector)}!`);
      return selected?.map((v2) => new _Handle(v2));
    }
    isThrow && new NotFoundError(stringify2(selector));
    return [];
  }, "findAllF");
  class _Handle {
    static {
      __name(this, "_Handle");
    }
    handle;
    constructor(handle) {
      this.handle = handle;
    }
    async find(selector, options = {}) {
      return findF(selector, options, this.handle);
    }
    async has(selector) {
      const selected = await findF(selector, { isThrow: false, timeout: false }, this.handle);
      return selected ? this : null;
    }
    async findAll(selector, options = {}) {
      return findAllF(selector, options, this.handle);
    }
    async press() {
      this.handle?.click && await this.handle?.click();
    }
    async previous() {
      const previous = await this.handle?.evaluateHandle((h2) => h2?.previousElementSibling);
      return previous ? new _Handle(previous) : null;
    }
    async next() {
      const next = await this.handle?.evaluateHandle((h2) => h2?.nextElementSibling);
      return next ? new _Handle(next) : null;
    }
    async url() {
      const text = await this.handle?.evaluate(async (el) => el?.href);
      return text ?? null;
    }
    async content() {
      const text = await this.handle?.evaluate(async (el) => el?.innerHTML);
      return text ?? null;
    }
    async src() {
      const text = await this.handle?.evaluate(async (el) => el?.src);
      return text ?? null;
    }
    async value() {
      const text = await this.handle?.evaluate(async (el) => el?.value);
      return text ?? null;
    }
    async select(value) {
      this.handle?.select && await this.handle?.select(value);
    }
    async text() {
      const text = await this.handle?.evaluate(async (el) => el.innerText);
      return text ?? null;
    }
    async type(value) {
      this.handle?.click && await this.handle?.type(value);
    }
  }
  const screen2 = {
    close: async () => {
      await browser.close();
    },
    find: findF,
    findAll: findAllF,
    key: async (value, { isDelay } = {}) => {
      await sleep(isDelay ? delay : delayDefault);
      const input = (() => {
        switch (value) {
          case "enter" /* ENTER */:
            return "Enter";
          case "up" /* UP */:
            return "ArrowUp";
          case "down" /* DOWN */:
            return "ArrowDown";
          default:
            throw new InvalidArgumentError();
        }
      })();
      await page.keyboard.press(input);
    },
    open: async (route) => {
      console.warn(`@@@route: ${route}`);
      await page.goto(route, { timeout, waitUntil: "networkidle2" });
    },
    snapshot: async ({ filename } = {}) => {
      await page.$eval('[banneroffsetheight="0"]', (h2) => h2?.remove());
      const element = await page.$("#bookingFunnelBody > div").then((h2) => h2?.boundingBox());
      const dirname = joinPaths([fromWorking(), snapshotPath]);
      !(0, import_fs.existsSync)(dirname) && (0, import_fs.mkdirSync)(dirname, { recursive: true });
      return page.screenshot({
        clip: {
          height: element?.height ?? dimension.height,
          width: element?.width ?? dimension.width,
          x: 0,
          y: 0
        },
        path: filename ? joinPaths([dirname, `${filename}.png`]) : void 0
      });
    },
    uri: () => {
      const { host, pathname, port } = new URL(page.url());
      return { host, pathname, port };
    }
  };
  try {
    await callback(screen2);
  } finally {
    await browser.close();
  }
}, "_withScreen");

// ../lib-shared/src/crawling/utils/withScreen/withScreen.ts
var withScreen = /* @__PURE__ */ __name(async (...[callback, options]) => _withScreen(callback, merge([options, config2])), "withScreen");

// src/functions/crawl/crawl.ts
var import_google_auth_library = require("google-auth-library");
var import_google_spreadsheet = require("google-spreadsheet");
var import_range = __toESM(require("lodash/range"));
var import_toNumber = __toESM(require("lodash/toNumber"));
var import_trim2 = __toESM(require("lodash/trim"));
var import_uniq2 = __toESM(require("lodash/uniq"));
var main = createLambdaHandler({
  handler: async ({ body, context }) => {
    console.warn(body);
    const ELEMENT_TIMEOUT = 5e3;
    await withScreen(async (screen) => {
      let result = [];
      const maxPages = 1;
      const batchSize = 1;
      const categories = [
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Sheathing-Plywood/N-5yc1vZc7q5?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Hardwood-Plywood/N-5yc1vZc7r1?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Oriented-Strand-Board-OSB/N-5yc1vZbqpq?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Timber/N-5yc1vZbym5?sortorder=desc&sortby=topsellers',
        //   'Timber',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Boards-Wood-Decking-Boards/Pressure-Treated/N-5yc1vZc80mZ1z0n5mi?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Stairs-Outdoor-Stair-Stringers/N-5yc1vZbqlk?sortorder=desc&sortby=topsellers',
        //   'Stringers',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Railings-Balusters-Spindles/Pressure-Treated/N-5yc1vZc5q0Z1z0n5mi?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Pressure-Treated-Lumber/2-in-x-4-in/N-5yc1vZc3srZ1z0n4we?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Pressure-Treated-Lumber/2-in-x-6-in/N-5yc1vZc3srZ1z0n4w1?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Pressure-Treated-Lumber/2-in-x-10-in/N-5yc1vZc3srZ1z0n4uq?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Timber/4-in/6-in/N-5yc1vZ2fkp9hkZ1z1rkokZ1z1sonl?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Project-Panels/N-5yc1vZc7hm?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Pressure-Treated-Lumber/2-in-x-10-in/2-in-x-6-in/2-in-x-8-in/N-5yc1vZc3srZ1z0n4uqZ1z0n4w1Z1z0n4w4?NCNI-5&sortorder=desc&sortby=topsellers',
        //   'Joist',
        // ],
        // [
        //   'https://www.homedepot.com/b/Paint/N-5yc1vZar2d?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Tools/N-5yc1vZc1xy?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Paint-Paint-Supplies-Tape/N-5yc1vZc5dk?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Flooring/N-5yc1vZaq7r?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Boards-Planks-Panels/N-5yc1vZ1z18h41?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Hardware-Fasteners/N-5yc1vZc255?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Fencing-Gates/N-5yc1vZbrk7?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Building-Hardware/N-5yc1vZaqzs?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Exterior-Doors-Front-Doors/N-5yc1vZar90?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Exterior-Doors-Patio-Doors/N-5yc1vZarqn?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Interior-Doors-Prehung-Doors/N-5yc1vZc5ij?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Interior-Doors-Slab-Doors/N-5yc1vZc5ie?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Interior-Doors/N-5yc1vZc5io?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Doors-Windows-Exterior-Doors/N-5yc1vZas82?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Hardware-Fasteners/N-5yc1vZc255?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Drywall-Joint-Compound/N-5yc1vZard1?sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials/N-5yc1vZaqnsZbwo5l?NCNI-5&sortorder=desc&sortby=topsellers',
        //   '',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Hardwood-Plywood/N-5yc1vZc7r1?sortorder=desc&sortby=topsellers',
        //   'Hardwood Plywood',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Sheathing-Plywood/N-5yc1vZc7q5?sortorder=desc&sortby=topsellers',
        //   'Sheathing Plywood',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-MDF/N-5yc1vZbtn1?sortorder=desc&sortby=topsellers',
        //   'MDF',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Plywood-Sanded-Plywood/N-5yc1vZc7qk?sortorder=desc&sortby=topsellers',
        //   'Sanded Plywood',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Roofing-Roof-Shingles/N-5yc1vZc5rb?sortorder=desc&sortby=topsellers',
        //   'Roof Shingles',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Roofing-Roof-Panels/N-5yc1vZaq4r?sortorder=desc&sortby=topsellers',
        //   'Roof Panels',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Roofing-Roof-Flashing-Roll-Flashing/N-5yc1vZas6d?sortorder=desc&sortby=topsellers',
        //   'Roof Flashing',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Drywall-Cement-Boards/N-5yc1vZcb0f?sortorder=desc&sortby=topsellers',
        //   'Cement Board',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Drywall-Drywall-Corner-Bead/N-5yc1vZc7qn?sortorder=desc&sortby=topsellers',
        //   'Corner Bead',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Drywall-Drywall-Tools/N-5yc1vZaro4?sortorder=desc&sortby=topsellers',
        //   'Drywall Tools',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Drywall-Drywall-Repair-Tools/N-5yc1vZc7r0?sortorder=desc&sortby=topsellers',
        //   'Drywall Repair',
        // ],
        //
        // ROUND 2
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Trusses/N-5yc1vZbtmz?sortorder=desc&sortby=topsellers',
        //   'Truss',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Pressure-Treated-Lumber/N-5yc1vZc3sr?sortorder=desc&sortby=topsellers',
        //   'Timber 2',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Dimensional-Lumber-Framing-Studs/N-5yc1vZc562?sortorder=desc&sortby=topsellers',
        //   'Framing Stud',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Ventilation-Roofing-Attic-Ventilation/N-5yc1vZc663?sortorder=desc&sortby=topsellers',
        //   'Roofing & Attic',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Insulation-Blown-in-Insulation/N-5yc1vZbayp?sortorder=desc&sortby=topsellers',
        //   'Blow in insulation',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Insulation-Mineral-Wool-Insulation/N-5yc1vZboco?sortorder=desc&sortby=topsellers',
        //   'Mineral wool insulation',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Insulation-Fiberglass-Insulation/N-5yc1vZbay7?sortorder=desc&sortby=topsellers',
        //   'Fiberglass',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Insulation-Foam-Board-Insulation/N-5yc1vZbaxx?sortorder=desc&sortby=topsellers',
        //   'Foam Board insulation',
        // ],
        // [
        //   'https://www.homedepot.com/b/Hardware-Fasteners-Screws/N-5yc1vZc2b0?sortorder=desc&sortby=topsellers',
        //   'Fasteners',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Concrete-Cement-Masonry-Concrete-Mix/N-5yc1vZcdpt?sortorder=desc&sortby=topsellers',
        //   'Concrete Mix',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Concrete-Cement-Masonry-Mortar-Mix/N-5yc1vZcdq4?sortorder=desc&sortby=topsellers',
        //   'Mortar Mix',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Concrete-Cement-Masonry-Stucco-Stucco-Mix/N-5yc1vZ2fkp5ot?sortorder=desc&sortby=topsellers',
        //   'Stucco Mix',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Concrete-Cement-Masonry-Concrete-Tools/N-5yc1vZarh8?sortorder=desc&sortby=topsellers',
        //   'Concrete Tools',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Ventilation/N-5yc1vZc4mr?catStyle=ShowProducts&sortorder=desc&sortby=topsellers',
        //   'Ventilations',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Gutter-Systems/N-5yc1vZardx?sortorder=desc&sortby=topsellers',
        //   'Gutters',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Fencing-Gates-Vinyl-Fencing/N-5yc1vZc3mq?sortorder=desc&sortby=topsellers',
        //   'Vinyl Fencing ',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Fencing-Gates-Composite-Fencing/N-5yc1vZc5ug?sortorder=desc&sortby=topsellers',
        //   'Compopsite Fencing',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Fencing-Gates-Metal-Fencing/N-5yc1vZc3le?sortorder=desc&sortby=topsellers',
        //   'Metal fencing',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Boards-Composite-Decking-Boards/N-5yc1vZc5mb?sortorder=desc&sortby=topsellers',
        //   'Composite Decking Boards',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Boards-Wood-Decking-Boards/N-5yc1vZc80m?sortorder=desc&sortby=topsellers',
        //   'Wood Decking Board',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Boards-PVC-Deck-Boards/N-5yc1vZc5mu?sortorder=desc&sortby=topsellers',
        //   'PVC Deck Board',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Wood-Siding/N-5yc1vZc8aj?sortorder=desc&sortby=topsellers',
        //   'Wood Siding',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Vinyl-Siding/N-5yc1vZc8a6?sortorder=desc&sortby=topsellers',
        //   'Vinyl Siding ',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Composite-Siding/N-5yc1vZc8ik?sortorder=desc&sortby=topsellers',
        //   'Composite Siding ',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Stone-Veneer-Siding/N-5yc1vZc85v?sortorder=desc&sortby=topsellers',
        //   'Stone Venner',
        // ],
        // [
        //   'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Railings-Deck-Railing-Systems/N-5yc1vZc5px?sortorder=desc&sortby=topsellers',
        //   'Deck Railing System',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Fiber-Cement-Siding/N-5yc1vZc8af?sortorder=desc&sortby=topsellers',
        //   'Fiber Siding',
        // ],
        // [
        //   'https://www.homedepot.com/b/Building-Materials-Siding-Siding-Trim/N-5yc1vZaq0n?sortorder=desc&sortby=topsellers',
        //   'Siding Trim',
        // ],
        {
          category: "Siding Accessories ",
          link: "https://www.homedepot.com/b/Building-Materials-Siding-Siding-Accessories/N-5yc1vZ2fkp9fi?sortorder=desc&sortby=topsellers",
          maxItems: 2
        }
        // {
        //   category: 'Moulding',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Moulding-Millwork-Moulding/N-5yc1vZara1?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Baseboards',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Moulding-Millwork-Moulding-Baseboard/N-5yc1vZcbjp?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Stair Parts',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Moulding-Millwork-Stair-Parts/N-5yc1vZbcro?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Stair Railings',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Moulding-Millwork-Stair-Parts-Stair-Railings/N-5yc1vZbcrw?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Ceiling Tiles',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Ceilings-Ceiling-Tiles/N-5yc1vZc58l?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Ceiling Grids',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Ceilings-Ceiling-Grids/N-5yc1vZc596?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Ceiling Light Panels & Louvers ',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Ceilings-Ceiling-Light-Panels/N-5yc1vZc58p?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Ceiling Tile tolls',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Ceilings-Ceiling-Tile-Tools/N-5yc1vZc59f?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Plexiglass',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Glass-Plastic-Sheets-Plexiglass/N-5yc1vZc9x2?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Corrugated Plastic Sheets',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Glass-Plastic-Sheets-Corrugated-Plastic-Sheets/N-5yc1vZcbtu?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Polycarbonate',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Glass-Plastic-Sheets-Polycarbonate-Sheets/N-5yc1vZc9ws?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Hdpe Sheets',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Glass-Plastic-Sheets-HDPE-Sheets/N-5yc1vZ2fkpddj?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Glass plastic Rubber Sheets ',
        //   link: 'https://www.homedepot.com/b/Building-Materials-Glass-Plastic-Sheets-Rubber-Sheets/N-5yc1vZcj87?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Deck Railings ',
        //   link: 'https://www.homedepot.com/b/Lumber-Composites-Decking-Deck-Railings/N-5yc1vZc5i7?sortorder=desc&sortby=topsellers',
        // },
        // {
        //   category: 'Wall Paneling',
        //   link: 'https://www.homedepot.com/b/Lumber-Composites-Boards-Planks-Panels-Wall-Paneling/N-5yc1vZbqp3?sortorder=desc&sortby=topsellers',
        // },
      ];
      const columns = [
        "Extra",
        "Tags",
        "Vendor",
        "Title",
        "Handle",
        "Body (HTML)",
        "Cost per Item",
        "Length",
        "Length Unit",
        "Width",
        "Width Unit",
        "Thickness",
        "Thickness Unit",
        "Variant Grams",
        "URL",
        "Image Src",
        "Image Position",
        "Variant Price",
        "Count"
      ];
      const auth = new import_google_auth_library.JWT({
        // email: process.env.SERVER_GOOGLE_EMAIL,
        // key: process.env.SERVER_GOOGLE_API_KEY,
        email: "bot-447@sunny-influence-410420.iam.gserviceaccount.com",
        key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC4C++YmoKWmWEj\n1tqAKjni9wLqiu7F9UwbjcJCDfsa3tmkRp/iqiskKxLA7QP3Qtuv8VUzSLDMvJLa\nevM2o3ARRp9ytEIqlQXAIRU9Nfz5g35VE7uD9rsUsEQ5uXOxOGb5lNHw50F3Ti80\n2EhNeP4fIp7Pk8RQKrEJhbMRPCfT8rUx2VV74+S+ozR8vBDQjlgsCP+4vFMmsmPq\nexatN3wk+rHNB065WeUOK4k7FcNlc97CYDSiQfbAqiDDp2LMH3BJ523TtOSMYwLQ\nIiuSw3s4yOJyAjV2YvPv3elYohRH2srkh9uh689lO1QME7ZZpliG0RtMrmq0zJAy\nl9UULrXnAgMBAAECggEABOAMELbHDsYxVIm0cACuV9zDLwNPH99HjNNMegN0y1lr\n2nYkdhSb3/FkJcghesNCnn5+C0W5qTK1kSQAnUnnBg4g2yD7P7WC2XwG3AA6G0Ho\nbsh/BxfaDMo+hGjtL5yW3bWbeg4mJcrkZTn1cFfsI1b/bfA0GwuGdQIdpC87vtl7\nbvCNVYYwxOrug49RV5bcRKeC2RmutAuP8KnwZTNn+iiOpw6h3WqdT3BaPWRMVgM9\nXgKjNzLcWUxVpFoN84C77QVtxko3Ll780eilH/OYsIK5GZ0BDpw/eNrl2sKGR5va\nhRegDMNccrWKjn3RzSxHcWxJkEa2h1kbx0qd3etQQQKBgQD0KiGz0uCOkY5g3FFR\nh9ad3lTSkuaBTnbazlPVq4YNn1vkWf1nHzswUvn7elzGTMz8rqi6ijj7REXa2fop\nOQTaJ0LXy/MevZxYWa2VbxC/UXMdoYzkU1qGDm05dn/Dyfnpg7uBLYJ9M22xNVUf\nLD8JYAzO3yo9t/ZhCaamO6ET1QKBgQDA98sOenvriunZv2jYOCvzl3gVdpFsuTnE\npxVm4nWulg7BtYDruU/aLfit8CCMrooSQueqMRfLrwTfLPc1N0eADTVHnsNTSbzB\n7M01UGvbJolwahoVnh8gcjJaG+J0v6DchQ2o2V1YYLLn2QxouhLePKGlae+08RfJ\npQy8VW4MywKBgQCH0RPUOn4s7+yaFpOpXX1VbYITbCGKVgIpLlJV7cZwt29fM2uQ\nvD+pXs6tQ2Bt8fSoreMveIm/wzd0SIIuAgif7OzyqwE+3UwlnSTAlfpj4cO9/Mop\ni/Az17yMFU12tFguu9dGQPFwAXaH91m1MGCUL3iQbnTJxhXn3n1zxIGSTQKBgEwi\nN/JJbxT6pNMtiu8sEmM0UsOdGTldRyaIiZAjLy0ntUDGHMxkO9YoJyJxSFZZEs6r\nqP1kCzBoqDJpakuLuOET1P6h7AyzXg7hIAG17ifz52v74LjAvyUtCSK2N726UXxP\n3pjM0eBpnoyM/TFgoMsf/uLljhbEvI7pWMIBrr7LAoGABY/kgEnAs5V//q8hyixM\nLIwWcTOhN9xUMbIHAYxUtaL93fC7xFqC0JIJLVmI0VkJwFJ+17xiRYN0s145jJdu\n5OLvsYwM28Q/A7lw3EY5dNnSLvsnZkbPF/zaK5/I74sHUYuOai8hbEV2CDrBZoXi\n/q21Z65lshBeeFduLdyJL4w=\n-----END PRIVATE KEY-----\n",
        scopes: [
          "https://www.googleapis.com/auth/spreadsheets",
          "https://www.googleapis.com/auth/drive.file"
        ]
      });
      const doc = new import_google_spreadsheet.GoogleSpreadsheet("1Y50rGvzXzPNcnDjm4xkJ1AnxKIYsKBaooeraCpankiw", auth);
      await doc.loadInfo();
      const [sheet] = doc.sheetsByIndex;
      for (const { category, link, maxItems } of categories) {
        const pageIndices = (0, import_range.default)(0, maxPages);
        for (const pageIndex of pageIndices) {
          try {
            let count = 1;
            if (maxItems && count >= maxItems) {
              break;
            }
            await screen.open(`${link}${pageIndex > 0 ? `&Nao=${pageIndex * 24}` : ""}`);
            await screen.find({ value: ".results-layout__toggle-grid" }, { timeout: ELEMENT_TIMEOUT }).then((h2) => h2?.press());
            const urls = await Promise.all(
              await screen.findAll({ value: ".browse-search__pod" }).then(
                (handles) => handles?.map((h2) => h2.find({ value: ".product-image" }).then((h3) => h3?.url()))
              )
            );
            const urlsF = [urls[0], urls[1]];
            for (const url of urlsF) {
              if (maxItems && count >= maxItems) {
                break;
              }
              try {
                if (url?.startsWith("https://www.homedepot.com")) {
                  const row = {};
                  const crawls = [];
                  columns.forEach((column) => row[column] = "");
                  await screen.open(url);
                  const accordions = await screen.findAll({
                    value: ".accordion-title-container"
                  });
                  for (const accordion of accordions) {
                    try {
                      await accordion.press();
                    } catch (e) {
                    }
                  }
                  row.Extra = category;
                  crawls.push(async () => {
                    let tags = [];
                    const categories2 = await screen.findAll({ value: ".breadcrumb__item a" }).then((handles) => handles.map((h2) => h2?.text()));
                    for (const category2 of categories2) {
                      const categoryF = await category2;
                      categoryF && categoryF !== "Home" && tags.push(categoryF);
                    }
                    tags = (0, import_uniq2.default)(tags);
                    row.Tags = tags ? tags.join(",") : "";
                  });
                  crawls.push(async () => {
                    row.Vendor = await screen.find({ value: ".brand" }).then((h2) => h2?.text()) ?? "";
                  });
                  crawls.push(async () => {
                    row.Title = await screen.find({
                      key: "data-component",
                      type: "data" /* DATA */,
                      value: "ProductDetailsTitle"
                    }).then((h2) => h2?.find({ value: "h1" }).then((h3) => h3?.text())) ?? "";
                    row.Title && (row.Handle = slug(row.Title));
                  });
                  crawls.push(async () => {
                    row["Body (HTML)"] = await screen.find({
                      key: "data-testid",
                      type: "data" /* DATA */,
                      value: "desktop-content"
                    }).then((h2) => h2?.find({ value: ".sui-flex-col" })).then((h2) => h2?.find({ value: ".sui-flex-col" })).then((h2) => h2?.content());
                    row["Body (HTML)"] = row["Body (HTML)"] ?? await screen.find({ value: ".desktop-content-wrapper__main-description" }).then((h2) => h2?.content());
                  });
                  crawls.push(async () => {
                    const priceContainer = await screen.find({
                      value: ".price-format__main-price"
                    });
                    if (priceContainer) {
                      const spans = await priceContainer.findAll({
                        value: "span"
                      });
                      const dollar = await spans[1]?.text();
                      const cent = await spans[3]?.text();
                      row["Cost per Item"] = dollar && cent ? (0, import_toNumber.default)(`${dollar ?? 0}.${cent ?? 0}`) : "";
                      row["Cost per Item"] && (row["Variant Price"] = (row["Cost per Item"] * 1.075).toFixed(
                        2
                      ));
                    }
                  });
                  const specificationsContainer = await screen.find(
                    { value: ".specifications" },
                    { timeout: ELEMENT_TIMEOUT }
                  );
                  if (specificationsContainer) {
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "ength (ft" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" ft.", "").replace(" ft", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Length = v;
                        row["Length Unit"] = "ft";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "ength (in" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" in.", "").replace(" in", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Length = v;
                        row["Length Unit"] = "in";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "idth (ft" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" ft.", "").replace(" ft", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Width = v;
                        row["Width Unit"] = "ft";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "idth (in" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" in.", "").replace(" in", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Width = v;
                        row["Width Unit"] = "in";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "hickness (ft" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" ft.", "").replace(" ft", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Thickness = v;
                        row["Thickness Unit"] = "ft";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "hickness (in" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" in.", "").replace(" in", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row.Thickness = v;
                        row["Thickness Unit"] = "in";
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "eight (grams" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" grams", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row["Variant Grams"] = v;
                      }
                    });
                    crawls.push(async () => {
                      const v = await specificationsContainer.find(
                        { type: "text" /* TEXT */, value: "eight (lb" },
                        { timeout: ELEMENT_TIMEOUT }
                      ).then((h2) => h2?.next()).then((h2) => h2?.text()).then((h2) => h2?.replace(" lb.", "").replace(" lb", "")).then((h) => h && (0, import_toNumber.default)((0, import_trim2.default)(eval(h), "0")));
                      if (v) {
                        row["Variant Grams"] = (v * 453.6).toFixed(3);
                      }
                    });
                  }
                  const thumbnails = await screen.findAll({ value: ".mediagallery__imgblock" });
                  crawls.push(async () => {
                    let i = 1;
                    for (const thumbnail of thumbnails) {
                      await thumbnail.press();
                      const src = await screen.find({ value: ".mediagallery__mainimage" }).then((h2) => h2?.find({ value: "img" })).then((h2) => h2?.src());
                      if (src) {
                        row.URL = url;
                        row.Count = count;
                        const rowToAdd = i > 1 ? { Extra: row.Extra, Handle: row.Handle } : row;
                        rowToAdd["Image Src"] = src;
                        rowToAdd["Image Position"] = i;
                        result.push(rowToAdd);
                        i++;
                      }
                    }
                  });
                  await Promise.all(crawls.map((f) => f()));
                  if (result) {
                    if (result.length > 0 && result.length % batchSize === 0) {
                      await sheet.addRows(result);
                      await sheet.saveUpdatedCells();
                      result = [];
                    }
                    count++;
                  }
                }
              } catch (e) {
                console.warn(e);
                continue;
              }
            }
            if (result.length > 0) {
              await sheet.addRows(result);
              await sheet.saveUpdatedCells();
              result = [];
            }
          } catch (e) {
            console.warn(e);
            continue;
          }
        }
      }
    });
    return {
      body: { message: "success" },
      headers: { "Access-Control-Allow-Origin": "*" },
      statusCode: HTTP_STATUS_CODE.SUCCESS
    };
  },
  plugins: ["authentication" /* AUTHENTICATION */]
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=crawl.js.map
