"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/websocket/websocket.ts
var websocket_exports = {};
__export(websocket_exports, {
  main: () => main
});
module.exports = __toCommonJS(websocket_exports);

// ../lib-backend/src/core/utils/Container/_Container.ts
var import_reflect_metadata = require("reflect-metadata");
var import_inversify = require("inversify");
var import_isFunction = __toESM(require("lodash/isFunction"));
var container = new import_inversify.Container({
  autoBindInjectable: true,
  defaultScope: "Singleton",
  skipBaseClassChecks: true
});
var _Container = {
  get: (type, name) => name ? container.getNamed(type, name) : container.get(type),
  set: (type, value, name) => {
    const valueF = (0, import_isFunction.default)(value) ? container.bind(type).to(value) : container.bind(type).toDynamicValue(() => value);
    name && valueF.whenTargetNamed(name);
  }
};

// ../../node_modules/.pnpm/tslib@2.6.2/node_modules/tslib/tslib.es6.mjs
function __decorate(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
    r = Reflect.decorate(decorators, target, key, desc);
  else
    for (var i = decorators.length - 1; i >= 0; i--)
      if (d = decorators[i])
        r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
__name(__decorate, "__decorate");
function __param(paramIndex, decorator) {
  return function(target, key) {
    decorator(target, key, paramIndex);
  };
}
__name(__param, "__param");
function __metadata(metadataKey, metadataValue) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
    return Reflect.metadata(metadataKey, metadataValue);
}
__name(__metadata, "__metadata");

// ../lib-backend/src/core/utils/withContainer/_withContainer.ts
var import_inversify2 = require("inversify");
var _withContainer = import_inversify2.injectable;

// ../lib-backend/src/core/utils/withContainer/withContainer.ts
var withContainer = /* @__PURE__ */ __name(({ name } = {}) => (target) => {
  _withContainer()(target);
  name && _Container.set(name, target);
  return target;
}, "withContainer");

// ../lib-backend/src/resource/resources/EntityResource/EntityResource.ts
var import_forEach = __toESM(require("lodash/forEach"));

// ../lib-backend/src/resource/utils/withEntity/withEntity.ts
var import_core = require("@mikro-orm/core");
var import_type_graphql = require("type-graphql");

// ../lib-shared/src/core/errors/NotImplementedError/NotImplementedError.ts
var NotImplementedError = class extends Error {
  static {
    __name(this, "NotImplementedError");
  }
  constructor(value) {
    super(`not implemented: ${value}`);
  }
};

// ../lib-backend/src/resource/utils/withEntity/withEntity.ts
var withEntity = /* @__PURE__ */ __name(({
  indices = [],
  isAbstract = false,
  isEmbeddable = false,
  isRepository = false,
  isSchema = true,
  isSchemaInput = true,
  name
} = {}) => {
  if (!name && !isAbstract) {
    throw new NotImplementedError("name for non-abstract entity");
  }
  return (Base) => {
    const nameF = name ?? Base.name;
    isSchema && (0, import_type_graphql.ObjectType)(nameF)(Base);
    isSchemaInput && (0, import_type_graphql.InputType)(`${nameF}Input`)(Base);
    let BaseF = isRepository ? (isEmbeddable ? import_core.Embeddable : import_core.Entity)({
      abstract: isAbstract,
      collection: nameF,
      tableName: nameF
    })(Base) : Base;
    for (const index of indices) {
      BaseF = (0, import_core.Index)({ properties: index })(BaseF);
    }
    return BaseF;
  };
}, "withEntity");

// ../lib-backend/src/resource/utils/withField/withField.ts
var import_core2 = require("@mikro-orm/core");
var import_type_graphql2 = require("type-graphql");
var getField = /* @__PURE__ */ __name(({
  Resource,
  isArray: isArray7,
  type
}) => {
  if (Resource) {
    return (0, import_type_graphql2.Field)(() => isArray7 ? [Resource()] : Resource(), {
      simple: true
    });
  }
  switch (type) {
    case "string" /* STRING */:
      return (0, import_type_graphql2.Field)(() => isArray7 ? [String] : String);
    case "boolean" /* BOOLEAN */:
      return (0, import_type_graphql2.Field)(() => isArray7 ? [Boolean] : Boolean);
    case "date" /* DATE */:
      return (0, import_type_graphql2.Field)(() => isArray7 ? [Date] : Date);
    case "number" /* NUMBER */:
      return (0, import_type_graphql2.Field)(() => isArray7 ? [import_type_graphql2.Float] : import_type_graphql2.Float);
    default:
      return (0, import_type_graphql2.Field)(() => isArray7 ? [String] : String);
  }
}, "getField");
var getColumn = /* @__PURE__ */ __name(({
  Resource,
  defaultValue,
  isArray: isArray7,
  isOptional,
  name,
  relation,
  root: root2,
  type
}) => {
  const defaultOptions = { nullable: isOptional, onCreate: defaultValue };
  if (Resource) {
    switch (relation) {
      case "embedded" /* EMBEDDED */:
        return (0, import_core2.Embedded)({
          array: isArray7,
          entity: Resource,
          nullable: defaultOptions.nullable,
          object: !isArray7
        });
      case "manyToMany" /* MANY_TO_MANY */:
        return (0, import_core2.ManyToMany)({
          ...defaultOptions,
          entity: Resource
        });
      case "oneToMany" /* ONE_TO_MANY */:
        return (0, import_core2.OneToMany)({
          ...defaultOptions,
          entity: Resource,
          mappedBy: root2,
          nullable: true,
          orphanRemoval: true
        });
      case "manyToOne" /* MANY_TO_ONE */:
        return (0, import_core2.ManyToOne)({
          ...defaultOptions,
          entity: Resource,
          // primary: true,
          ref: true
        });
      case "oneToOne" /* ONE_TO_ONE */:
        return (0, import_core2.OneToOne)({
          ...defaultOptions,
          entity: Resource
        });
      default:
        return (0, import_core2.Property)({ ...defaultOptions, type: () => Resource });
    }
  }
  if (isArray7) {
    return (0, import_core2.Property)({ ...defaultOptions, type: import_core2.ArrayType });
  }
  switch (type) {
    case "primaryKey" /* PRIMARY_KEY */:
      return (0, import_core2.PrimaryKey)({ ...defaultOptions, type: "ObjectId" });
    case "id" /* ID */:
      return (0, import_core2.Property)({ ...defaultOptions, type: "ObjectId" });
    case "string" /* STRING */:
      return (0, import_core2.Property)({ ...defaultOptions, type: "string" });
    case "number" /* NUMBER */:
      return (0, import_core2.Property)({ ...defaultOptions, type: "number" });
    case "date" /* DATE */:
      return (0, import_core2.Property)({ ...defaultOptions, type: Date });
    default:
      return (0, import_core2.Property)({ ...defaultOptions, type: void 0 });
  }
}, "getColumn");
var withField = /* @__PURE__ */ __name(({
  Resource,
  defaultValue,
  expire,
  isArray: isArray7,
  isOptional,
  isRepository = false,
  isSchema = true,
  isUnique,
  name,
  relation,
  root: root2,
  type
}) => (target, propertyKey) => {
  (expire || isUnique) && (0, import_core2.Index)({ options: expire ? { expireAfterSeconds: expire } : {} })(
    target,
    propertyKey
  );
  isSchema && getField({ Resource, isArray: isArray7, isOptional, name, relation, root: root2, type })(target, propertyKey);
  isRepository && getColumn({ Resource, defaultValue, isArray: isArray7, isOptional, name, relation, root: root2, type })(
    target,
    propertyKey
  );
}, "withField");

// ../lib-backend/src/resource/utils/withHook/withHook.ts
var import_core3 = require("@mikro-orm/core");

// ../lib-shared/src/core/errors/InvalidArgumentError/InvalidArgumentError.ts
var InvalidArgumentError = class extends Error {
  static {
    __name(this, "InvalidArgumentError");
  }
};

// ../lib-backend/src/resource/utils/withHook/withHook.ts
var getHook = /* @__PURE__ */ __name(({ type }) => {
  switch (type) {
    case "BEFORE_CREATE" /* BEFORE_CREATE */:
      return (0, import_core3.BeforeCreate)();
    default:
      throw new InvalidArgumentError();
  }
}, "getHook");
var withHook = /* @__PURE__ */ __name(({ type }) => (target, propertyKey) => getHook({ type })(target, propertyKey), "withHook");

// ../lib-backend/src/resource/resources/EntityResource/EntityResource.ts
var _a;
var _b;
var EntityResource = class EntityResource2 {
  static {
    __name(this, "EntityResource");
  }
  created;
  _id;
  async beforeCreate() {
    (0, import_forEach.default)(this, (v, k) => {
      if (v === void 0) {
        delete this[k];
      }
    });
  }
};
__decorate([
  withField({ defaultValue: () => /* @__PURE__ */ new Date(), isRepository: true, type: "date" /* DATE */ }),
  __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], EntityResource.prototype, "created", void 0);
__decorate([
  withField({ isRepository: true, type: "primaryKey" /* PRIMARY_KEY */ }),
  __metadata("design:type", String)
], EntityResource.prototype, "_id", void 0);
__decorate([
  withHook({ type: "BEFORE_CREATE" /* BEFORE_CREATE */ }),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", []),
  __metadata("design:returntype", typeof (_b = typeof Promise !== "undefined" && Promise) === "function" ? _b : Object)
], EntityResource.prototype, "beforeCreate", null);
EntityResource = __decorate([
  withEntity({ isAbstract: true })
], EntityResource);

// ../lib-shared/src/http/resources/Socket/Socket.constants.ts
var SOCKET_RESOURCE_NAME = "Socket";

// ../lib-backend/src/http/resources/Socket/Socket.ts
var Socket = class Socket2 extends EntityResource {
  static {
    __name(this, "Socket");
  }
  externalId;
  name;
};
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Socket.prototype, "externalId", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Socket.prototype, "name", void 0);
Socket = __decorate([
  withEntity({ isRepository: true, name: SOCKET_RESOURCE_NAME })
], Socket);

// ../lib-shared/src/core/utils/cleanObject/cleanObject.constants.ts
var CLEAN_OBJECT_KEYS = ["toJSON"];

// ../lib-shared/src/core/utils/filterNil/filterNil.ts
var filterNil = /* @__PURE__ */ __name((params) => params?.filter(Boolean), "filterNil");

// ../lib-shared/src/core/utils/isPrimitive/isPrimitive.ts
var isPrimitive = /* @__PURE__ */ __name((params) => params !== Object(params) || params instanceof Date, "isPrimitive");

// ../lib-shared/src/core/utils/toPlainObject/_toPlainObject.ts
var import_toPlainObject = __toESM(require("lodash/toPlainObject"));
var _toPlainObject = /* @__PURE__ */ __name((params) => (0, import_toPlainObject.default)(params), "_toPlainObject");

// ../lib-shared/src/core/utils/toPlainObject/toPlainObject.ts
var toPlainObject2 = /* @__PURE__ */ __name((params) => _toPlainObject(params), "toPlainObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.base.ts
var import_every = __toESM(require("lodash/every"));
var import_isArray = __toESM(require("lodash/isArray"));
var import_isObject = __toESM(require("lodash/isObject"));
var cleanObject = /* @__PURE__ */ __name((...[value, options, depth = 0]) => {
  if (isPrimitive(value)) {
    return value;
  }
  if ((0, import_isArray.default)(value)) {
    return filterNil(value.map((vv) => cleanObject(vv, options, depth)));
  }
  if ((0, import_isObject.default)(value) && (!options?.primitiveTypes || (0, import_every.default)(options?.primitiveTypes, (type) => !(value instanceof type)))) {
    const valueF = options?.objectTransformer ? options.objectTransformer(value, depth) : toPlainObject2(value);
    Object.keys(valueF).forEach((k) => {
      let v = valueF[k];
      v = options?.keyValueTransformer ? options.keyValueTransformer(v, k, depth) : v;
      if (CLEAN_OBJECT_KEYS.includes(k) || v === void 0) {
        delete valueF[k];
      } else {
        valueF[k] = cleanObject(v, options, depth + 1);
      }
    });
    return valueF;
  }
  return value;
}, "cleanObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.ts
var import_toPlainObject4 = __toESM(require("lodash/toPlainObject"));
var import_mongodb = require("mongodb");
var cleanObject2 = /* @__PURE__ */ __name((...[value, options, depth]) => cleanObject(
  value,
  {
    ...options,
    objectTransformer: (v) => {
      const { beforeCreate } = v;
      beforeCreate && void beforeCreate.bind(v)();
      return (0, import_toPlainObject4.default)(v);
    },
    primitiveTypes: [...options?.primitiveTypes ?? [], import_mongodb.ObjectId]
  },
  depth
), "cleanObject");

// ../lib-backend/src/database/utils/cleanDocument/cleanDocument.ts
var import_isArray2 = __toESM(require("lodash/isArray"));
var import_isEqual = __toESM(require("lodash/isEqual"));
var import_isPlainObject = __toESM(require("lodash/isPlainObject"));
var import_isString = __toESM(require("lodash/isString"));
var import_last = __toESM(require("lodash/last"));
var import_reduce = __toESM(require("lodash/reduce"));
var import_mongodb2 = require("mongodb");
var resolveObjectId = /* @__PURE__ */ __name((value) => (0, import_isString.default)(value) ? new import_mongodb2.ObjectId(value) : (0, import_isPlainObject.default)(value) ? (0, import_reduce.default)(value, (result, v, k) => ({ ...result, [k]: resolveObjectId(v) }), {}) : value, "resolveObjectId");
var cleanDocument = /* @__PURE__ */ __name((value) => cleanObject2(value, {
  keyValueTransformer: (v, k, depth) => {
    let vF = v;
    if (vF.entity) {
      vF = vF.entity;
    }
    return depth === 0 && (0, import_isPlainObject.default)(vF) && (0, import_isEqual.default)(Object.keys(vF), ["_id"]) ? resolveObjectId(vF._id) : (0, import_isString.default)(vF) && (0, import_last.default)(k.split("."))?.startsWith("_") ? (0, import_isArray2.default)(vF) ? vF.map(resolveObjectId) : new import_mongodb2.ObjectId(vF) : vF;
  }
}), "cleanDocument");

// ../lib-backend/src/database/utils/getConnection/getConnection.ts
var import_graphql_relay = require("graphql-relay");
var getConnection = /* @__PURE__ */ __name(async ({
  count,
  getMany,
  input = {},
  pagination = {}
}) => {
  const { after, before, first, last: last3 } = pagination;
  const beforeOffset = (0, import_graphql_relay.getOffsetWithDefault)(before, count);
  const afterOffset = (0, import_graphql_relay.getOffsetWithDefault)(after, -1);
  let startOffset = Math.max(-1, afterOffset) + 1;
  let endOffset = Math.min(beforeOffset, count);
  first && (endOffset = Math.min(endOffset, startOffset + first));
  last3 && (startOffset = Math.max(startOffset, endOffset - last3));
  const skip = Math.max(startOffset, 0);
  const take = Math.max(endOffset - startOffset, 1);
  const { result, root: root2 } = await getMany({ ...input, options: { skip, take } });
  if (result && result.length) {
    const edges = result.map((node, index) => ({
      cursor: (0, import_graphql_relay.offsetToCursor)(startOffset + index),
      node
    }));
    const { 0: firstEdge, length, [length - 1]: lastEdge } = edges;
    const lowerBound = after ? afterOffset + 1 : 0;
    const upperBound = before ? Math.min(beforeOffset, count) : count;
    const pageInfo = {
      endCursor: lastEdge.cursor,
      hasNextPage: first ? endOffset < upperBound : false,
      hasPreviousPage: last3 ? startOffset > lowerBound : false,
      startCursor: firstEdge.cursor
    };
    return { result: { edges, pageInfo }, root: root2 };
  }
  return {
    result: {
      edges: [],
      pageInfo: { endCursor: "", hasNextPage: false, hasPreviousPage: false, startCursor: "" }
    },
    root: root2
  };
}, "getConnection");

// ../lib-frontend/src/route/utils/trimPathname/trimPathname.ts
var import_trim = __toESM(require("lodash/trim"));

// ../lib-frontend/src/route/utils/slug/slug.ts
var slug = /* @__PURE__ */ __name((params) => params.normalize("NFKD").replace(/(.+)([A-Z])/g, "$1-$2").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^(\w|?)-]+/g, "").replace(/_/g, "-").replace(/--+/g, "-").replace(/-$/g, ""), "slug");

// ../lib-frontend/src/route/utils/trimPathname/trimPathname.ts
var trimPathname = /* @__PURE__ */ __name((value) => {
  const pathname = filterNil(value.split("/")).map((char) => (0, import_trim.default)(char, "/").replace(/\w\S*/g, slug)).join("/");
  return `/${(0, import_trim.default)(pathname, "/")}`;
}, "trimPathname");

// ../lib-shared/src/http/utils/uri/uri.ts
var uri = /* @__PURE__ */ __name(({
  host = "",
  isProtocol = true,
  params,
  pathname,
  port
}) => {
  let uri2 = `${host}${port ? `:${port}` : ""}${pathname ? trimPathname(pathname) : ""}`;
  if (params) {
    const queryParams = Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
    uri2 = `${uri2}?${queryParams}`;
  }
  !isProtocol && ([, uri2] = uri2.split("://"));
  return uri2;
}, "uri");

// ../lib-shared/src/http/http.constants.ts
var HTTP_STATUS_CODE = {
  BAD_REQUEST: 400,
  CONFLICT: 409,
  FORBIDDEN: 403,
  GATEWAY_TIMEOUT: 504,
  INTERNAL_SERVER_ERROR: 500,
  NETWORK_CONNECT_TIMEOUT: 599,
  SERVICE_UNAVAILABLE: 503,
  SUCCESS: 200,
  UNAUTHORIZED: 401
};
var APP_URI = uri({ host: process.env.APP_HOST, port: process.env.APP_PORT });

// ../lib-shared/src/http/errors/HttpError/HttpError.ts
var HttpError = class _HttpError extends Error {
  static {
    __name(this, "HttpError");
  }
  statusCode;
  constructor(statusCode, message, stack) {
    super();
    Object.setPrototypeOf(this, _HttpError.prototype);
    this.statusCode = statusCode ?? HTTP_STATUS_CODE.INTERNAL_SERVER_ERROR;
    this.message = message ?? "HttpError";
    this.stack = stack;
  }
};

// ../lib-shared/src/core/errors/DuplicateError/DuplicateError.ts
var DuplicateError = class extends HttpError {
  static {
    __name(this, "DuplicateError");
  }
  constructor(message) {
    super(HTTP_STATUS_CODE.CONFLICT, message);
  }
};

// ../lib-shared/src/core/errors/UninitializedError/UninitializedError.ts
var UninitializedError = class extends Error {
  static {
    __name(this, "UninitializedError");
  }
  constructor(value) {
    super(`not initialized: ${value}`);
  }
};

// ../lib-shared/src/core/utils/stringify/stringify.ts
var import_isString2 = __toESM(require("lodash/isString"));

// ../lib-shared/src/core/utils/stringify/_stringify.ts
var import_json_stringify_safe = __toESM(require("json-stringify-safe"));
var _stringify = /* @__PURE__ */ __name((...[params, options]) => options?.isMinify ?? true ? (0, import_json_stringify_safe.default)(params) : (0, import_json_stringify_safe.default)(params, null, "  "), "_stringify");

// ../lib-shared/src/core/utils/stringify/stringify.ts
var stringify2 = /* @__PURE__ */ __name((...[params, options]) => (0, import_isString2.default)(params) ? params : params ? _stringify(params, options) : "undefined", "stringify");

// ../lib-shared/src/logging/utils/logger/logger.ts
var import_isArray3 = __toESM(require("lodash/isArray"));
var import_isPlainObject2 = __toESM(require("lodash/isPlainObject"));

// ../lib-shared/src/logging/utils/logger/_logger.node.ts
var import_winston = require("winston");

// ../lib-shared/src/data/utils/dateTimeFormat/_dateTimeFormat.ts
var import_moment = __toESM(require("moment"));
var _dateTimeFormat = /* @__PURE__ */ __name(({ format: format2 = "M/D/YYYY" /* DATE */, value } = {
  format: "M/D/YYYY" /* DATE */
}) => (0, import_moment.default)(value).format(format2), "_dateTimeFormat");

// ../lib-shared/src/logging/utils/logger/_logger.node.ts
var enumerateErrorFormat = (0, import_winston.format)((info3) => {
  if (info3 instanceof Error) {
    Object.assign(info3, { message: info3.stack });
  }
  return info3;
});
var logger = (0, import_winston.createLogger)({
  format: import_winston.format.combine(
    enumerateErrorFormat(),
    import_winston.format.colorize(),
    import_winston.format.splat(),
    import_winston.format.printf(
      ({ level, message }) => `[${_dateTimeFormat({
        format: "M/D/YY HH:mm:ss" /* DATE_TIME_SECONDS_SHORT */
      })}] ${level}: ${message}`
    )
  ),
  level: true ? "debug" : "info",
  transports: [new import_winston.transports.Console({ stderrLevels: ["error"] })]
});
var { debug, error, info, warn } = {
  debug: (message) => logger.debug.bind(logger)(message),
  error: (message) => logger.error.bind(logger)(message),
  info: (message) => logger.info.bind(logger)(message),
  warn: (message) => logger.warn.bind(logger)(message)
};

// ../lib-shared/src/logging/utils/logger/logger.ts
var stringifyF = /* @__PURE__ */ __name((params) => params.map(
  (value) => (0, import_isPlainObject2.default)(value) ? stringify2(value) : (0, import_isArray3.default)(value) ? value.map((v) => stringifyF([v])) : value
).join(" "), "stringifyF");
var { debug: debug2, error: error2, info: info2, warn: warn2 } = {
  debug: (...params) => debug(stringifyF(params)),
  error: (...params) => error(stringifyF(params)),
  info: (...params) => info(stringifyF(params)),
  warn: (...params) => warn(stringifyF(params))
};

// ../lib-backend/src/database/utils/Database/_Database.ts
var import_core4 = require("@mikro-orm/core");
var import_isString3 = __toESM(require("lodash/isString"));
var import_last2 = __toESM(require("lodash/last"));
var import_mongodb3 = require("mongodb");
var getFilter = /* @__PURE__ */ __name((filters, prefix) => filters ? filters.reduce((result, v) => {
  const conditionF = v.condition ?? "$eq" /* EQUAL */;
  return {
    ...result,
    [prefix ? `${prefix}.${v.field}` : v.field]: [
      "$contains" /* CONTAINS */,
      "$notcontains" /* NOT_CONTAINS */
    ].includes(conditionF) ? {
      $options: "i",
      $regex: conditionF === "$contains" /* CONTAINS */ ? `${v.value}` : `^((?!${v.value}).)*$`
    } : {
      [conditionF]: (0, import_last2.default)(v.field.split("."))?.startsWith("_") && (0, import_isString3.default)(v.value) ? new import_mongodb3.ObjectId(v.value) : v.value
    }
  };
}, {}) : {}, "getFilter");
var _Database = class {
  static {
    __name(this, "_Database");
  }
  _config;
  _entityManager;
  constructor(config4) {
    this._config = config4;
  }
  async flush() {
    const em = this._getEntityManager();
    await em.flush();
  }
  async isConnected() {
    return this._entityManager?.getConnection().isConnected() ?? false;
  }
  async connect() {
    if (await this.isConnected()) {
      info2("reusing connection", this._config.clientUrl);
    } else {
      info2("connecting", this._config.clientUrl);
      this._entityManager = (await import_core4.MikroORM.init(this._config)).em;
    }
  }
  _getEntityManager = () => {
    const em = this._entityManager;
    if (em) {
      return em.fork();
    }
    throw new UninitializedError("database");
  };
  getRepository = ({
    name
  }) => {
    const service = {
      clear: async () => {
        await this._getEntityManager().getRepository(name).nativeDelete({});
      },
      count: async () => this._getEntityManager().getRepository(name).count(),
      create: async ({ form, options } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = cleanDocument(form);
          console.warn(formF);
          const result = em.create(name, formF);
          !options?.isCommitted && await em.persistAndFlush(result);
          return { result };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      createMany: async ({ form } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = form?.map(cleanDocument);
          const result = await em.insertMany(name, formF);
          return { result };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      get: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const collection = em.getCollection(name);
        const result = await (options?.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? filterNil([
            options.project && { $project: options.project },
            ...options.aggregate ?? []
          ]) : []
        ]).next() : collection.findOne(
          filterF,
          options && { projection: options.project }
        ));
        return { result: result ?? void 0 };
      },
      getConnection: async ({ filter, pagination } = {}) => {
        const { result } = await getConnection({
          count: await service.count(),
          getMany: service.getMany,
          input: { filter },
          pagination
        });
        return { result: result ?? void 0 };
      },
      getMany: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const collection = em.getCollection(name);
        const filterF = cleanDocument(getFilter(filter));
        const result = await (options && options.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? [
            options.project && { $project: options.project },
            options.take && { $limit: options.take + (options.skip ?? 0) },
            options.skip && { $skip: options.skip },
            ...options.aggregate ?? []
          ] : []
        ]).toArray() : collection.find(
          filterF,
          options && { limit: options.take, projection: options.project, skip: options.skip }
        ).toArray());
        return { result: result ?? void 0 };
      },
      remove: async ({ filter } = {}) => {
        const em = this._getEntityManager();
        const filterF = getFilter(filter);
        const entity = await service.get({ filter });
        await em.getRepository(name).nativeDelete(filterF);
        return entity;
      },
      update: async ({ filter, options, update } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const updateF = cleanDocument(update);
        updateF && Object.keys(updateF).forEach((key) => {
          const keyF = key;
          if (!key.startsWith("$")) {
            updateF["$set"] = {
              ...updateF["$set"] ?? {},
              [key]: updateF[keyF]
            };
            delete updateF[keyF];
          }
        });
        console.warn(filterF);
        console.warn(stringify2(update));
        console.warn(stringify2(updateF));
        console.warn("\n\n");
        const { value: result } = await em.getConnection().getCollection(name).findOneAndUpdate(filterF, updateF, {
          projection: options?.project,
          returnDocument: "after"
        });
        return { result };
      }
    };
    return service;
  };
  close = async () => {
    debug2("closing connections", this._config.clientUrl);
    if (await this.isConnected()) {
      await this._getEntityManager().getConnection()?.close();
    }
  };
};

// ../lib-backend/src/database/utils/Database/Database.ts
var Database = class extends _Database {
  static {
    __name(this, "Database");
  }
};

// ../lib-shared/src/resource/utils/collapseFilter/collapseFilter.ts
var collapseFilter = /* @__PURE__ */ __name((params) => params?.map(
  ({
    booleanValue,
    condition,
    dateValue,
    field,
    numberValue,
    resourceArrayValue,
    resourceValue,
    stringArrayValue,
    stringValue,
    value
  }) => ({
    condition,
    field,
    value: value ?? booleanValue ?? dateValue ?? numberValue ?? resourceValue ?? resourceArrayValue ?? stringValue ?? stringArrayValue
  })
) ?? [], "collapseFilter");

// ../lib-backend/src/resource/utils/createResourceService/createResourceService.ts
var createResourceService = /* @__PURE__ */ __name(({
  afterCreate,
  afterCreateMany,
  afterGet,
  afterGetConnection,
  afterGetMany,
  afterRemove,
  afterUpdate,
  beforeCreate,
  beforeCreateMany,
  beforeGet,
  beforeGetConnection,
  beforeGetMany,
  beforeRemove,
  beforeUpdate,
  create,
  createMany,
  get,
  getConnection: getConnection2,
  getMany,
  remove,
  root: root2,
  update
}) => {
  class ResourceService {
    static {
      __name(this, "ResourceService");
    }
    _decorators = {
      afterCreate,
      afterCreateMany,
      afterGet,
      afterGetConnection,
      afterGetMany,
      afterRemove,
      afterUpdate,
      beforeCreate,
      beforeCreateMany,
      beforeGet: async ({ input }, context) => {
        const inputF = { ...input, filter: collapseFilter(input?.filter) };
        return beforeGet ? beforeGet({ input: inputF }, context) : inputF;
      },
      beforeGetConnection: async ({ input }, context) => {
        const inputF = { ...input, filter: collapseFilter(input?.filter) };
        return beforeGetConnection ? beforeGetConnection({ input: inputF }, context) : inputF;
      },
      beforeGetMany: async ({ input }, context) => {
        const inputF = { ...input, filter: collapseFilter(input?.filter) };
        return beforeGetMany ? beforeGetMany({ input: inputF }, context) : inputF;
      },
      beforeRemove: async ({ input }, context) => {
        const inputF = { ...input, filter: collapseFilter(input?.filter) };
        return beforeRemove ? beforeRemove({ input: inputF }, context) : inputF;
      },
      beforeUpdate: async ({ input }, context) => {
        const inputF = { ...input, filter: collapseFilter(input?.filter) };
        return beforeUpdate ? beforeUpdate({ input: inputF }, context) : inputF;
      },
      root: root2
    };
    constructor() {
      this.create = this.create.bind(this);
      this.createMany = this.createMany.bind(this);
      this.get = this.get.bind(this);
      this.getMany = this.getMany.bind(this);
      this.getConnection = this.getConnection.bind(this);
      this.update = this.update.bind(this);
      this.remove = this.remove.bind(this);
    }
    get decorators() {
      return this._decorators;
    }
    set decorators(value) {
      this._decorators = value;
    }
    async create(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeCreate ? await this.decorators.beforeCreate({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await create(
        inputF,
        context
      );
      return this.decorators.afterCreate ? this.decorators.afterCreate({ output }, context) : output;
    }
    async createMany(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeCreateMany ? await this.decorators.beforeCreateMany({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await createMany(
        inputF,
        context
      );
      return this.decorators.afterCreateMany ? this.decorators.afterCreateMany({ output }, context) : output;
    }
    async get(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeGet ? await this.decorators.beforeGet({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await get(
        inputF,
        context
      );
      return this.decorators.afterGet ? this.decorators.afterGet({ output }, context) : output;
    }
    async getMany(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeGetMany ? await this.decorators.beforeGetMany({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await getMany(
        inputF,
        context
      );
      return this.decorators.afterGetMany ? this.decorators.afterGetMany({ output }, context) : output;
    }
    async getConnection(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeGetConnection ? await this.decorators.beforeGetConnection({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await getConnection2(inputF, context);
      return this.decorators.afterGetConnection ? this.decorators.afterGetConnection({ output }, context) : output;
    }
    async update(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeUpdate ? await this.decorators.beforeUpdate({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await update(
        inputF,
        context
      );
      return this.decorators.afterUpdate ? this.decorators.afterUpdate({ output }, context) : output;
    }
    async remove(input = {}, context) {
      const inputF = cleanObject2(
        this.decorators.beforeRemove ? await this.decorators.beforeRemove({ input }, context) : input
      );
      const root3 = inputF?.root ?? this._decorators.root;
      inputF && root3 && (inputF.root = root3);
      const output = await remove(
        inputF,
        context
      );
      return this.decorators.afterRemove ? this.decorators.afterRemove({ output }, context) : output;
    }
    async count() {
      return this.count();
    }
  }
  return ResourceService;
}, "createResourceService");

// ../lib-backend/src/resource/utils/createEntityResourceService/createEntityResourceService.ts
var createEntityResourceService = /* @__PURE__ */ __name(({
  Resource,
  afterCreate,
  afterCreateMany,
  afterGet,
  afterGetConnection,
  afterGetMany,
  afterRemove,
  afterUpdate,
  beforeCreate,
  beforeCreateMany,
  beforeGet,
  beforeGetConnection,
  beforeGetMany,
  beforeRemove,
  beforeUpdate,
  name
}) => {
  let repository;
  const getRepository = /* @__PURE__ */ __name(() => {
    repository = repository ?? _Container.get(Database, "mongo" /* MONGO */).getRepository({ name });
    return repository;
  }, "getRepository");
  return createResourceService({
    Resource,
    afterCreate,
    afterCreateMany,
    afterGet,
    afterGetConnection,
    afterGetMany,
    afterRemove,
    afterUpdate,
    beforeCreate,
    beforeCreateMany,
    beforeGet,
    beforeGetConnection,
    beforeGetMany,
    beforeRemove,
    beforeUpdate,
    count: async () => getRepository().count(),
    create: async (input) => getRepository().create(input),
    createMany: async (input) => getRepository().createMany(input),
    get: async (input) => getRepository().get(input),
    getConnection: async (input) => getRepository().getConnection(input),
    getMany: async (input) => getRepository().getMany(input),
    name,
    remove: async (input) => getRepository().remove(input),
    update: async (input) => getRepository().update(input)
  });
}, "createEntityResourceService");

// ../lib-backend/src/http/resources/Socket/SocketService/SocketService.ts
var SocketService = class SocketService2 extends createEntityResourceService({
  Resource: Socket,
  name: SOCKET_RESOURCE_NAME
}) {
  static {
    __name(this, "SocketService");
  }
};
SocketService = __decorate([
  withContainer({ name: `${SOCKET_RESOURCE_NAME}Service` })
], SocketService);

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var import_server = require("@apollo/server");
var import_aws_lambda = require("@as-integrations/aws-lambda");
var import_client_apigatewaymanagementapi = require("@aws-sdk/client-apigatewaymanagementapi");

// ../lib-backend/src/auth/utils/JwtService/_JwtService.ts
var import_firebase_admin = __toESM(require("firebase-admin"));
var import_toString = __toESM(require("lodash/toString"));

// ../lib-shared/src/user/resources/User/User.constants.ts
var USER_RESOURCE_NAME = "User";

// ../lib-shared/src/auth/resources/SignIn/SignIn.constants.ts
var SIGN_IN_RESOURCE_NAME = "SignIn";
var SIGN_IN_USER = `${SIGN_IN_RESOURCE_NAME}${USER_RESOURCE_NAME}`;
var SIGN_IN_USERNAME = `${SIGN_IN_RESOURCE_NAME}Username`;
var SIGN_IN_TOKEN_CLAIM_KEYS = [
  "email",
  "phone",
  "first",
  "last"
];

// ../lib-shared/src/core/utils/pick/_pick.ts
var import_pick = __toESM(require("lodash/pick"));
var _pick = /* @__PURE__ */ __name((...[value, keys]) => (0, import_pick.default)(value, keys), "_pick");

// ../lib-shared/src/core/utils/pick/pick.ts
var pick2 = /* @__PURE__ */ __name((...params) => _pick(...params), "pick");

// ../lib-backend/src/auth/utils/JwtService/_JwtService.ts
var _JwtService = class {
  static {
    __name(this, "_JwtService");
  }
  constructor() {
    !import_firebase_admin.default.apps.length && import_firebase_admin.default.initializeApp({
      credential: import_firebase_admin.default.credential.cert({
        clientEmail: "firebase-adminsdk-ofw76@app-46c38.iam.gserviceaccount.com",
        privateKey: "-----BEGIN PRIVATE KEY-----\\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDTb4hDO2RhqDrP\\nyaINPn8prgdZvDBEXioW0BeS9f4lnud8CebdiZ7qu7LOVUEJj3FKnPt/4RgSGK8m\\n+RHeLnzoljfDdx8SotidTSngImhoznNsb3GWjH83nxRsP0YKPijYK/MfzfcCMf6n\\nX9mwrhJkad8tOzgzAbadNcvEfFUQstkTjZ34dp/go2euFT4vGJfB+K2lChvZs6Tt\\n/jYmaUVehPAvyN4s5+CwbP+dzM6jm7/Ibd54zVw+d2kme1IYs7fl53KWOlRaEl7l\\neoiqvqWFTTaCypOkWHTZWaEvAJxxMo7OEUnoYQegYb2+TkfKcf82O4N2JKAWqpnz\\nWMFqqMHbAgMBAAECggEAH7as85im99bp61zNB7uGC1RlGdqWSsrs+TsBLjPjiPUK\\nt5osnLIVuhOpQDWdabewQIbHWmkC2UQGkYvuWCsU5TYS6yik6oCuiPmX/Fxs2LuO\\nqIcWvIQaWNdtksby1Hp6WeJNt0mHcTbagXRpDI0viQwwQ3KMfWoWYAI/rBsSD0ze\\nS6OTsAN0UNxYTOotg6WCQN5O30G97s4oBgtWvftMWicd6ckfInyoWt48kyiYmLaG\\nPhxxLSaYb+/Ve33YdEED5QHCuH8fYvyYlKM4ts/m97wMkWa6a6taoQvZ4dUKZKFF\\nzj1yxfmCfbVbiFiuXH8PsHp/jr0L50cIfgggp5bWgQKBgQD0/MLoQHK8g9mX7lXM\\nA75XZGDsUw6Yrl0Ozr2HVTy7PQXeSrS6QEH9OwJ6O2nbps596f3zb5EXbXl9KdVZ\\nrqGkXKLaV1OsMppqoLIc/UlNMLURNzluJdLQhEun608p/j/x0kPdBKc9lB92IFP/\\nqkuNJ8EMZDwvp8YvkMLuKC/UuwKBgQDc8Ksp4UoJ5cF/69oM63gZWAFJe6KE+mAm\\nB2oEq+6Ml9ktD1hZKnqVZRkS6o86aibsbqTbAR20k/DPuNm+piOSunISiSB5iOvA\\nXASl9ddS0aAAsYQ74XAsySP7TdNmolqrKd2Loo85KqDwVGAXInT8Tac0oPiRp77D\\nhxS9VsyFYQKBgQDiLFhkwtsqXy+LrGVZLDuVwv4YL7XSD2eqPAON5Ytj8TpxttaS\\n/K/vcYMgBan9N0p7xILHM8DnuBHpE638VdS1QTC4EtcUqsMUnbbSPKRntwfzFODY\\nZ+LwzrJqHDvBsRCn2E7+xUUA/Lbu/3mNF1MYxhLbtc460NGPKD5OUJuX8QKBgBB3\\n6/o6Lb+hHZRAa0dtQc15ztbAXXPWCdar1M42VpiqNOjz7NzwmqSKHZ1YWIa9JNuY\\nv7cHVUSBhoClQa3BSoOEXD5fdEk62H/FHB+WvI8Syv9iO/4OpsLf10vDGE/dKC77\\n9uSSoGRddhOT5nmy+s9Xpm/4065ft4txhS07zBDhAoGABQLhltA5+pP+wTt3CQoD\\npXQ8MQv0FvBYSxPPuGWKavRRlco1D68k1mf+BiyQ2l2oGyUlWGObA+2w7yFrPmRB\\n9eM3AUmqFKZRTQZy5QMyF0RiugH4lVg4CCIu4kvwWA4tzo296WWlseSJBIF9+kTt\\nsefeNjnDvvPVF0xMglCR6DI=\\n-----END PRIVATE KEY-----\\n".replace(/\\n/gm, "\n"),
        projectId: "app-46c38"
      })
    });
  }
  createToken = async (_id, claims) => import_firebase_admin.default.auth().createCustomToken((0, import_toString.default)(_id), claims);
  verifyToken = async (token) => {
    const decoded = await import_firebase_admin.default.auth().verifyIdToken(token);
    return {
      _id: decoded.uid,
      claims: {
        ...decoded.additionalClaims ?? {},
        ...pick2(decoded, SIGN_IN_TOKEN_CLAIM_KEYS)
      }
    };
  };
};

// ../lib-backend/src/auth/utils/JwtService/JwtService.ts
var JwtService = class JwtService2 extends _JwtService {
  static {
    __name(this, "JwtService");
  }
};
JwtService = __decorate([
  withContainer()
], JwtService);

// ../lib-backend/src/auth/utils/getUserFromHeader/getUserFromHeader.ts
var getUserFromHeader = /* @__PURE__ */ __name(async (params) => {
  if (params) {
    const [, token] = params.split(" ");
    return token && token !== "null" ? _Container.get(JwtService).verifyToken(token) : null;
  }
  return null;
}, "getUserFromHeader");

// ../lib-config/src/core/utils/defineConfig/defineConfig.ts
var import_isFunction2 = __toESM(require("lodash/isFunction"));

// ../lib-shared/src/core/utils/merge/merge.ts
var import_isArray4 = __toESM(require("lodash/isArray"));
var import_isPlainObject3 = __toESM(require("lodash/isPlainObject"));
var import_mergeWith = __toESM(require("lodash/mergeWith"));
var import_uniq = __toESM(require("lodash/uniq"));
var merge = /* @__PURE__ */ __name((...[values, strategy = "DEEP" /* DEEP */]) => (0, import_mergeWith.default)({}, ...values, (x, y) => {
  switch (strategy) {
    case "DEEP" /* DEEP */:
      return (0, import_isPlainObject3.default)(x) && (0, import_isPlainObject3.default)(y) ? merge([x, y], strategy) : x === void 0 ? y : x;
    case "DEEP_APPEND" /* DEEP_APPEND */:
    case "DEEP_PREPEND" /* DEEP_PREPEND */:
      return (0, import_isArray4.default)(x) && (0, import_isArray4.default)(y) ? (0, import_uniq.default)(
        strategy === "DEEP_APPEND" /* DEEP_APPEND */ ? [...y, ...x] : [...x, ...y]
      ) : (0, import_isPlainObject3.default)(x) && (0, import_isPlainObject3.default)(y) ? merge([x, y], strategy) : x === void 0 ? y : x;
    default:
      return x === void 0 ? y : x;
  }
}), "merge");

// ../lib-config/src/core/utils/defineConfig/defineConfig.ts
var getConfigs = /* @__PURE__ */ __name(({
  config: config4,
  overrides,
  strategy
}) => merge(
  [
    ...overrides ? (0, import_isFunction2.default)(overrides) ? overrides() : overrides : [],
    (0, import_isFunction2.default)(config4) ? config4() : config4
  ],
  strategy
), "getConfigs");
var defineConfig = /* @__PURE__ */ __name(({
  _config: _config4,
  config: config4,
  overrides,
  strategy = "DEEP_PREPEND" /* DEEP_PREPEND */
}) => ({
  _config: _config4 ? (0, import_isFunction2.default)(config4) ? (params) => _config4(
    getConfigs({
      config: config4,
      overrides: [
        params,
        ...overrides ? overrides() : []
      ],
      strategy
    })
  ) : _config4(getConfigs({ config: config4, overrides, strategy })) : void 0,
  config: (0, import_isFunction2.default)(config4) ? () => getConfigs({ config: config4, overrides, strategy }) : getConfigs({ config: config4, overrides, strategy })
}), "defineConfig");

// ../lib-config/src/database/_database.ts
var _database = /* @__PURE__ */ __name(({
  database,
  entities,
  host,
  password,
  pool,
  type,
  username
}) => {
  const config4 = {
    clientUrl: host,
    dbName: database,
    debug: true,
    ensureIndexes: true,
    entities,
    pool: { max: pool.max, min: 0 },
    type
  };
  if (username && password) {
    config4.user = username;
    config4.password = password;
  }
  return config4;
}, "_database");

// ../lib-backend/src/resource/utils/withEmbeddedResourceField/withEmbeddedResourceField.ts
var withEmbeddedResourceField = /* @__PURE__ */ __name(({
  Resource,
  isRepository = true,
  root: root2
}) => (target, propertyKey) => withField({
  Resource,
  isArray: true,
  isOptional: true,
  isRepository,
  relation: "oneToMany" /* ONE_TO_MANY */,
  root: root2,
  type: "resource" /* RESOURCE */
})(target, propertyKey), "withEmbeddedResourceField");

// ../lib-shared/src/admin/resources/Utility/Utility.constants.ts
var UTILITY_RESOURCE_NAME = "Utility";

// ../lib-shared/src/admin/resources/Vendor/Vendor.constants.ts
var VENDOR_RESOURCE_NAME = "Vendor";

// ../lib-backend/src/admin/resources/Vendor/Vendor.ts
var _a2;
var _b2;
var Vendor = class Vendor2 extends EntityResource {
  static {
    __name(this, "Vendor");
  }
  [_b2 = UTILITY_RESOURCE_NAME];
  imageSrc;
  name;
};
__decorate([
  withEmbeddedResourceField({ Resource: () => Utility, root: VENDOR_RESOURCE_NAME }),
  __metadata("design:type", typeof (_a2 = typeof Array !== "undefined" && Array) === "function" ? _a2 : Object)
], Vendor.prototype, _b2, void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Vendor.prototype, "imageSrc", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Vendor.prototype, "name", void 0);
Vendor = __decorate([
  withEntity({ isRepository: true, name: VENDOR_RESOURCE_NAME })
], Vendor);
var VendorForm = class VendorForm2 {
  static {
    __name(this, "VendorForm");
  }
};
VendorForm = __decorate([
  withEntity({ name: `${VENDOR_RESOURCE_NAME}Form` })
], VendorForm);

// ../lib-backend/src/resource/resources/EmbeddedResource/EmbeddedResource.ts
var import_mongodb4 = require("@mikro-orm/mongodb");
var _a3;
var EmbeddedResource = class EmbeddedResource2 extends EntityResource {
  static {
    __name(this, "EmbeddedResource");
  }
  async beforeCreate() {
    this._id = this._id ?? new import_mongodb4.ObjectId();
    this.created = this.created ?? /* @__PURE__ */ new Date();
    return super.beforeCreate();
  }
};
__decorate([
  withHook({ type: "BEFORE_CREATE" /* BEFORE_CREATE */ }),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", []),
  __metadata("design:returntype", typeof (_a3 = typeof Promise !== "undefined" && Promise) === "function" ? _a3 : Object)
], EmbeddedResource.prototype, "beforeCreate", null);
EmbeddedResource = __decorate([
  withEntity({ isAbstract: true, isEmbeddable: true })
], EmbeddedResource);

// ../lib-backend/src/resource/utils/withEmbeddableRootField/withEmbeddableRootField.ts
var withEmbeddableRootField = /* @__PURE__ */ __name(({
  Resource,
  name
}) => (target, propertyKey) => withField({
  Resource,
  isRepository: true,
  name,
  relation: "manyToOne" /* MANY_TO_ONE */,
  type: "resource" /* RESOURCE */
})(target, propertyKey), "withEmbeddableRootField");

// ../lib-backend/src/admin/resources/Utility/Utility.ts
var _a4;
var Utility = class Utility2 extends EmbeddedResource {
  static {
    __name(this, "Utility");
  }
  [_a4 = VENDOR_RESOURCE_NAME];
  description;
  name;
  type;
  usage;
};
__decorate([
  withEmbeddableRootField({ Resource: () => Vendor }),
  __metadata("design:type", Object)
], Utility.prototype, _a4, void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Utility.prototype, "description", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Utility.prototype, "name", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], Utility.prototype, "type", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], Utility.prototype, "usage", void 0);
Utility = __decorate([
  withEntity({ isEmbeddable: true, isRepository: true, name: UTILITY_RESOURCE_NAME })
], Utility);

// ../lib-backend/src/auth/resources/Access/Access.ts
var import_core6 = require("@mikro-orm/core");

// ../lib-shared/src/group/resources/Group/Group.constants.ts
var GROUP_RESOURCE_NAME = "Group";

// ../lib-backend/src/group/resources/Group/Group.ts
var _a5;
var Group = class Group2 extends EntityResource {
  static {
    __name(this, "Group");
  }
  name;
  types;
  logo;
};
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Group.prototype, "name", void 0);
__decorate([
  withField({ isArray: true, isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", typeof (_a5 = typeof Array !== "undefined" && Array) === "function" ? _a5 : Object)
], Group.prototype, "types", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Group.prototype, "logo", void 0);
Group = __decorate([
  withEntity({ isRepository: true, name: GROUP_RESOURCE_NAME })
], Group);

// ../lib-shared/src/billing/resources/Bank/Bank.constants.ts
var BANK_RESOURCE_NAME = "Bank";

// ../lib-shared/src/billing/resources/PaymentMethod/PaymentMethod.constants.ts
var PAYMENT_METHOD_RESOURCE_NAME = "PaymentMethod";
var PAYMENT_METHOD_TYPE = /* @__PURE__ */ ((PAYMENT_METHOD_TYPE2) => {
  PAYMENT_METHOD_TYPE2["BANK"] = "bank";
  PAYMENT_METHOD_TYPE2["CARD"] = "card";
  return PAYMENT_METHOD_TYPE2;
})(PAYMENT_METHOD_TYPE || {});

// ../lib-backend/src/billing/resources/Bank/Bank.ts
var _a6;
var _b3;
var Bank = class Bank2 extends EmbeddedResource {
  static {
    __name(this, "Bank");
  }
  [_a6 = USER_RESOURCE_NAME];
  externalId;
  last4;
  name;
  type;
};
__decorate([
  withEmbeddableRootField({ Resource: () => User }),
  __metadata("design:type", Object)
], Bank.prototype, _a6, void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Bank.prototype, "externalId", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Bank.prototype, "last4", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Bank.prototype, "name", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", typeof (_b3 = typeof PAYMENT_METHOD_TYPE !== "undefined" && "bank" /* BANK */) === "function" ? _b3 : Object)
], Bank.prototype, "type", void 0);
Bank = __decorate([
  withEntity({ isRepository: true, name: BANK_RESOURCE_NAME })
], Bank);

// ../lib-shared/src/billing/resources/Card/Card.constants.ts
var CARD_RESOURCE_NAME = "Card";

// ../lib-backend/src/billing/resources/Card/Card.ts
var _a7;
var _b4;
var Card = class Card2 extends EmbeddedResource {
  static {
    __name(this, "Card");
  }
  [_a7 = USER_RESOURCE_NAME];
  expMonth;
  expYear;
  externalId;
  funding;
  last4;
  name;
  type;
};
__decorate([
  withEmbeddableRootField({ Resource: () => User }),
  __metadata("design:type", Object)
], Card.prototype, _a7, void 0);
__decorate([
  withField({ isRepository: true, type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Card.prototype, "expMonth", void 0);
__decorate([
  withField({ isRepository: true, type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Card.prototype, "expYear", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Card.prototype, "externalId", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], Card.prototype, "funding", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Card.prototype, "last4", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Card.prototype, "name", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", typeof (_b4 = typeof PAYMENT_METHOD_TYPE !== "undefined" && "card" /* CARD */) === "function" ? _b4 : Object)
], Card.prototype, "type", void 0);
Card = __decorate([
  withEntity({ isRepository: true, name: CARD_RESOURCE_NAME })
], Card);

// ../lib-backend/src/billing/resources/PaymentMethod/PaymentMethod.ts
var _a8;
var PaymentMethod = class PaymentMethod2 extends EmbeddedResource {
  static {
    __name(this, "PaymentMethod");
  }
  [_a8 = USER_RESOURCE_NAME];
  externalId;
  last4;
  name;
  type;
};
__decorate([
  withEmbeddableRootField({ Resource: () => User }),
  __metadata("design:type", Object)
], PaymentMethod.prototype, _a8, void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], PaymentMethod.prototype, "externalId", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], PaymentMethod.prototype, "last4", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], PaymentMethod.prototype, "name", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], PaymentMethod.prototype, "type", void 0);
PaymentMethod = __decorate([
  withEntity({ name: PAYMENT_METHOD_RESOURCE_NAME })
], PaymentMethod);

// ../lib-backend/src/resource/utils/Collection/_Collection.ts
var import_core5 = require("@mikro-orm/core");
var _Collection = class extends import_core5.Collection {
  static {
    __name(this, "_Collection");
  }
};

// ../lib-backend/src/resource/utils/Collection/Collection.ts
var Collection2 = class extends _Collection {
  static {
    __name(this, "Collection");
  }
};

// ../lib-shared/src/user/resources/LinkedUser/LinkedUser.constants.ts
var LINKED_USER_RESOURCE_NAME = "linkedUser";

// ../lib-backend/src/user/resources/LinkedUser/LinkedUser.ts
var _a9;
var LinkedUser = class LinkedUser2 extends EmbeddedResource {
  static {
    __name(this, "LinkedUser");
  }
  [_a9 = USER_RESOURCE_NAME];
  externalId;
  type;
};
__decorate([
  withEmbeddableRootField({ Resource: () => User }),
  __metadata("design:type", Object)
], LinkedUser.prototype, _a9, void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], LinkedUser.prototype, "externalId", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], LinkedUser.prototype, "type", void 0);
LinkedUser = __decorate([
  withEntity({ isRepository: true, name: LINKED_USER_RESOURCE_NAME })
], LinkedUser);

// ../lib-shared/src/auth/resources/Access/Access.constants.ts
var ACCESS_RESOURCE_NAME = "Access";

// ../lib-backend/src/user/resources/User/User.ts
var _a10;
var _b5;
var _c;
var _d;
var _e;
var _f;
var _g;
var _h;
var _j;
var User = class User2 extends EntityResource {
  static {
    __name(this, "User");
  }
  [_a10 = ACCESS_RESOURCE_NAME] = new Collection2(this);
  [_c = BANK_RESOURCE_NAME];
  [_e = CARD_RESOURCE_NAME];
  [_g = LINKED_USER_RESOURCE_NAME];
  [_j = PAYMENT_METHOD_RESOURCE_NAME];
  callingCode;
  email;
  paymentMethodPrimary;
  phone;
  first;
  last;
};
__decorate([
  withEmbeddedResourceField({ Resource: () => Access, root: USER_RESOURCE_NAME }),
  __metadata("design:type", Object)
], User.prototype, _a10, void 0);
__decorate([
  withEmbeddedResourceField({ Resource: () => Bank, root: USER_RESOURCE_NAME }),
  __metadata("design:type", typeof (_b5 = typeof Array !== "undefined" && Array) === "function" ? _b5 : Object)
], User.prototype, _c, void 0);
__decorate([
  withEmbeddedResourceField({ Resource: () => Card, root: USER_RESOURCE_NAME }),
  __metadata("design:type", typeof (_d = typeof Array !== "undefined" && Array) === "function" ? _d : Object)
], User.prototype, _e, void 0);
__decorate([
  withEmbeddedResourceField({ Resource: () => LinkedUser, root: USER_RESOURCE_NAME }),
  __metadata("design:type", typeof (_f = typeof Array !== "undefined" && Array) === "function" ? _f : Object)
], User.prototype, _g, void 0);
__decorate([
  withEmbeddedResourceField({ Resource: () => PaymentMethod, root: USER_RESOURCE_NAME }),
  __metadata("design:type", typeof (_h = typeof Array !== "undefined" && Array) === "function" ? _h : Object)
], User.prototype, _j, void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "callingCode", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, isUnique: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "email", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "paymentMethodPrimary", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, isUnique: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "phone", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "first", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], User.prototype, "last", void 0);
User = __decorate([
  withEntity({ indices: [["email"], ["phone"]], isRepository: true, name: USER_RESOURCE_NAME })
], User);

// ../lib-backend/src/auth/resources/Access/Access.ts
var _a11;
var _b6;
var _c2;
var _d2;
var _e2;
var Access = class Access2 extends EntityResource {
  static {
    __name(this, "Access");
  }
  [import_core6.PrimaryKeyProp];
  [import_core6.PrimaryKeyType];
  [_b6 = GROUP_RESOURCE_NAME];
  [_d2 = USER_RESOURCE_NAME];
  role;
};
__decorate([
  withField({
    Resource: () => Group,
    isRepository: true,
    name: GROUP_RESOURCE_NAME,
    relation: "manyToOne" /* MANY_TO_ONE */,
    type: "resource" /* RESOURCE */
  }),
  __metadata("design:type", typeof (_a11 = typeof import_core6.Ref !== "undefined" && import_core6.Ref) === "function" ? _a11 : Object)
], Access.prototype, _b6, void 0);
__decorate([
  withField({
    Resource: () => User,
    isRepository: true,
    name: USER_RESOURCE_NAME,
    relation: "manyToOne" /* MANY_TO_ONE */,
    type: "resource" /* RESOURCE */
  }),
  __metadata("design:type", typeof (_c2 = typeof import_core6.Ref !== "undefined" && import_core6.Ref) === "function" ? _c2 : Object)
], Access.prototype, _d2, void 0);
__decorate([
  withField({ isArray: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", typeof (_e2 = typeof Array !== "undefined" && Array) === "function" ? _e2 : Object)
], Access.prototype, "role", void 0);
Access = __decorate([
  withEntity({ isRepository: true, name: ACCESS_RESOURCE_NAME })
], Access);

// ../lib-backend/src/auth/resources/Otp/Otp.constants.ts
var OTP_EXPIRATION_SECONDS = 60 * 5;

// ../lib-backend/src/resource/utils/withAccess/withAccess.ts
var import_type_graphql3 = require("type-graphql");

// ../lib-shared/src/core/utils/withCondition/withCondition.ts
var import_isArray5 = __toESM(require("lodash/isArray"));
var withCondition = /* @__PURE__ */ __name((...[condition, ifTrue]) => (...params) => {
  if (condition()) {
    const decorators = ifTrue();
    return (0, import_isArray5.default)(decorators) ? decorators.forEach(
      (decorator) => decorator(...params)
    ) : decorators(...params);
  }
}, "withCondition");

// ../lib-backend/src/resource/utils/withAccess/withAccess.ts
var getAccessRole = /* @__PURE__ */ __name((level) => {
  switch (level) {
    case "PROHIBITED" /* PROHIBITED */:
      return [];
    case "RESTRICTED" /* RESTRICTED */:
      return ["Admin" /* ADMIN */];
    case "PROTECTED" /* PROTECTED */:
      return ["User" /* USER */];
    default:
      return ["Any" /* ANY */];
  }
}, "getAccessRole");
var withAccess = /* @__PURE__ */ __name(({
  level = "PUBLIC" /* PUBLIC */
}) => withCondition(
  () => level !== "PUBLIC" /* PUBLIC */,
  () => (0, import_type_graphql3.Authorized)(getAccessRole(level))
), "withAccess");

// ../lib-shared/src/auth/resources/Otp/Otp.constants.ts
var OTP_RESOURCE_NAME = "Otp";
var OTP_IF_DOES_NOT_EXIST = `${OTP_RESOURCE_NAME}IfDoesNotExist`;

// ../lib-backend/src/auth/resources/Otp/Otp.ts
var _a12;
var OtpForm = class OtpForm2 {
  static {
    __name(this, "OtpForm");
  }
  callingCode;
  checkExists;
  email;
  phone;
};
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], OtpForm.prototype, "callingCode", void 0);
__decorate([
  withField({ type: "boolean" /* BOOLEAN */ }),
  __metadata("design:type", Boolean)
], OtpForm.prototype, "checkExists", void 0);
__decorate([
  withField({ isRepository: true, isUnique: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], OtpForm.prototype, "email", void 0);
__decorate([
  withField({ isRepository: true, isUnique: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], OtpForm.prototype, "phone", void 0);
OtpForm = __decorate([
  withEntity({ name: `${OTP_RESOURCE_NAME}Form` })
], OtpForm);
var Otp = class Otp2 extends EntityResource {
  static {
    __name(this, "Otp");
  }
  callingCode;
  email;
  otp;
  phone;
};
__decorate([
  withField({
    defaultValue: () => /* @__PURE__ */ new Date(),
    expire: OTP_EXPIRATION_SECONDS,
    isRepository: true,
    type: "date" /* DATE */
  }),
  __metadata("design:type", typeof (_a12 = typeof Date !== "undefined" && Date) === "function" ? _a12 : Object)
], Otp.prototype, "created", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Otp.prototype, "callingCode", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Otp.prototype, "email", void 0);
__decorate([
  withAccess({ level: "PROHIBITED" /* PROHIBITED */ }),
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Otp.prototype, "otp", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Otp.prototype, "phone", void 0);
Otp = __decorate([
  withEntity({ indices: [["email"], ["phone"]], isRepository: true, name: OTP_RESOURCE_NAME })
], Otp);

// ../lib-shared/src/chat/resources/Chat/Chat.constants.ts
var CHAT_RESOURCE_NAME = "Chat";

// ../lib-backend/src/chat/resources/Chat/Chat.ts
var Chat = class Chat2 extends EntityResource {
  static {
    __name(this, "Chat");
  }
  name;
};
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Chat.prototype, "name", void 0);
Chat = __decorate([
  withEntity({ isRepository: true, name: CHAT_RESOURCE_NAME })
], Chat);

// ../lib-shared/src/test/resources/TestableEntityResource/TestableEntityResource.constants.ts
var TESTABLE_ENTITY_RESOURCE_RESOURCE_NAME = "TestableEntityResource";

// ../lib-backend/src/test/resources/TestableEntityResource/TestableEntityResource.ts
var _a13;
var _b7;
var TestableEntityResource = class TestableEntityResource2 extends EntityResource {
  static {
    __name(this, "TestableEntityResource");
  }
  dateTtlProperty;
  numberProperty;
  stringArrayField;
  stringField;
  stringFieldOptional;
};
__decorate([
  withField({
    defaultValue: () => /* @__PURE__ */ new Date(),
    expire: OTP_EXPIRATION_SECONDS,
    isOptional: true,
    isRepository: true,
    type: "date" /* DATE */
  }),
  __metadata("design:type", typeof (_a13 = typeof Date !== "undefined" && Date) === "function" ? _a13 : Object)
], TestableEntityResource.prototype, "dateTtlProperty", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], TestableEntityResource.prototype, "numberProperty", void 0);
__decorate([
  withField({ isArray: true, isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", typeof (_b7 = typeof Array !== "undefined" && Array) === "function" ? _b7 : Object)
], TestableEntityResource.prototype, "stringArrayField", void 0);
__decorate([
  withField({ isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], TestableEntityResource.prototype, "stringField", void 0);
__decorate([
  withField({ isOptional: true, isRepository: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], TestableEntityResource.prototype, "stringFieldOptional", void 0);
TestableEntityResource = __decorate([
  withEntity({ isRepository: true, name: TESTABLE_ENTITY_RESOURCE_RESOURCE_NAME })
], TestableEntityResource);

// ../lib-config/src/database/database.base.ts
var { _config, config } = defineConfig({
  _config: _database,
  config: () => ({
    entities: filterNil([
      Access,
      Bank,
      Card,
      Chat,
      LinkedUser,
      Group,
      Otp,
      Socket,
      User,
      Utility,
      Vendor,
      TestableEntityResource
    ]),
    pool: { max: 10 }
  })
});

// ../lib-config/src/database/database.mongo.ts
var { _config: _config2, config: config2 } = defineConfig({
  _config: _database,
  config,
  overrides: () => [
    {
      database: "development",
      host: "mongodb+srv://admin:AOJQET44fUQMbLXE@cluster0.w6g4b.mongodb.net",
      password: "AOJQET44fUQMbLXE",
      type: "mongo" /* MONGO */,
      username: "admin"
    }
  ]
});

// ../lib-backend/src/setup/utils/initialize/initialize.ts
var initialize = /* @__PURE__ */ __name(async () => {
  const database = new Database(_config2());
  await database.connect();
  _Container.set(Database, database, "mongo" /* MONGO */);
  return { database };
}, "initialize");

// ../lib-backend/src/admin/resources/Vendor/VendorService/VendorService.ts
var VendorService = class VendorService2 extends createEntityResourceService({
  Resource: Vendor,
  name: VENDOR_RESOURCE_NAME
}) {
  static {
    __name(this, "VendorService");
  }
};
VendorService = __decorate([
  withContainer({ name: `${VENDOR_RESOURCE_NAME}Service` })
], VendorService);

// ../lib-shared/src/core/utils/flattenObject/flattenObject.ts
var import_isArray6 = __toESM(require("lodash/isArray"));
var import_isPlainObject4 = __toESM(require("lodash/isPlainObject"));
var import_reduce2 = __toESM(require("lodash/reduce"));
var import_some = __toESM(require("lodash/some"));
var flattenObject = /* @__PURE__ */ __name((...[value, { delimiter = ".", path = [], prefixes = ["$"] } = {}]) => (0, import_isPlainObject4.default)(value) ? (0, import_reduce2.default)(
  value,
  (result, v, k) => (0, import_isArray6.default)(v) ? {
    ...result,
    [k]: v.map(
      (vv) => flattenObject(vv, { delimiter, path, prefixes })
    )
  } : (0, import_some.default)(prefixes, (prefix) => k.startsWith(prefix)) ? { ...result, [[...path, k].join(delimiter)]: v } : {
    ...result,
    ...flattenObject(v, { delimiter, path: [...path, k], prefixes })
  },
  {}
) : path.length ? { [path.join(delimiter)]: value } : value, "flattenObject");

// ../lib-backend/src/resource/utils/createEmbeddedResourceService/createEmbeddedResourceService.ts
var import_forEach2 = __toESM(require("lodash/forEach"));
var import_reduce3 = __toESM(require("lodash/reduce"));
var createEmbeddedResourceService = /* @__PURE__ */ __name(({
  Resource,
  RootService,
  afterCreate,
  afterCreateMany,
  afterGet,
  afterGetConnection,
  afterGetMany,
  afterRemove,
  afterUpdate,
  beforeCreate,
  beforeCreateMany,
  beforeGet,
  beforeGetConnection,
  beforeGetMany,
  beforeRemove,
  beforeUpdate,
  name
}) => {
  let rootService;
  const getRootService = /* @__PURE__ */ __name(() => {
    rootService = rootService ?? _Container.get(RootService);
    return rootService;
  }, "getRootService");
  const getForm = /* @__PURE__ */ __name(async (form) => {
    const formF = new Resource();
    (0, import_forEach2.default)(form, (v, k) => formF[k] = v);
    formF.beforeCreate && formF.beforeCreate();
    return formF;
  }, "getForm");
  const getAggregation = /* @__PURE__ */ __name((input = {}) => {
    const nameF = `$${name}`;
    return filterNil([
      { $unwind: nameF },
      { $match: getFilter(input.filter, name) },
      input.options?.project && { $project: flattenObject({ [name]: input.options.project }) },
      { $group: { _id: "$_id", [name]: { $push: nameF } } }
    ]);
  }, "getAggregation");
  const getCount = /* @__PURE__ */ __name(async (input) => {
    if (input.root) {
      const { result: rootResult } = await getRootService().get({
        filter: [{ field: "_id", value: input.root }]
      });
      const result = rootResult && rootResult[name];
      return result?.length || 0;
    }
    throw new InvalidArgumentError("root");
  }, "getCount");
  const getMany = /* @__PURE__ */ __name(async (input = {}) => {
    if (input.root) {
      const skip = input.options?.skip ?? 0;
      const limit = input.options?.take;
      const { result: rootResult } = await getRootService().get({
        filter: [{ field: "_id", value: input.root }],
        options: input.filter ? { aggregate: getAggregation(input) } : void 0
      });
      const result = (rootResult && rootResult[name]) ?? [];
      return {
        result: (skip || limit) && result?.length ? result.slice(skip, limit ? skip + (limit || 0) : void 0) : result,
        root: rootResult
      };
    }
    throw new InvalidArgumentError("root");
  }, "getMany");
  return createResourceService({
    Resource,
    afterCreate,
    afterCreateMany,
    afterGet,
    afterGetConnection,
    afterGetMany,
    afterRemove,
    afterUpdate,
    beforeCreate,
    beforeCreateMany,
    beforeGet,
    beforeGetConnection,
    beforeGetMany,
    beforeRemove,
    beforeUpdate,
    count: getCount,
    create: async (input = {}) => {
      if (input.root) {
        const formF = await getForm(input.form);
        const { result: rootResult } = await getRootService().update({
          filter: [{ field: "_id", value: input.root }],
          update: { $push: { [name]: formF } }
        });
        return { result: formF, root: rootResult };
      }
      throw new InvalidArgumentError("root");
    },
    createMany: async (input = {}) => {
      if (input.root && input.form) {
        const formF = await Promise.all(input.form.map((value) => getForm(value)));
        const { result: rootResult } = await getRootService().update({
          filter: [{ field: "_id", value: input.root }],
          update: { $push: { [name]: { $each: formF } } }
        });
        return { result: formF, root: rootResult };
      }
      throw new InvalidArgumentError("root");
    },
    get: async (input = {}) => {
      if (input.root) {
        const { result: rootResult } = await getRootService().get({
          filter: [{ field: "_id", value: input.root }],
          options: { aggregate: getAggregation(input) }
        });
        const result = rootResult && rootResult[name];
        return { result: result && result[0], root: rootResult };
      }
      throw new InvalidArgumentError("root");
    },
    getConnection: async (input = {}) => {
      if (input.root) {
        return getConnection({
          count: await getCount(input),
          getMany: getMany.bind(void 0),
          input,
          pagination: input.pagination
        });
      }
      throw new InvalidArgumentError("root");
    },
    getMany,
    name,
    remove: async (input = {}) => {
      const { result: rootResult } = await getRootService().update({
        filter: [{ field: "_id", value: input.root }],
        update: { $pull: { [name]: getFilter(input.filter) } }
      });
      return { root: rootResult };
    },
    update: async (input = {}) => {
      const { result: rootResult } = await getRootService().update({
        filter: [
          { field: "_id", value: input.root },
          ...(input.filter ?? []).map(
            (filter) => ({ ...filter, field: `${name}.${filter.field}` })
          )
        ],
        options: {
          project: {
            [name]: { $elemMatch: getFilter(input.filter) }
          }
        },
        update: (0, import_reduce3.default)(
          input.update,
          (result2, v, k) => ({
            ...result2,
            ...k.startsWith("$") ? { [k]: { [`${name}.$`]: v } } : { [`${name}.$.${k}`]: v }
          }),
          {}
        )
      });
      const result = rootResult && rootResult[name];
      let resultF = result?.length ? result[0] : void 0;
      if (resultF && input.options?.project) {
        resultF = pick2(
          resultF,
          Object.keys(input.options.project)
        );
      }
      return { result: resultF, root: rootResult };
    }
  });
}, "createEmbeddedResourceService");

// ../lib-backend/src/admin/resources/Utility/UtilityService/UtilityService.ts
var UtilityService = class UtilityService2 extends createEmbeddedResourceService({
  Resource: Utility,
  RootService: VendorService,
  name: UTILITY_RESOURCE_NAME
}) {
  static {
    __name(this, "UtilityService");
  }
};
UtilityService = __decorate([
  withContainer()
], UtilityService);

// ../lib-backend/src/http/utils/withResolver/_withResolver.ts
var import_type_graphql4 = require("type-graphql");
function _withResolver({
  Resource
} = {}) {
  return (target) => {
    if (Resource) {
      return (0, import_type_graphql4.Resolver)(Resource)(target);
    }
    return (0, import_type_graphql4.Resolver)()(target);
  };
}
__name(_withResolver, "_withResolver");

// ../lib-backend/src/http/utils/withResolver/withResolver.ts
var withResolver = /* @__PURE__ */ __name((params = {}) => _withResolver(params), "withResolver");

// ../lib-backend/src/http/utils/withContext/_withContext.ts
var import_type_graphql5 = require("type-graphql");
var _withContext = /* @__PURE__ */ __name(() => (target, propertyKey, parameterIndex) => (0, import_type_graphql5.Ctx)()(target, propertyKey, parameterIndex), "_withContext");

// ../lib-shared/src/auth/errors/UnauthorizedError/UnauthorizedError.ts
var UnauthorizedError = class extends HttpError {
  static {
    __name(this, "UnauthorizedError");
  }
  constructor(message) {
    super(HTTP_STATUS_CODE.UNAUTHORIZED, message ?? "unauthorized");
  }
};

// ../lib-backend/src/resource/utils/withAuthorizer/withAuthorizer.ts
var withAuthorizer = /* @__PURE__ */ __name(({
  authorizer
}) => (_target, _propertyKey, descriptor) => {
  if (authorizer) {
    const original = descriptor.value;
    descriptor.value = async function(input, context) {
      if (authorizer({ context, input })) {
        return original.apply(this, [input, context]);
      }
      throw new UnauthorizedError();
    };
    return descriptor;
  }
  return descriptor;
}, "withAuthorizer");

// ../lib-backend/src/resource/utils/createFilter/createFilter.ts
var createFilter = /* @__PURE__ */ __name(({ Resource, name }) => {
  var _a21, _b12, _c7;
  let Filter = class Filter {
    static {
      __name(this, "Filter");
    }
    booleanValue;
    condition;
    dateValue;
    field;
    resourceArrayValue;
    resourceValue;
    numberValue;
    stringArrayValue;
    stringValue;
    value;
  };
  __decorate([
    withField({ type: "boolean" /* BOOLEAN */ }),
    __metadata("design:type", Boolean)
  ], Filter.prototype, "booleanValue", void 0);
  __decorate([
    withField({ type: "string" /* STRING */ }),
    __metadata("design:type", Object)
  ], Filter.prototype, "condition", void 0);
  __decorate([
    withField({ type: "date" /* DATE */ }),
    __metadata("design:type", typeof (_a21 = typeof Date !== "undefined" && Date) === "function" ? _a21 : Object)
  ], Filter.prototype, "dateValue", void 0);
  __decorate([
    withField({ type: "string" /* STRING */ }),
    __metadata("design:type", Object)
  ], Filter.prototype, "field", void 0);
  __decorate([
    withField({ Resource, isArray: true, type: "resource" /* RESOURCE */ }),
    __metadata("design:type", typeof (_b12 = typeof Array !== "undefined" && Array) === "function" ? _b12 : Object)
  ], Filter.prototype, "resourceArrayValue", void 0);
  __decorate([
    withField({ Resource, type: "resource" /* RESOURCE */ }),
    __metadata("design:type", Object)
  ], Filter.prototype, "resourceValue", void 0);
  __decorate([
    withField({ type: "number" /* NUMBER */ }),
    __metadata("design:type", Number)
  ], Filter.prototype, "numberValue", void 0);
  __decorate([
    withField({ isArray: true, type: "string" /* STRING */ }),
    __metadata("design:type", typeof (_c7 = typeof Array !== "undefined" && Array) === "function" ? _c7 : Object)
  ], Filter.prototype, "stringArrayValue", void 0);
  __decorate([
    withField({ type: "string" /* STRING */ }),
    __metadata("design:type", String)
  ], Filter.prototype, "stringValue", void 0);
  Filter = __decorate([
    withEntity({ name: `${name}Filter` })
  ], Filter);
  return Filter;
}, "createFilter");

// ../lib-backend/src/resource/utils/createForm/createForm.ts
var createForm = /* @__PURE__ */ __name(({ Resource, name }) => {
  let FormF = class FormF extends Resource() {
    static {
      __name(this, "FormF");
    }
  };
  FormF = __decorate([
    withEntity({ name: `${name}Form` })
  ], FormF);
  return FormF;
}, "createForm");

// ../lib-backend/src/resource/utils/createUpdate/createUpdate.ts
var createUpdate = /* @__PURE__ */ __name(({ Resource, name }) => {
  let Update = class Update extends Resource() {
    static {
      __name(this, "Update");
    }
  };
  Update = __decorate([
    withEntity({ name: `${name}Update` })
  ], Update);
  return Update;
}, "createUpdate");

// ../lib-backend/src/resource/utils/Pagination/Pagination.ts
var Pagination = class Pagination2 {
  static {
    __name(this, "Pagination");
  }
  before;
  after;
  first;
  last;
};
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Pagination.prototype, "before", void 0);
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Pagination.prototype, "after", void 0);
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Pagination.prototype, "first", void 0);
__decorate([
  withField({ isOptional: true, type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Pagination.prototype, "last", void 0);
Pagination = __decorate([
  withEntity({ name: "Pagination" })
], Pagination);

// ../lib-shared/src/core/errors/InvalidTypeError/InvalidTypeError.ts
var InvalidTypeError = class extends Error {
  static {
    __name(this, "InvalidTypeError");
  }
  constructor(actual, expected) {
    super(`input type: ${typeof actual} (actual) vs ${expected} (expected)`);
  }
};

// ../lib-shared/src/resource/resource.constants.ts
var RESOURCE_METHOD_TYPE = /* @__PURE__ */ ((RESOURCE_METHOD_TYPE2) => {
  RESOURCE_METHOD_TYPE2["CREATE"] = "Create";
  RESOURCE_METHOD_TYPE2["CREATE_MANY"] = "CreateMany";
  RESOURCE_METHOD_TYPE2["GET"] = "Get";
  RESOURCE_METHOD_TYPE2["GET_CONNECTION"] = "GetConnection";
  RESOURCE_METHOD_TYPE2["GET_MANY"] = "GetMany";
  RESOURCE_METHOD_TYPE2["REMOVE"] = "Remove";
  RESOURCE_METHOD_TYPE2["UPDATE"] = "Update";
  return RESOURCE_METHOD_TYPE2;
})(RESOURCE_METHOD_TYPE || {});

// ../lib-backend/src/resource/utils/createArgs/createArgs.ts
var Root = class Root2 {
  static {
    __name(this, "Root");
  }
  root;
};
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], Root.prototype, "root", void 0);
Root = __decorate([
  withEntity({ isAbstract: true })
], Root);
var createArgs = /* @__PURE__ */ __name(({ Resource, method, name }) => {
  var _a21, _b12, _c7, _d4;
  const Filter = Resource && createFilter({ Resource, name });
  const Form = Resource && createForm({ Resource, name });
  switch (method) {
    case "Get" /* GET */:
    case "GetMany" /* GET_MANY */:
    case "Remove" /* REMOVE */: {
      let Args = class Args extends Root {
        static {
          __name(this, "Args");
        }
        filter;
      };
      __decorate([
        withCondition(() => !!Filter, () => withField({
          Resource: Filter ? () => Filter : void 0,
          isArray: true,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", typeof (_a21 = typeof Array !== "undefined" && Array) === "function" ? _a21 : Object)
      ], Args.prototype, "filter", void 0);
      Args = __decorate([
        withEntity({ isAbstract: true })
      ], Args);
      return Args;
    }
    case "Create" /* CREATE */: {
      let Args = class Args extends Root {
        static {
          __name(this, "Args");
        }
        form;
      };
      __decorate([
        withCondition(() => !!Form, () => withField({
          Resource: Form ? () => Form : void 0,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", Object)
      ], Args.prototype, "form", void 0);
      Args = __decorate([
        withEntity({ isAbstract: true })
      ], Args);
      return Args;
    }
    case "CreateMany" /* CREATE_MANY */: {
      let Args = class Args extends Root {
        static {
          __name(this, "Args");
        }
        form;
      };
      __decorate([
        withCondition(() => !!Form, () => withField({
          Resource: Form ? () => Form : void 0,
          isArray: true,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", typeof (_b12 = typeof Array !== "undefined" && Array) === "function" ? _b12 : Object)
      ], Args.prototype, "form", void 0);
      Args = __decorate([
        withEntity({ isAbstract: true })
      ], Args);
      return Args;
    }
    case "Update" /* UPDATE */: {
      const Update = Resource && createUpdate({ Resource, name });
      let Args = class Args extends Root {
        static {
          __name(this, "Args");
        }
        filter;
        update;
      };
      __decorate([
        withCondition(() => !!Filter, () => withField({
          Resource: Filter ? () => Filter : void 0,
          isArray: true,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", typeof (_c7 = typeof Array !== "undefined" && Array) === "function" ? _c7 : Object)
      ], Args.prototype, "filter", void 0);
      __decorate([
        withCondition(() => !!Update, () => withField({
          Resource: Update ? () => Update : void 0,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", Object)
      ], Args.prototype, "update", void 0);
      Args = __decorate([
        withEntity({ isAbstract: true })
      ], Args);
      return Args;
    }
    case "GetConnection" /* GET_CONNECTION */: {
      let Args = class Args extends Root {
        static {
          __name(this, "Args");
        }
        filter;
        pagination;
      };
      __decorate([
        withCondition(() => !!Filter, () => withField({
          Resource: Filter ? () => Filter : void 0,
          isArray: true,
          type: "resource" /* RESOURCE */
        })),
        __metadata("design:type", typeof (_d4 = typeof Array !== "undefined" && Array) === "function" ? _d4 : Object)
      ], Args.prototype, "filter", void 0);
      __decorate([
        withField({ Resource: () => Pagination, type: "resource" /* RESOURCE */ }),
        __metadata("design:type", Object)
      ], Args.prototype, "pagination", void 0);
      Args = __decorate([
        withEntity({ isAbstract: true })
      ], Args);
      return Args;
    }
    default:
      throw new InvalidTypeError(method, RESOURCE_METHOD_TYPE);
  }
}, "createArgs");

// ../lib-backend/src/resource/utils/createInput/createInput.ts
var createInput = /* @__PURE__ */ __name(({ Resource, method, name }) => {
  const Args = createArgs({ Resource, method, name });
  let Input = class Input extends Args {
    static {
      __name(this, "Input");
    }
  };
  Input = __decorate([
    withEntity({ name })
  ], Input);
  return Input;
}, "createInput");

// ../lib-backend/src/resource/utils/withParams/withParams.ts
var import_type_graphql6 = require("type-graphql");
var withParams = /* @__PURE__ */ __name(({ Resource }) => (0, import_type_graphql6.Arg)("input", Resource), "withParams");

// ../lib-backend/src/resource/utils/withInput/withInput.ts
var withInput = /* @__PURE__ */ __name(({
  Resource,
  method,
  name
}) => {
  const nameF = `${name}${method}`;
  const InputF = createInput({ Resource, method, name: nameF });
  return withParams({ Resource: () => InputF });
}, "withInput");

// ../lib-backend/src/resource/utils/createEdge/createEdge.ts
var createEdge = /* @__PURE__ */ __name(({ Resource, name }) => {
  let EdgeF = class EdgeF {
    static {
      __name(this, "EdgeF");
    }
    node;
    cursor;
  };
  __decorate([
    withField({ Resource, type: "resource" /* RESOURCE */ }),
    __metadata("design:type", Object)
  ], EdgeF.prototype, "node", void 0);
  __decorate([
    withField({ type: "string" /* STRING */ }),
    __metadata("design:type", String)
  ], EdgeF.prototype, "cursor", void 0);
  EdgeF = __decorate([
    withEntity({ name: `${name}Edge` })
  ], EdgeF);
  return EdgeF;
}, "createEdge");

// ../lib-backend/src/resource/utils/PageInfo/PageInfo.ts
var PageInfo = class PageInfo2 {
  static {
    __name(this, "PageInfo");
  }
  hasNextPage;
  hasPreviousPage;
  startCursor;
  endCursor;
};
__decorate([
  withField({ type: "boolean" /* BOOLEAN */ }),
  __metadata("design:type", Boolean)
], PageInfo.prototype, "hasNextPage", void 0);
__decorate([
  withField({ type: "boolean" /* BOOLEAN */ }),
  __metadata("design:type", Boolean)
], PageInfo.prototype, "hasPreviousPage", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], PageInfo.prototype, "startCursor", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], PageInfo.prototype, "endCursor", void 0);
PageInfo = __decorate([
  withEntity({ name: "PageInfo" })
], PageInfo);

// ../lib-backend/src/resource/utils/createConnection/createConnection.ts
var createConnection = /* @__PURE__ */ __name(({ Resource, name }) => {
  var _a21;
  const Edge = createEdge({ Resource, name });
  let ConnectionF = class ConnectionF {
    static {
      __name(this, "ConnectionF");
    }
    edges;
    pageInfo;
  };
  __decorate([
    withField({
      Resource: () => Edge,
      isArray: true,
      name: `${name}ConnectionEdges`,
      type: "resource" /* RESOURCE */
    }),
    __metadata("design:type", typeof (_a21 = typeof Array !== "undefined" && Array) === "function" ? _a21 : Object)
  ], ConnectionF.prototype, "edges", void 0);
  __decorate([
    withField({
      Resource: () => PageInfo,
      name: `${name}ConnectionPageInfo`,
      type: "resource" /* RESOURCE */
    }),
    __metadata("design:type", Object)
  ], ConnectionF.prototype, "pageInfo", void 0);
  ConnectionF = __decorate([
    withEntity({ name: `${name}Connection` })
  ], ConnectionF);
  return ConnectionF;
}, "createConnection");

// ../lib-backend/src/resource/utils/createRoot/createRoot.ts
var createRoot = /* @__PURE__ */ __name(({ RootResource, name }) => {
  if (RootResource) {
    let Root4 = class Root {
      static {
        __name(this, "Root");
      }
      root;
    };
    __decorate([
      withField({ Resource: RootResource, type: "resource" /* RESOURCE */ }),
      __metadata("design:type", Object)
    ], Root4.prototype, "root", void 0);
    Root4 = __decorate([
      withEntity({ name: `${name}Root` })
    ], Root4);
    return Root4;
  }
  return void 0;
}, "createRoot");

// ../lib-backend/src/resource/utils/createOutput/createOutput.ts
var createOutput = /* @__PURE__ */ __name(({ Resource, RootResource, method, name }) => {
  const nameF = `${name}Output`;
  const Root4 = createRoot({ RootResource, name: nameF });
  const Result = (method === "GetConnection" /* GET_CONNECTION */ ? createConnection({ Resource, name }) : Resource()) ?? Boolean;
  let Output = class Output extends (Root4 ?? class {
  }) {
    static {
      __name(this, "Output");
    }
    result;
  };
  __decorate([
    withField({
      Resource: () => Result,
      isArray: method === "GetMany" /* GET_MANY */,
      type: "resource" /* RESOURCE */
    }),
    __metadata("design:type", Object)
  ], Output.prototype, "result", void 0);
  Output = __decorate([
    withEntity({ name: nameF })
  ], Output);
  return Output;
}, "createOutput");

// ../lib-backend/src/resource/utils/withResult/withResult.ts
var import_type_graphql7 = require("type-graphql");
var withResult = /* @__PURE__ */ __name(({
  Resource,
  level = "PUBLIC" /* PUBLIC */,
  name,
  operation = "query" /* QUERY */
}) => (target, propertyKey, descriptor) => {
  withAccess({ level })(target, propertyKey, descriptor);
  (operation === "query" /* QUERY */ ? import_type_graphql7.Query : import_type_graphql7.Mutation)(Resource, {
    name
  })(target, propertyKey, descriptor);
}, "withResult");

// ../lib-backend/src/resource/utils/withOutput/withOutput.ts
var getOperation = /* @__PURE__ */ __name((method) => {
  switch (method) {
    case "Get" /* GET */:
    case "GetMany" /* GET_MANY */:
    case "GetConnection" /* GET_CONNECTION */:
      return "query" /* QUERY */;
    case "Create" /* CREATE */:
    case "CreateMany" /* CREATE_MANY */:
    case "Update" /* UPDATE */:
    case "Remove" /* REMOVE */:
      return "mutation" /* MUTATION */;
    default:
      throw new InvalidTypeError(method, RESOURCE_METHOD_TYPE);
  }
}, "getOperation");
var withOutput = /* @__PURE__ */ __name(({
  Resource,
  RootResource,
  level = "PUBLIC" /* PUBLIC */,
  method,
  name
}) => (target, propertyKey, descriptor) => {
  const nameF = `${name}${method}`;
  const OutputF = createOutput({ Resource, RootResource, method, name: nameF });
  withResult({
    Resource: () => OutputF ?? Boolean,
    level,
    name: nameF,
    operation: getOperation(method)
  })(target, propertyKey, descriptor);
}, "withOutput");

// ../lib-backend/src/resource/utils/createResourceResolver/createResourceResolver.ts
var createResourceResolver = /* @__PURE__ */ __name(({ Resource, ResourceData, ResourceService, RootResource, access = { default: "RESTRICTED" /* RESTRICTED */ }, authorizer, name }) => {
  var _a21, _b12, _c7, _d4, _e3, _f2, _g2;
  const { prototype } = ResourceService;
  const createExists = prototype.create !== void 0;
  const createManyExists = prototype.createMany !== void 0;
  const getExists = prototype.get !== void 0;
  const getManyExists = prototype.getMany !== void 0;
  const getConnectionExists = prototype.getConnection !== void 0;
  const updateExists = prototype.update !== void 0;
  const removeExists = prototype.remove !== void 0;
  let ResourceResolver = class ResourceResolver {
    static {
      __name(this, "ResourceResolver");
    }
    _service = _Container.get(ResourceService);
    async create(input = {}, context) {
      if (this._service.create) {
        return this._service.create(cleanObject2(input), context);
      }
      throw new NotImplementedError("Create" /* CREATE */);
    }
    async createMany(input = {}, context) {
      if (this._service.createMany) {
        return this._service.createMany(cleanObject2(input), context);
      }
      throw new NotImplementedError("CreateMany" /* CREATE_MANY */);
    }
    async get(input = {}, context) {
      if (this._service.get) {
        return this._service.get(cleanObject2(input), context);
      }
      throw new NotImplementedError("Get" /* GET */);
    }
    async getMany(input = {}, context) {
      if (this._service.getMany) {
        return this._service.getMany(cleanObject2(input), context);
      }
      throw new NotImplementedError("GetMany" /* GET_MANY */);
    }
    async getConnection(input = {}, context) {
      if (this._service.getConnection) {
        return this._service.getConnection(cleanObject2(input), context);
      }
      throw new NotImplementedError("GetConnection" /* GET_CONNECTION */);
    }
    async update(input = {}, context) {
      if (this._service.update) {
        return this._service.update(cleanObject2(input), context);
      }
      throw new NotImplementedError("Update" /* UPDATE */);
    }
    async remove(input = {}, context) {
      if (this._service.remove) {
        return this._service.remove(cleanObject2(input), context);
      }
      throw new NotImplementedError("Remove" /* REMOVE */);
    }
  };
  __decorate([
    withCondition(() => createExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.write ?? authorizer?.Create
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.write ?? access?.Create,
        method: "Create" /* CREATE */,
        name
      })
    ]),
    __param(0, withCondition(() => createExists, () => withInput({
      Resource: ResourceData ?? Resource,
      method: "Create" /* CREATE */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_a21 = typeof Promise !== "undefined" && Promise) === "function" ? _a21 : Object)
  ], ResourceResolver.prototype, "create", null);
  __decorate([
    withCondition(() => createManyExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.write ?? authorizer?.CreateMany
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.write ?? access?.CreateMany,
        method: "CreateMany" /* CREATE_MANY */,
        name
      })
    ]),
    __param(0, withCondition(() => createManyExists, () => withInput({
      Resource: ResourceData ?? Resource,
      method: "CreateMany" /* CREATE_MANY */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_b12 = typeof Promise !== "undefined" && Promise) === "function" ? _b12 : Object)
  ], ResourceResolver.prototype, "createMany", null);
  __decorate([
    withCondition(() => getExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.read ?? authorizer?.Get
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.read ?? access?.Get,
        method: "Get" /* GET */,
        name
      })
    ]),
    __param(0, withCondition(() => getExists, () => withInput({
      Resource,
      method: "Get" /* GET */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_c7 = typeof Promise !== "undefined" && Promise) === "function" ? _c7 : Object)
  ], ResourceResolver.prototype, "get", null);
  __decorate([
    withCondition(() => getManyExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.read ?? authorizer?.GetMany
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.read ?? access?.GetMany,
        method: "GetMany" /* GET_MANY */,
        name
      })
    ]),
    __param(0, withCondition(() => getManyExists, () => withInput({
      Resource,
      method: "GetMany" /* GET_MANY */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_d4 = typeof Promise !== "undefined" && Promise) === "function" ? _d4 : Object)
  ], ResourceResolver.prototype, "getMany", null);
  __decorate([
    withCondition(() => getConnectionExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.read ?? authorizer?.GetConnection
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.read ?? access?.GetConnection,
        method: "GetConnection" /* GET_CONNECTION */,
        name
      })
    ]),
    __param(0, withCondition(() => getConnectionExists, () => withInput({
      Resource,
      method: "GetConnection" /* GET_CONNECTION */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_e3 = typeof Promise !== "undefined" && Promise) === "function" ? _e3 : Object)
  ], ResourceResolver.prototype, "getConnection", null);
  __decorate([
    withCondition(() => updateExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.write ?? authorizer?.Update
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.write ?? access?.Update,
        method: "Update" /* UPDATE */,
        name
      })
    ]),
    __param(0, withCondition(() => updateExists, () => withInput({
      Resource,
      method: "Update" /* UPDATE */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_f2 = typeof Promise !== "undefined" && Promise) === "function" ? _f2 : Object)
  ], ResourceResolver.prototype, "update", null);
  __decorate([
    withCondition(() => removeExists, () => [
      withAuthorizer({
        authorizer: authorizer?.default ?? authorizer?.write ?? authorizer?.Remove
      }),
      withOutput({
        Resource,
        RootResource,
        level: access?.default ?? access?.write ?? access?.Remove,
        method: "Remove" /* REMOVE */,
        name
      })
    ]),
    __param(0, withCondition(() => removeExists, () => withInput({
      Resource,
      method: "Remove" /* REMOVE */,
      name
    }))),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_g2 = typeof Promise !== "undefined" && Promise) === "function" ? _g2 : Object)
  ], ResourceResolver.prototype, "remove", null);
  ResourceResolver = __decorate([
    withResolver()
  ], ResourceResolver);
  return ResourceResolver;
}, "createResourceResolver");

// ../lib-backend/src/resource/utils/createEmbeddedResourceResolver/createEmbeddedResourceResolver.ts
var createEmbeddedResourceResolver = /* @__PURE__ */ __name((params) => {
  const ResourceResolver = createResourceResolver(params);
  let EmbeddedResourceResolver = class EmbeddedResourceResolver extends ResourceResolver {
    static {
      __name(this, "EmbeddedResourceResolver");
    }
  };
  EmbeddedResourceResolver = __decorate([
    withResolver()
  ], EmbeddedResourceResolver);
  return EmbeddedResourceResolver;
}, "createEmbeddedResourceResolver");

// ../lib-backend/src/admin/resources/Utility/UtilityResolver/UtilityResolver.ts
var UtilityResolver = class UtilityResolver2 extends createEmbeddedResourceResolver({
  Resource: () => Utility,
  ResourceService: UtilityService,
  RootResource: () => Vendor,
  name: UTILITY_RESOURCE_NAME
}) {
  static {
    __name(this, "UtilityResolver");
  }
};
UtilityResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Utility })
], UtilityResolver);

// ../lib-backend/src/resource/utils/createEntityResourceResolver/createEntityResourceResolver.ts
var createEntityResourceResolver = /* @__PURE__ */ __name((params) => {
  let EntityResourceResolver = class EntityResourceResolver extends createResourceResolver(params) {
    static {
      __name(this, "EntityResourceResolver");
    }
  };
  EntityResourceResolver = __decorate([
    withResolver()
  ], EntityResourceResolver);
  return EntityResourceResolver;
}, "createEntityResourceResolver");

// ../lib-backend/src/admin/resources/Vendor/VendorResolver/VendorResolver.ts
var VendorResolver = class VendorResolver2 extends createEntityResourceResolver({
  Resource: () => Vendor,
  ResourceService: VendorService,
  name: VENDOR_RESOURCE_NAME
}) {
  static {
    __name(this, "VendorResolver");
  }
};
VendorResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Vendor })
], VendorResolver);

// ../lib-backend/src/group/resources/Group/GroupService/GroupService.ts
var GroupService = class GroupService2 extends createEntityResourceService({
  Resource: Group,
  afterCreate: async ({ output }, context) => {
    const userId = context?.user?._id;
    if (userId) {
      const { create: accessCreate } = _Container.get(AccessService);
      output.result?._id && await accessCreate({
        form: {
          [GROUP_RESOURCE_NAME]: { _id: output.result._id },
          [USER_RESOURCE_NAME]: { _id: userId },
          role: ["Admin" /* ADMIN */]
        }
      });
    }
    return output;
  },
  name: GROUP_RESOURCE_NAME
}) {
  static {
    __name(this, "GroupService");
  }
};
GroupService = __decorate([
  withContainer({ name: `${GROUP_RESOURCE_NAME}Service` })
], GroupService);

// ../lib-shared/src/auth/errors/UnauthenticatedError/UnauthenticatedError.ts
var UnauthenticatedError = class extends HttpError {
  static {
    __name(this, "UnauthenticatedError");
  }
  constructor(message) {
    super(HTTP_STATUS_CODE.UNAUTHORIZED, message);
  }
};

// ../lib-shared/src/core/errors/NotFoundError/NotFoundError.ts
var NotFoundError = class extends Error {
  static {
    __name(this, "NotFoundError");
  }
  constructor(message) {
    super(`not found: ${message}`);
  }
};

// ../lib-shared/src/core/utils/withInject/_withInject.ts
var import_inversify3 = require("inversify");
var _withInject = /* @__PURE__ */ __name((value) => (0, import_inversify3.inject)(value), "_withInject");

// ../lib-shared/src/core/utils/withInject/withInject.ts
var withInject = /* @__PURE__ */ __name((params) => _withInject(params), "withInject");

// ../lib-backend/src/auth/utils/createProtectedResourceService/createProtectedResourceService.ts
var import_mongodb5 = require("mongodb");
var createProtectedResoureService = /* @__PURE__ */ __name(({ ...params }) => {
  class ProtectedResourceService extends createEntityResourceService({
    ...params
  }) {
    static {
      __name(this, "ProtectedResourceService");
    }
    _groupService;
    async getManyProtected(input = {}, context) {
      const userId = context?.user?._id;
      if (userId) {
        const accessAll = (await _Container.get(AccessService).getMany({
          filter: [{ field: USER_RESOURCE_NAME, value: { _id: userId } }]
        })).result;
        if (accessAll) {
          input.filter = filterNil([
            ...input.filter ?? [],
            context.group && { field: GROUP_RESOURCE_NAME, value: new import_mongodb5.ObjectId(context.group) }
          ]);
          return this.getMany(input, context);
        }
        return { result: [] };
      }
      throw new UnauthenticatedError();
    }
    async Group(self) {
      if (self.Group) {
        const { result } = await this._groupService.get({
          filter: [{ field: "_id", value: self.Group }]
        });
        if (result) {
          return result;
        }
      }
      throw new NotFoundError("group");
    }
  }
  __decorate([
    withInject(GroupService),
    __metadata("design:type", Object)
  ], ProtectedResourceService.prototype, "_groupService", void 0);
  return ProtectedResourceService;
}, "createProtectedResoureService");

// ../lib-backend/src/auth/resources/Access/AccessService/AccessService.ts
var AccessService = class AccessService2 extends createProtectedResoureService({
  Resource: Access,
  name: ACCESS_RESOURCE_NAME
}) {
  static {
    __name(this, "AccessService");
  }
  async getManyUser(input = {}, context) {
    const userId = context?.user?._id;
    if (userId) {
      input.filter = [
        ...input.filter ?? [],
        { field: USER_RESOURCE_NAME, value: { _id: userId } }
      ];
      return this.getMany(input, context);
    }
    throw new UnauthenticatedError();
  }
};
AccessService = __decorate([
  withContainer({ name: `${ACCESS_RESOURCE_NAME}Service` })
], AccessService);

// ../lib-backend/src/http/utils/withFieldResolver/_withFieldResolver.ts
var import_type_graphql8 = require("type-graphql");
var _withFieldResolver = /* @__PURE__ */ __name(({ Resource } = {}) => (target, propertyKey, descriptor) => (0, import_type_graphql8.FieldResolver)(Resource)(target, propertyKey, descriptor), "_withFieldResolver");

// ../lib-backend/src/http/utils/withFieldResolver/withFieldResolver.ts
var withFieldResolver = /* @__PURE__ */ __name((params) => _withFieldResolver(params), "withFieldResolver");

// ../lib-backend/src/http/utils/withSelf/_withSelf.ts
var import_type_graphql9 = require("type-graphql");
var _withSelf = /* @__PURE__ */ __name(() => (target, propertyKey, parameterIndex) => (0, import_type_graphql9.Root)()(target, propertyKey, parameterIndex), "_withSelf");

// ../lib-backend/src/http/utils/withSelf/withSelf.ts
var withSelf = /* @__PURE__ */ __name(() => _withSelf(), "withSelf");

// ../lib-backend/src/resource/utils/createProtectedResourceResolver/createProtectedResourceResolver.ts
var createProtectedResourceResolver = /* @__PURE__ */ __name((params) => {
  var _a21, _b12;
  let ProtectedResourceResolver = class ProtectedResourceResolver extends createResourceResolver(params) {
    static {
      __name(this, "ProtectedResourceResolver");
    }
    _service = _Container.get(params.ResourceService);
    async getManyProtected(input = {}, context) {
      return this._service.getManyProtected(input, context);
    }
    async Group(self) {
      return this._service.Group ? this._service.Group(self) : null;
    }
  };
  __decorate([
    withOutput({
      Resource: params.Resource,
      method: "GetMany" /* GET_MANY */,
      name: `${params.name}${"GetMany" /* GET_MANY */}Protected`
    }),
    __param(0, withInput({
      Resource: params.Resource,
      method: "GetMany" /* GET_MANY */,
      name: `${params.name}${"GetMany" /* GET_MANY */}Protected`
    })),
    __param(1, _withContext()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", typeof (_a21 = typeof Promise !== "undefined" && Promise) === "function" ? _a21 : Object)
  ], ProtectedResourceResolver.prototype, "getManyProtected", null);
  __decorate([
    withFieldResolver({ Resource: () => Group }),
    __param(0, withSelf()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [void 0]),
    __metadata("design:returntype", typeof (_b12 = typeof Promise !== "undefined" && Promise) === "function" ? _b12 : Object)
  ], ProtectedResourceResolver.prototype, "Group", null);
  ProtectedResourceResolver = __decorate([
    withResolver({ Resource: params.Resource })
  ], ProtectedResourceResolver);
  return ProtectedResourceResolver;
}, "createProtectedResourceResolver");

// ../lib-backend/src/auth/resources/Access/AccessResolver/AccessResolver.ts
var AccessResolver = class AccessResolver2 extends createProtectedResourceResolver({
  Resource: () => Access,
  ResourceService: AccessService,
  name: ACCESS_RESOURCE_NAME
}) {
  static {
    __name(this, "AccessResolver");
  }
};
AccessResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Access })
], AccessResolver);

// ../lib-backend/src/auth/resources/Otp/OtpService/OtpService.ts
var import_toNumber2 = __toESM(require("lodash/toNumber"));

// ../lib-backend/src/file/utils/getRoot/_getRoot.ts
var import_app_root_path = __toESM(require("app-root-path"));
var _getRoot = /* @__PURE__ */ __name(() => import_app_root_path.default.toString(), "_getRoot");

// ../lib-backend/src/file/utils/getRoot/getRoot.ts
var getRoot = /* @__PURE__ */ __name(() => _getRoot(), "getRoot");

// ../lib-backend/src/file/utils/joinPaths/joinPaths.ts
var import_trimStart = __toESM(require("lodash/trimStart"));
var import_path = require("path");
var joinPaths = /* @__PURE__ */ __name((...[paths, options]) => {
  let path = (0, import_path.join)(...filterNil(paths));
  options?.extension && (path = `${path}.${(0, import_trimStart.default)(options.extension, ".")}`);
  return path;
}, "joinPaths");

// ../lib-backend/src/file/utils/fromRoot/fromRoot.ts
var fromRoot = /* @__PURE__ */ __name((...paths) => joinPaths([getRoot(), ...paths]), "fromRoot");

// ../lib-backend/src/file/utils/fromPackages/fromPackages.ts
var fromPackages = /* @__PURE__ */ __name((...paths) => fromRoot("packages", ...paths), "fromPackages");

// ../lib-backend/src/file/utils/fromStatic/fromStatic.ts
var fromStatic = /* @__PURE__ */ __name((...paths) => fromPackages("asset-static", ...paths), "fromStatic");

// ../lib-backend/src/notification/utils/mail/_mail.ts
var import_email_templates = __toESM(require("email-templates"));
var import_toNumber = __toESM(require("lodash/toNumber"));
var import_nodemailer = require("nodemailer");
var transport = (0, import_nodemailer.createTransport)({
  auth: { pass: "1pqcTKmYajdAQEFx", user: "ygmindev@gmail.com" },
  host: "smtp-relay.brevo.com",
  pool: true,
  port: (0, import_toNumber.default)("587")
});

// ../lib-backend/src/notification/utils/mail/mail.ts
var mail = /* @__PURE__ */ __name(async ({
  ...params
}) => {
  if (false) {
    return _mail({ ...params });
  }
  debug2(params);
  return true;
}, "mail");

// ../lib-backend/src/core/utils/template/_template.ts
var import_ejs = require("ejs");

// ../lib-backend/src/notification/utils/sms/_sms.ts
var import_twilio = __toESM(require("twilio"));

// ../lib-backend/src/notification/utils/sms/sms.ts
var sms = /* @__PURE__ */ __name(async ({
  from,
  params,
  pathname,
  to
}) => {
  if (false) {
    return _sms({ body: await template({ params, pathname }), from, to });
  }
  debug2(params);
  return true;
}, "sms");

// ../lib-backend/src/resource/utils/objectToEquality/objectToEquality.ts
var import_reduce4 = __toESM(require("lodash/reduce"));
var objectToEquality = /* @__PURE__ */ __name((params) => (0, import_reduce4.default)(
  params,
  (result, v, k) => !!v ? [...result, { field: k, value: v }] : result,
  []
), "objectToEquality");

// ../lib-backend/src/user/resources/User/UserService/UserService.ts
var UserService = class UserService2 extends createEntityResourceService({
  Resource: User,
  name: USER_RESOURCE_NAME
}) {
  static {
    __name(this, "UserService");
  }
};
UserService = __decorate([
  withContainer({ name: `${USER_RESOURCE_NAME}Service` })
], UserService);

// ../lib-shared/src/crypto/utils/randomInt/_randomInt.ts
var import_crypto = require("crypto");
var _randomInt = /* @__PURE__ */ __name((...[min, max]) => (0, import_crypto.randomInt)(min, max), "_randomInt");

// ../lib-shared/src/crypto/utils/randomInt/randomInt.ts
var randomInt2 = /* @__PURE__ */ __name((...params) => params.length == 2 ? _randomInt(params[0], params[1]) : _randomInt(10 ** (params[0] - 1), 10 ** params[0] - 1), "randomInt");

// ../lib-backend/src/auth/resources/Otp/OtpService/OtpService.ts
var OtpService = class OtpService2 extends createEntityResourceService({
  Resource: Otp,
  afterCreate: async ({ output }) => {
    if (output.result) {
      if (output.result.phone && output.result.callingCode) {
        await sms({
          from: "+18556452678",
          params: { otp: output.result.otp },
          pathname: fromStatic("templates/otp/sms.ejs"),
          to: `+${output.result.callingCode}${output.result.phone}`
        });
      }
      if (output.result.email) {
        await mail({
          from: "ygmindev@gmail.com",
          params: { otp: output.result.otp },
          template: "otp",
          to: [output.result.email]
        });
      }
    }
    return output;
  },
  beforeCreate: async ({ input }) => {
    const { checkExists, ...formF } = input.form;
    if (checkExists) {
      const userService = _Container.get(UserService);
      const { result } = await userService.get({
        filter: objectToEquality(cleanObject2(pick2(formF, ["callingCode", "email", "phone"]))),
        options: { project: { _id: true } }
      });
      if (result) {
        throw new DuplicateError(result._id);
      }
    }
    const otpService = _Container.get(OtpService2);
    await otpService.remove({ filter: objectToEquality(formF) });
    input.form.otp = process.env.SERVER_OTP_STATIC ?? randomInt2((0, import_toNumber2.default)("6")).toString();
    return input;
  },
  name: OTP_RESOURCE_NAME
}) {
  static {
    __name(this, "OtpService");
  }
  async verify(data) {
    const filter = objectToEquality(data);
    const { result } = await this.get({ filter, options: { project: { otp: true } } });
    if (!result || result.otp !== data.otp) {
      throw new UnauthorizedError();
    }
    await super.remove({ filter });
    return result;
  }
};
OtpService = __decorate([
  withContainer()
], OtpService);

// ../lib-backend/src/auth/resources/Otp/OtpResolver/OtpResolver.ts
var OtpResolver = class OtpResolver2 extends createEntityResourceResolver({
  Resource: () => Otp,
  ResourceData: () => OtpForm,
  ResourceService: OtpService,
  access: {
    ["Create" /* CREATE */]: "PUBLIC" /* PUBLIC */
  },
  name: OTP_RESOURCE_NAME
}) {
  static {
    __name(this, "OtpResolver");
  }
};
OtpResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Otp })
], OtpResolver);

// ../lib-backend/src/auth/resources/SignIn/SignIn.ts
var SignIn = class SignIn2 extends EntityResource {
  static {
    __name(this, "SignIn");
  }
  user;
  token;
  isNew;
};
__decorate([
  withField({ Resource: () => User, type: "resource" /* RESOURCE */ }),
  __metadata("design:type", Object)
], SignIn.prototype, "user", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", String)
], SignIn.prototype, "token", void 0);
__decorate([
  withField({ isOptional: true, type: "boolean" /* BOOLEAN */ }),
  __metadata("design:type", Boolean)
], SignIn.prototype, "isNew", void 0);
SignIn = __decorate([
  withEntity({ isRepository: true, name: SIGN_IN_RESOURCE_NAME })
], SignIn);
var SignInForm = class SignInForm2 {
  static {
    __name(this, "SignInForm");
  }
  callingCode;
  email;
  otp;
  phone;
};
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], SignInForm.prototype, "callingCode", void 0);
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], SignInForm.prototype, "email", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", String)
], SignInForm.prototype, "otp", void 0);
__decorate([
  withField({ isOptional: true, type: "string" /* STRING */ }),
  __metadata("design:type", String)
], SignInForm.prototype, "phone", void 0);
SignInForm = __decorate([
  withEntity({ name: `${SIGN_IN_RESOURCE_NAME}Form` })
], SignInForm);

// ../lib-backend/src/auth/resources/SignIn/SignInService/SignInService.ts
var _a14;
var _b8;
var _c3;
var SignInService = class SignInService2 {
  static {
    __name(this, "SignInService");
  }
  userService;
  otpService;
  jwtService;
  createSignIn = async (user) => {
    if (user?._id) {
      const claims = pick2(user, SIGN_IN_TOKEN_CLAIM_KEYS);
      const token = await this.jwtService.createToken(user._id, claims);
      return { token, user };
    }
    throw new NotFoundError("user");
  };
  async create({ form } = {}) {
    if (form?.otp) {
      const formF = cleanObject2(pick2(form, ["callingCode", "email", "phone"]));
      await this.otpService.verify({ ...formF, otp: form.otp });
      delete formF.otp;
      let { result: user } = await this.userService.get({
        filter: objectToEquality(formF)
      });
      let isNew;
      if (!user) {
        const { result: created } = await this.userService.create({ form: formF });
        user = created;
        isNew = true;
      }
      const signIn = await this.createSignIn(user);
      return { result: { ...signIn, isNew } };
    }
    throw new HttpError(HTTP_STATUS_CODE.BAD_REQUEST, "otp");
  }
  async userUpdate(input = {}, _context) {
    const result = await this.userService.update(input);
    if (result?.result) {
      const signIn = await this.createSignIn(result.result);
      return { result: signIn };
    }
    throw new HttpError(HTTP_STATUS_CODE.INTERNAL_SERVER_ERROR);
  }
  async usernameUpdate({ form } = {}, context) {
    if (form?.otp) {
      const formF = cleanObject2(form);
      const otp = await this.otpService.verify(formF);
      const { result: user } = await this.userService.update({
        filter: filterNil([
          context?.user?._id && { field: "_id", value: context.user._id },
          otp.email && { field: "email", value: otp.email },
          otp.phone && { field: "phone", value: otp.phone },
          otp.callingCode && { field: "callingCode", value: otp.callingCode }
        ]),
        update: formF
      });
      if (user) {
        const signIn = await this.createSignIn(user);
        return { result: signIn };
      }
      throw new UnauthorizedError();
    }
    throw new HttpError(HTTP_STATUS_CODE.BAD_REQUEST, "otp");
  }
};
__decorate([
  withInject(UserService),
  __metadata("design:type", typeof (_a14 = typeof UserService !== "undefined" && UserService) === "function" ? _a14 : Object)
], SignInService.prototype, "userService", void 0);
__decorate([
  withInject(OtpService),
  __metadata("design:type", typeof (_b8 = typeof OtpService !== "undefined" && OtpService) === "function" ? _b8 : Object)
], SignInService.prototype, "otpService", void 0);
__decorate([
  withInject(JwtService),
  __metadata("design:type", typeof (_c3 = typeof JwtService !== "undefined" && JwtService) === "function" ? _c3 : Object)
], SignInService.prototype, "jwtService", void 0);
SignInService = __decorate([
  withContainer({ name: `${SIGN_IN_RESOURCE_NAME}Service` })
], SignInService);

// ../lib-backend/src/auth/resources/SignIn/SignInResolver/SignInResolver.ts
var _a15;
var _b9;
var _c4;
var SignInResolver = class SignInResolver2 extends createEntityResourceResolver({
  Resource: () => SignIn,
  ResourceData: () => SignInForm,
  ResourceService: SignInService,
  access: {
    ["Create" /* CREATE */]: "PUBLIC" /* PUBLIC */
  },
  name: SIGN_IN_RESOURCE_NAME
}) {
  static {
    __name(this, "SignInResolver");
  }
  signInService;
  async userUpdate(input = {}, context) {
    return this.signInService.userUpdate(input, context);
  }
  async usernameUpdate(input = {}, context) {
    return this.signInService.usernameUpdate(input, context);
  }
};
__decorate([
  withInject(SignInService),
  __metadata("design:type", typeof (_a15 = typeof SignInService !== "undefined" && SignInService) === "function" ? _a15 : Object)
], SignInResolver.prototype, "signInService", void 0);
__decorate([
  withOutput({
    Resource: () => SignIn,
    level: "PROTECTED" /* PROTECTED */,
    method: "Update" /* UPDATE */,
    name: SIGN_IN_USER
  }),
  __param(0, withInput({
    Resource: () => User,
    method: "Update" /* UPDATE */,
    name: SIGN_IN_USER
  })),
  __param(1, _withContext()),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", [Object, Object]),
  __metadata("design:returntype", typeof (_b9 = typeof Promise !== "undefined" && Promise) === "function" ? _b9 : Object)
], SignInResolver.prototype, "userUpdate", null);
__decorate([
  withOutput({
    Resource: () => SignIn,
    level: "PROTECTED" /* PROTECTED */,
    method: "Create" /* CREATE */,
    name: SIGN_IN_USERNAME
  }),
  __param(0, withInput({
    Resource: () => SignInForm,
    method: "Create" /* CREATE */,
    name: SIGN_IN_USERNAME
  })),
  __param(1, _withContext()),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", [Object, Object]),
  __metadata("design:returntype", typeof (_c4 = typeof Promise !== "undefined" && Promise) === "function" ? _c4 : Object)
], SignInResolver.prototype, "usernameUpdate", null);
SignInResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => SignIn })
], SignInResolver);

// ../lib-backend/src/auth/utils/authorize/authorize.ts
var authorize = /* @__PURE__ */ __name(async ({
  context,
  roles
}) => {
  if (roles) {
    if (roles.includes("Any" /* ANY */)) {
      return true;
    }
    if (context.user) {
      if (roles.includes("User" /* USER */)) {
        return true;
      }
      return true;
    }
    return false;
  }
  return false;
}, "authorize");

// ../lib-shared/src/core/utils/isEqual/_isEqual.ts
var import_isEqual2 = __toESM(require("lodash/isEqual"));
var _isEqual = /* @__PURE__ */ __name((x, y) => (0, import_isEqual2.default)(x, y), "_isEqual");

// ../lib-backend/src/auth/utils/selfAuthorizer/selfAuthorizer.ts
var selfAuthorizer = /* @__PURE__ */ __name((self = (input) => input?.root) => ({ context, input }) => _isEqual(context?.user?._id, self(input)), "selfAuthorizer");

// ../lib-backend/src/billing/resources/Bank/BankService/BankService.ts
var BankService = class BankService2 extends createEmbeddedResourceService({
  Resource: Bank,
  RootService: UserService,
  name: BANK_RESOURCE_NAME
}) {
  static {
    __name(this, "BankService");
  }
};
BankService = __decorate([
  withContainer()
], BankService);

// ../lib-backend/src/billing/resources/Bank/BankResolver/BankResolver.ts
var BankResolver = class BankResolver2 extends createEmbeddedResourceResolver({
  Resource: () => Bank,
  ResourceService: BankService,
  RootResource: () => User,
  authorizer: { default: selfAuthorizer() },
  name: BANK_RESOURCE_NAME
}) {
  static {
    __name(this, "BankResolver");
  }
};
BankResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Bank })
], BankResolver);

// ../lib-backend/src/billing/resources/Card/CardService/CardService.ts
var CardService = class CardService2 extends createEmbeddedResourceService({
  Resource: Card,
  RootService: UserService,
  name: CARD_RESOURCE_NAME
}) {
  static {
    __name(this, "CardService");
  }
};
CardService = __decorate([
  withContainer()
], CardService);

// ../lib-backend/src/billing/resources/Card/CardResolver/CardResolver.ts
var CardResolver = class CardResolver2 extends createEmbeddedResourceResolver({
  Resource: () => Card,
  ResourceService: CardService,
  RootResource: () => User,
  authorizer: { default: selfAuthorizer() },
  name: CARD_RESOURCE_NAME
}) {
  static {
    __name(this, "CardResolver");
  }
};
CardResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Card })
], CardResolver);

// ../lib-backend/src/billing/resources/PaymentMethod/PaymentMethodService/PaymentMethodService.ts
var import_reduce5 = __toESM(require("lodash/reduce"));

// ../lib-backend/src/billing/utils/StripeAdminService/StripeAdminService.ts
var import_stripe = __toESM(require("stripe"));

// ../lib-backend/src/billing/utils/StripeAdminService/StripeAdminService.constants.ts
var STRIPE_ADMIN_SERVICE_API_VERSION = "2022-11-15";

// ../lib-shared/src/core/errors/ExternalError/ExternalError.ts
var ExternalError = class extends Error {
  static {
    __name(this, "ExternalError");
  }
  constructor(value) {
    super(`external: ${value}`);
  }
};

// ../lib-backend/src/billing/utils/StripeAdminService/StripeAdminService.ts
var StripeAdminService = class StripeAdminService2 {
  static {
    __name(this, "StripeAdminService");
  }
  stripe = new import_stripe.default("sk_test_51M6JrCIgnrVx8bLYzslp9zptnVd5pe7XYTR7xyx6L41lFBU6YGWbNPw6KmG2TLPVpxfGJ2Vw0vije9XW0dXi63AM00ZI2bU6r2", {
    apiVersion: STRIPE_ADMIN_SERVICE_API_VERSION
  });
  createCustomer = async () => {
    const { id } = await this.stripe.customers.create();
    return id;
  };
  createIntent = async (id) => {
    const { client_secret } = await this.stripe.setupIntents.create({
      customer: id,
      payment_method_types: ["card", "us_bank_account"]
    });
    if (client_secret) {
      return client_secret;
    }
    throw new ExternalError("Stripe create intent");
  };
};
StripeAdminService = __decorate([
  withContainer()
], StripeAdminService);

// ../lib-backend/src/user/resources/LinkedUser/LinkedUserService/LinkedUserService.ts
var LinkedUserService = class LinkedUserService2 extends createEmbeddedResourceService({
  Resource: LinkedUser,
  RootService: UserService,
  name: LINKED_USER_RESOURCE_NAME
}) {
  static {
    __name(this, "LinkedUserService");
  }
};
LinkedUserService = __decorate([
  withContainer()
], LinkedUserService);

// ../lib-backend/src/billing/resources/PaymentMethod/PaymentMethodService/PaymentMethodService.ts
var _a16;
var _b10;
var _c5;
var _d3;
var PaymentMethodService = class PaymentMethodService2 {
  static {
    __name(this, "PaymentMethodService");
  }
  linkedUserService;
  cardService;
  bankService;
  stripeAdminService;
  async getMany(input = {}) {
    if (input.root) {
      const fields = [
        "_id",
        "externalId",
        "last4",
        "name",
        "type"
      ];
      const project = (0, import_reduce5.default)(fields, (result, v) => ({ ...result, [v]: true }), {});
      const { result: banks } = await this.bankService.getMany({
        filter: [],
        options: { project },
        root: input.root
      });
      const { result: cards } = await this.cardService.getMany({
        filter: [],
        options: { project },
        root: input.root
      });
      return {
        result: [
          ...banks?.map((value) => pick2(value, fields)) ?? [],
          ...cards?.map((value) => pick2(value, fields)) ?? []
        ]
      };
    }
    throw new UnauthenticatedError();
  }
  async createToken(input) {
    if (input?.root) {
      let { result: linkedUser } = await this.linkedUserService.get({
        filter: [{ field: "type", value: "stripe" /* STRIPE */ }],
        options: { project: { _id: true, externalId: true } },
        root: input.root
      });
      if (!linkedUser) {
        const id = await this.stripeAdminService.createCustomer();
        const { result: linkedUserNew } = await this.linkedUserService.create({
          form: { externalId: id, type: "stripe" /* STRIPE */ },
          root: input.root
        });
        linkedUserNew && (linkedUser = linkedUserNew);
      }
      if (linkedUser) {
        const result = linkedUser.externalId && await this.stripeAdminService.createIntent(linkedUser.externalId);
        return { result };
      }
      throw new NotFoundError("linked user");
    }
    throw new UnauthenticatedError();
  }
};
__decorate([
  withInject(LinkedUserService),
  __metadata("design:type", typeof (_a16 = typeof LinkedUserService !== "undefined" && LinkedUserService) === "function" ? _a16 : Object)
], PaymentMethodService.prototype, "linkedUserService", void 0);
__decorate([
  withInject(CardService),
  __metadata("design:type", typeof (_b10 = typeof CardService !== "undefined" && CardService) === "function" ? _b10 : Object)
], PaymentMethodService.prototype, "cardService", void 0);
__decorate([
  withInject(BankService),
  __metadata("design:type", typeof (_c5 = typeof BankService !== "undefined" && BankService) === "function" ? _c5 : Object)
], PaymentMethodService.prototype, "bankService", void 0);
__decorate([
  withInject(StripeAdminService),
  __metadata("design:type", typeof (_d3 = typeof StripeAdminService !== "undefined" && StripeAdminService) === "function" ? _d3 : Object)
], PaymentMethodService.prototype, "stripeAdminService", void 0);
PaymentMethodService = __decorate([
  withContainer({ name: `${PAYMENT_METHOD_RESOURCE_NAME}Service` })
], PaymentMethodService);

// ../lib-backend/src/billing/resources/PaymentMethod/PaymentMethodResolver/PaymentMethodResolver.ts
var _a17;
var PaymentMethodResolver = class PaymentMethodResolver2 extends createEmbeddedResourceResolver({
  Resource: () => PaymentMethod,
  ResourceService: PaymentMethodService,
  RootResource: () => User,
  authorizer: { default: selfAuthorizer() },
  name: PAYMENT_METHOD_RESOURCE_NAME
}) {
  static {
    __name(this, "PaymentMethodResolver");
  }
  async createToken(input) {
    return _Container.get(PaymentMethodService).createToken(input);
  }
};
__decorate([
  withOutput({
    Resource: () => String,
    method: "Create" /* CREATE */,
    name: `${PAYMENT_METHOD_RESOURCE_NAME}Token`
  }),
  __param(0, withInput({
    method: "Create" /* CREATE */,
    name: `${PAYMENT_METHOD_RESOURCE_NAME}Token`
  })),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", [Object]),
  __metadata("design:returntype", typeof (_a17 = typeof Promise !== "undefined" && Promise) === "function" ? _a17 : Object)
], PaymentMethodResolver.prototype, "createToken", null);
PaymentMethodResolver = __decorate([
  withContainer(),
  withResolver()
], PaymentMethodResolver);

// ../lib-backend/src/chat/resources/Chat/ChatService/ChatService.ts
var ChatService = class ChatService2 extends createEntityResourceService({
  Resource: Chat,
  name: CHAT_RESOURCE_NAME
}) {
  static {
    __name(this, "ChatService");
  }
};
ChatService = __decorate([
  withContainer({ name: `${CHAT_RESOURCE_NAME}Service` })
], ChatService);

// ../lib-backend/src/chat/resources/Chat/ChatResolver/ChatResolver.ts
var ChatResolver = class ChatResolver2 extends createEntityResourceResolver({
  Resource: () => Chat,
  ResourceService: ChatService,
  name: CHAT_RESOURCE_NAME
}) {
  static {
    __name(this, "ChatResolver");
  }
};
ChatResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Chat })
], ChatResolver);

// ../lib-backend/src/group/resources/Group/GroupResolver/GroupResolver.ts
var GroupResolver = class GroupResolver2 extends createProtectedResourceResolver({
  Resource: () => Group,
  ResourceService: GroupService,
  name: GROUP_RESOURCE_NAME
}) {
  static {
    __name(this, "GroupResolver");
  }
};
GroupResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Group })
], GroupResolver);

// ../lib-backend/src/http/resources/Socket/SocketResolver/SocketResolver.ts
var SocketResolver = class SocketResolver2 extends createEntityResourceResolver({
  Resource: () => Socket,
  ResourceService: SocketService,
  name: SOCKET_RESOURCE_NAME
}) {
  static {
    __name(this, "SocketResolver");
  }
};
SocketResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => Socket })
], SocketResolver);

// ../lib-backend/src/aroom/utils/PriceTier/PriceTier.ts
var PriceTier = class PriceTier2 {
  static {
    __name(this, "PriceTier");
  }
  price;
  timing;
};
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], PriceTier.prototype, "price", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], PriceTier.prototype, "timing", void 0);
PriceTier = __decorate([
  withEntity({ name: "PriceTier" })
], PriceTier);

// ../lib-shared/src/map/resources/MapRoute/MapRoute.constants.ts
var MAP_ROUTE_RESOURCE = "MapRoute";

// ../lib-backend/src/map/resources/MapRoute/MapRoute.ts
var _a18;
var MapRoute = class MapRoute2 {
  static {
    __name(this, "MapRoute");
  }
  distance;
  duration;
  polyline;
  priceTiers;
};
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], MapRoute.prototype, "distance", void 0);
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], MapRoute.prototype, "duration", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", String)
], MapRoute.prototype, "polyline", void 0);
__decorate([
  withField({ Resource: () => PriceTier, isArray: true, type: "resource" /* RESOURCE */ }),
  __metadata("design:type", typeof (_a18 = typeof Array !== "undefined" && Array) === "function" ? _a18 : Object)
], MapRoute.prototype, "priceTiers", void 0);
MapRoute = __decorate([
  withEntity({ name: MAP_ROUTE_RESOURCE })
], MapRoute);

// ../lib-shared/src/http/utils/HttpService/_HttpService.ts
var import_axios = __toESM(require("axios"));
var _HttpService = class {
  static {
    __name(this, "_HttpService");
  }
  _instance;
  constructor({ baseUri, onError, onRequest, onResponse, request } = {}) {
    this._instance = import_axios.default.create({
      ...request,
      baseURL: baseUri ? uri(baseUri) : ""
    });
    this._onError = onError;
    onRequest && this._instance.interceptors.request.use(
      ({ headers, responseType, timeout, withCredentials, ...params }) => onRequest({
        ...params,
        headers,
        responseType,
        timeout,
        withCredentials
      })
    );
    onResponse && this._instance.interceptors.response.use(
      async ({ data, headers, status, statusText, ...params }) => onResponse({
        ...params,
        data,
        headers,
        status,
        statusText
      })
    );
  }
  request = async (method, { params, request, url }) => {
    try {
      const response = await this._instance.request({
        ...request,
        data: params,
        method,
        url: url ?? ""
      });
      return (response && response.data) ?? null;
    } catch (e) {
      const eF = new HttpError(
        e.response?.status ?? HTTP_STATUS_CODE.INTERNAL_SERVER_ERROR,
        stringify2(e.response?.data),
        e.stack
      );
      if (this._onError) {
        await this._onError(eF);
        return null;
      }
      throw eF;
    }
  };
  get = async ({
    params,
    request,
    url
  }) => this.request("get" /* GET */, {
    request,
    url: uri({ host: url, params })
  });
  delete = async ({
    params,
    request,
    url
  }) => this.request("delete" /* DELETE */, {
    request,
    url: uri({ host: url, params })
  });
  post = async ({
    params,
    request,
    url
  }) => this.request("post" /* POST */, { params, request, url });
  put = async ({
    params,
    request,
    url
  }) => this.request("put" /* PUT */, { params, request, url });
};

// ../lib-shared/src/http/utils/HttpService/HttpService.ts
var HttpService = class extends _HttpService {
  static {
    __name(this, "HttpService");
  }
};

// ../lib-backend/src/http/utils/HttpService/HttpService.ts
var HttpService2 = class HttpService3 extends HttpService {
  static {
    __name(this, "HttpService");
  }
};
HttpService2 = __decorate([
  withContainer()
], HttpService2);

// ../lib-backend/src/map/resources/MapRoute/MapRouteService/MapRouteService.constants.ts
var PRICING_TABLE = {
  ["car" /* CAR */]: {
    ["rush" /* RUSH */]: {
      base: 0,
      min: 8,
      perMile: 1.62,
      perMinute: 0.74
    },
    ["sameDay" /* SAME_DAY */]: {
      base: 0,
      min: 7,
      perMile: 1.22,
      perMinute: 0.54
    }
  },
  ["cargoVan" /* CARGO_VAN */]: {
    ["rush" /* RUSH */]: {
      base: 3.85,
      min: 10.5,
      perMile: 2.35,
      perMinute: 0.77
    },
    ["sameDay" /* SAME_DAY */]: {
      base: 2.85,
      min: 9.5,
      perMile: 2.15,
      perMinute: 0.57
    }
  },
  ["sprinterVan" /* SPRINTER_VAN */]: {
    ["rush" /* RUSH */]: {
      base: 14.75,
      min: 25,
      perMile: 4.5,
      perMinute: 1.32
    },
    ["sameDay" /* SAME_DAY */]: {
      base: 13.75,
      min: 24,
      perMile: 4.3,
      perMinute: 1.12
    }
  }
};

// ../lib-backend/src/map/resources/MapRoute/MapRouteService/MapRouteService.ts
var import_round = __toESM(require("lodash/round"));
var import_toNumber3 = __toESM(require("lodash/toNumber"));
var _a19;
var getPrice = /* @__PURE__ */ __name(({ distanceMeters, durationSeconds, timing, vehicle }) => {
  const { base, min, perMile, perMinute } = PRICING_TABLE[vehicle][timing];
  const miles = distanceMeters / 1609.34;
  const minutes = durationSeconds / 60;
  const price = Math.max(min, base + perMile * miles + perMinute * minutes);
  return (0, import_round.default)(price, 2);
}, "getPrice");
var MapRouteService = class MapRouteService2 {
  static {
    __name(this, "MapRouteService");
  }
  httpService;
  async getRoute(input) {
    const { coordinates, timing, vehicle } = input;
    const origin = {
      latitude: 40.71486,
      longitude: -74.0142
    };
    const destination = {
      latitude: 40.759769,
      longitude: -73.987968
    };
    const intermediates = coordinates.slice(1, -1);
    const params = {
      destination: { location: { latLng: destination } },
      origin: { location: { latLng: origin } },
      routingPreference: "TRAFFIC_AWARE",
      travelMode: "DRIVE"
    };
    intermediates?.length && (params.intermediates = intermediates.map((value) => ({ latLng: value })));
    const result = {
      routes: [
        {
          distanceMeters: 6800,
          duration: "1805s",
          polyline: {
            encodedPolyline: "kbowFlxvbMhCd@x@TsA|DqB|FwCuBZcDEg@j@oGc@K}YcEae@yFuDWmIe@oDMk\\}AwTu@_CHcCNoAEk@IiAa@qCuA}@]{E}@y@Og@ABSAa@Ky@IWMUkBiAeEsCy@e@eHyEWMgm@w`@{DmCaKqGw@k@}BuAuFuDcOyJ|Mqb@sFqD"
          }
        }
      ]
    };
    const route = result?.routes?.[0];
    if (route) {
      const seconds = (0, import_toNumber3.default)(route.duration.replace("s", ""));
      const priceTiers = ["rush" /* RUSH */, "sameDay" /* SAME_DAY */].map((timing2) => ({
        price: getPrice({
          distanceMeters: route.distanceMeters,
          durationSeconds: seconds,
          timing: timing2,
          vehicle
        }),
        timing: timing2
      }));
      return {
        distance: route.distanceMeters,
        duration: seconds,
        polyline: route.polyline.encodedPolyline,
        priceTiers
      };
    }
    return {
      distance: 0,
      duration: 0,
      polyline: "",
      priceTiers: []
    };
  }
};
__decorate([
  withInject(HttpService2),
  __metadata("design:type", typeof (_a19 = typeof HttpService2 !== "undefined" && HttpService2) === "function" ? _a19 : Object)
], MapRouteService.prototype, "httpService", void 0);
MapRouteService = __decorate([
  withContainer()
], MapRouteService);

// ../lib-backend/src/map/utils/Coordinate/Coordinate.ts
var Coordinate = class Coordinate2 {
  static {
    __name(this, "Coordinate");
  }
  latitude;
  longitude;
};
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Coordinate.prototype, "latitude", void 0);
__decorate([
  withField({ type: "number" /* NUMBER */ }),
  __metadata("design:type", Number)
], Coordinate.prototype, "longitude", void 0);
Coordinate = __decorate([
  withEntity({ name: "Coordinate" })
], Coordinate);

// ../lib-backend/src/map/resources/MapRoute/MapRouteResolver/MapRouteResolver.ts
var _a20;
var _b11;
var _c6;
var GetRouteInput = class GetRouteInput2 {
  static {
    __name(this, "GetRouteInput");
  }
  coordinates;
  timing;
  vehicle;
};
__decorate([
  withField({ Resource: () => Coordinate, isArray: true, type: "resource" /* RESOURCE */ }),
  __metadata("design:type", typeof (_a20 = typeof Array !== "undefined" && Array) === "function" ? _a20 : Object)
], GetRouteInput.prototype, "coordinates", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], GetRouteInput.prototype, "timing", void 0);
__decorate([
  withField({ type: "string" /* STRING */ }),
  __metadata("design:type", Object)
], GetRouteInput.prototype, "vehicle", void 0);
GetRouteInput = __decorate([
  withEntity({ name: "GetRoute" })
], GetRouteInput);
var MapRouteResolver = class MapRouteResolver2 {
  static {
    __name(this, "MapRouteResolver");
  }
  mapRouteService;
  async getRoute(input) {
    return this.mapRouteService.getRoute(input);
  }
};
__decorate([
  withInject(MapRouteService),
  __metadata("design:type", typeof (_b11 = typeof MapRouteService !== "undefined" && MapRouteService) === "function" ? _b11 : Object)
], MapRouteResolver.prototype, "mapRouteService", void 0);
__decorate([
  withResult({
    Resource: () => MapRoute,
    name: `${"Get" /* GET */}${MAP_ROUTE_RESOURCE}`
  }),
  __param(0, withParams({ Resource: () => GetRouteInput })),
  __metadata("design:type", Function),
  __metadata("design:paramtypes", [Object]),
  __metadata("design:returntype", typeof (_c6 = typeof Promise !== "undefined" && Promise) === "function" ? _c6 : Object)
], MapRouteResolver.prototype, "getRoute", null);
MapRouteResolver = __decorate([
  withContainer(),
  withResolver()
], MapRouteResolver);

// ../lib-backend/src/user/resources/LinkedUser/LinkedUserResolver/LinkedUserResolver.ts
var LinkedUserResolver = class LinkedUserResolver2 extends createEmbeddedResourceResolver({
  Resource: () => LinkedUser,
  ResourceService: LinkedUserService,
  RootResource: () => User,
  authorizer: { default: selfAuthorizer() },
  name: LINKED_USER_RESOURCE_NAME
}) {
  static {
    __name(this, "LinkedUserResolver");
  }
};
LinkedUserResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => LinkedUser })
], LinkedUserResolver);

// ../lib-backend/src/user/resources/User/UserResolver/UserResolver.ts
var import_isEqual5 = __toESM(require("lodash/isEqual"));
var UserResolver = class UserResolver2 extends createEntityResourceResolver({
  Resource: () => User,
  ResourceService: UserService,
  authorizer: {
    Update: ({ context, input }) => (0, import_isEqual5.default)(context?.user?._id, input.filter._id)
  },
  name: USER_RESOURCE_NAME
}) {
  static {
    __name(this, "UserResolver");
  }
};
UserResolver = __decorate([
  withContainer(),
  withResolver({ Resource: () => User })
], UserResolver);

// ../lib-config/src/data/graphql/_graphql.ts
var import_type_graphql10 = require("type-graphql");
var _graphql = /* @__PURE__ */ __name(({
  authorize: authorize2,
  container: container2,
  resolvers,
  schemaDir
}) => (0, import_type_graphql10.buildSchemaSync)({
  authChecker: ({ context }, roles) => authorize2({ context, roles }),
  container: container2,
  emitSchemaFile: schemaDir,
  nullableByDefault: true,
  resolvers,
  validate: { forbidUnknownValues: false }
}), "_graphql");

// ../lib-config/src/data/graphql/graphql.ts
var { _config: _config3, config: config3 } = defineConfig({
  _config: _graphql,
  config: () => ({
    authorize,
    container: _Container,
    resolvers: filterNil([
      AccessResolver,
      BankResolver,
      CardResolver,
      ChatResolver,
      GroupResolver,
      LinkedUserResolver,
      OtpResolver,
      PaymentMethodResolver,
      SignInResolver,
      SocketResolver,
      UserResolver,
      VendorResolver,
      UtilityResolver,
      MapRouteResolver
      // process.env.NODE_ENV === 'test' && SnapshotResolver,
    ]),
    schemaDir: fromStatic("graphql/schema.gql")
  })
});

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var _createLambdaHandler = /* @__PURE__ */ __name(({
  context: contextDefault = {},
  handler,
  plugins,
  type
}) => {
  const getContext = /* @__PURE__ */ __name(async ({
    context,
    event
  }) => {
    const contextF = { ...contextDefault, ...context };
    contextF.callbackWaitsForEmptyEventLoop = false;
    contextF.pathname = event.requestContext.routeKey;
    if (plugins?.includes("authentication" /* AUTHENTICATION */)) {
      const eventF = event;
      const authorization = eventF.headers?.authorization ?? eventF.queryStringParameters?.Authorization;
      const user = await getUserFromHeader(authorization);
      user && (contextF.user = user);
      eventF.headers?.group && (contextF.group = eventF.headers.group);
    }
    if (plugins?.includes("database" /* DATABASE */) && !contextF.database) {
      const { database } = await initialize();
      database && (contextDefault.database = database);
    }
    contextF.requestId = type === "websocket" /* WEBSOCKET */ ? event.requestContext.connectionId : context.awsRequestId;
    return { ...contextDefault, ...contextF };
  }, "getContext");
  return async (event, context, callback) => {
    if (type === "graphql" /* GRAPHQL */) {
      const server = new import_server.ApolloServer({
        allowBatchedHttpRequests: true,
        formatError: (e, originalError) => {
          const originalErrorF = originalError?.originalError;
          const errorF = new HttpError(
            originalErrorF?.statusCode,
            e.message ?? originalErrorF?.message,
            e.extensions?.stacktrace ?? e?.stack ?? originalErrorF.stack
          );
          console.error(e);
          console.error(errorF);
          return errorF;
        },
        schema: _config3()
      });
      const handlerF = (0, import_aws_lambda.startServerAndCreateLambdaHandler)(
        server,
        import_aws_lambda.handlers.createAPIGatewayProxyEventV2RequestHandler(),
        {
          context: async ({ context: context2, event: event2 }) => getContext({ context: context2, event: event2 })
        }
      );
      return handlerF(event, context, callback);
    }
    const contextF = await getContext({ context, event });
    const result = {
      statusCode: HTTP_STATUS_CODE.SUCCESS,
      ...handler && await handler({ body: event.body, context: contextF })
    };
    switch (type) {
      case "websocket" /* WEBSOCKET */:
        if (contextF.pathname === "$default" && result.requestId && result.body) {
          try {
            const api = new import_client_apigatewaymanagementapi.ApiGatewayManagementApiClient({
              endpoint: event.requestContext.domainName
            });
            const command = new import_client_apigatewaymanagementapi.PostToConnectionCommand({
              ConnectionId: result.requestId,
              Data: Buffer.from(result.body)
            });
            await api.send(command);
            return { statusCode: HTTP_STATUS_CODE.SUCCESS };
          } catch (e) {
            console.warn("@@@ERROR");
            console.warn(e);
          }
        }
        return result;
      default: {
        result.body && (result.body = stringify2(result.body));
        return result;
      }
    }
  };
}, "_createLambdaHandler");

// ../lib-backend/src/serverless/utils/createLambdaHandler/createLambdaHandler.ts
var createLambdaHandler = /* @__PURE__ */ __name(({
  ...params
}) => _createLambdaHandler({ ...params }), "createLambdaHandler");

// src/functions/websocket/websocket.ts
var main = createLambdaHandler({
  handler: async ({ body, context }) => {
    const socketService = _Container.get(SocketService);
    const { pathname, user } = context;
    switch (pathname) {
      case "$connect": {
        if (user) {
          const socket = await socketService.create({ form: { externalId: context.requestId } });
        }
        return {
          body: { message: "success" },
          statusCode: HTTP_STATUS_CODE.SUCCESS
        };
      }
      case "$disconnect": {
        await socketService.remove({ filter: [{ field: "externalId", value: context.requestId }] });
        return {
          body: { message: "success" },
          statusCode: HTTP_STATUS_CODE.SUCCESS
        };
      }
      default: {
        return {
          body,
          requestId: context.requestId
        };
      }
    }
  },
  plugins: ["authentication" /* AUTHENTICATION */, "database" /* DATABASE */],
  type: "websocket" /* WEBSOCKET */
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=websocket.js.map
