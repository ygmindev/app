"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/ping/ping.ts
var ping_exports = {};
__export(ping_exports, {
  main: () => main
});
module.exports = __toCommonJS(ping_exports);

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var import_server = require("@apollo/server");
var import_aws_lambda = require("@as-integrations/aws-lambda");
var import_client_apigatewaymanagementapi = require("@aws-sdk/client-apigatewaymanagementapi");

// ../../node_modules/.pnpm/tslib@2.6.2/node_modules/tslib/tslib.es6.mjs
function __decorate(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
    r = Reflect.decorate(decorators, target, key, desc);
  else
    for (var i = decorators.length - 1; i >= 0; i--)
      if (d = decorators[i])
        r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
__name(__decorate, "__decorate");

// ../lib-backend/src/auth/utils/JwtImplementation/_JwtImplementation.ts
var import_firebase_admin = __toESM(require("firebase-admin"));
var import_toString = __toESM(require("lodash/toString"));

// ../lib-shared/src/user/resources/User/User.constants.ts
var USER_RESOURCE_NAME = "User";

// ../lib-shared/src/auth/resources/SignIn/SignIn.constants.ts
var SIGN_IN_RESOURCE_NAME = "SignIn";
var SIGN_IN_USER = `${SIGN_IN_RESOURCE_NAME}${USER_RESOURCE_NAME}`;
var SIGN_IN_USERNAME = `${SIGN_IN_RESOURCE_NAME}Username`;
var SIGN_IN_TOKEN_CLAIM_KEYS = [
  "email",
  "phone",
  "first",
  "last"
];

// ../lib-shared/src/core/utils/pick/_pick.ts
var import_pick = __toESM(require("lodash/pick"));
var _pick = /* @__PURE__ */ __name((...[value, keys]) => (0, import_pick.default)(value, keys), "_pick");

// ../lib-shared/src/core/utils/pick/pick.ts
var pick2 = /* @__PURE__ */ __name((...params) => _pick(...params), "pick");

// ../lib-backend/src/auth/utils/JwtImplementation/_JwtImplementation.ts
var _JwtImplementation = class {
  static {
    __name(this, "_JwtImplementation");
  }
  constructor() {
    !import_firebase_admin.default.apps.length && import_firebase_admin.default.initializeApp({
      credential: import_firebase_admin.default.credential.cert({
        clientEmail: process.env.SERVER_FIREBASE_ADMIN_EMAIL,
        privateKey: process.env.SERVER_FIREBASE_ADMIN_SECRET.replace(/\\n/gm, "\n"),
        projectId: process.env.SERVER_FIREBASE_ADMIN_PROJECT_ID
      })
    });
  }
  createToken = async (_id, claims) => import_firebase_admin.default.auth().createCustomToken((0, import_toString.default)(_id), claims);
  verifyToken = async (token) => {
    const decoded = await import_firebase_admin.default.auth().verifyIdToken(token);
    return {
      _id: decoded.uid,
      claims: {
        ...decoded.additionalClaims ?? {},
        ...pick2(decoded, SIGN_IN_TOKEN_CLAIM_KEYS)
      }
    };
  };
};

// ../lib-backend/src/core/utils/Container/_Container.ts
var import_reflect_metadata = require("reflect-metadata");
var import_inversify = require("inversify");
var import_isFunction = __toESM(require("lodash/isFunction"));
var container = new import_inversify.Container({
  autoBindInjectable: true,
  defaultScope: "Singleton",
  skipBaseClassChecks: true
});
var _Container = {
  get: (type, name) => name ? container.getNamed(type, name) : container.get(type),
  set: (type, value, name) => {
    const valueF = (0, import_isFunction.default)(value) ? container.bind(type).to(value) : container.bind(type).toDynamicValue(() => value);
    name && valueF.whenTargetNamed(name);
  }
};

// ../lib-backend/src/core/utils/withContainer/_withContainer.ts
var import_inversify2 = require("inversify");
var _withContainer = import_inversify2.injectable;

// ../lib-backend/src/core/utils/withContainer/withContainer.ts
var withContainer = /* @__PURE__ */ __name(({ name } = {}) => (target) => {
  _withContainer()(target);
  name && _Container.set(name, target);
  return target;
}, "withContainer");

// ../lib-backend/src/auth/utils/JwtImplementation/JwtImplementation.ts
var JwtImplementation = class JwtImplementation2 extends _JwtImplementation {
  static {
    __name(this, "JwtImplementation");
  }
};
JwtImplementation = __decorate([
  withContainer()
], JwtImplementation);

// ../lib-backend/src/auth/utils/getUserFromHeader/getUserFromHeader.ts
var getUserFromHeader = /* @__PURE__ */ __name(async (params) => {
  if (params) {
    const [, token] = params.split(" ");
    return token && token !== "null" ? _Container.get(JwtImplementation).verifyToken(token) : null;
  }
  return null;
}, "getUserFromHeader");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.constants.ts
var CLEAN_OBJECT_KEYS = ["toJSON"];

// ../lib-shared/src/core/utils/filterNil/filterNil.ts
var filterNil = /* @__PURE__ */ __name((params) => params?.filter(Boolean), "filterNil");

// ../lib-shared/src/core/utils/isPrimitive/isPrimitive.ts
var isPrimitive = /* @__PURE__ */ __name((params) => params !== Object(params) || params instanceof Date, "isPrimitive");

// ../lib-shared/src/core/utils/toPlainObject/_toPlainObject.ts
var import_toPlainObject = __toESM(require("lodash/toPlainObject"));
var _toPlainObject = /* @__PURE__ */ __name((params) => (0, import_toPlainObject.default)(params), "_toPlainObject");

// ../lib-shared/src/core/utils/toPlainObject/toPlainObject.ts
var toPlainObject2 = /* @__PURE__ */ __name((params) => _toPlainObject(params), "toPlainObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.base.ts
var import_every = __toESM(require("lodash/every"));
var import_isArray = __toESM(require("lodash/isArray"));
var import_isObject = __toESM(require("lodash/isObject"));
var cleanObject = /* @__PURE__ */ __name((...[value, options, depth = 0]) => {
  if (isPrimitive(value)) {
    return value;
  }
  if ((0, import_isArray.default)(value)) {
    return filterNil(value.map((vv) => cleanObject(vv, options, depth)));
  }
  if ((0, import_isObject.default)(value) && (!options?.primitiveTypes || (0, import_every.default)(options?.primitiveTypes, (type) => !(value instanceof type)))) {
    const valueF = options?.objectTransformer ? options.objectTransformer(value, depth) : toPlainObject2(value);
    Object.keys(valueF).forEach((k) => {
      let v = valueF[k];
      v = options?.keyValueTransformer ? options.keyValueTransformer(v, k, depth) : v;
      if (CLEAN_OBJECT_KEYS.includes(k) || v === void 0) {
        delete valueF[k];
      } else {
        valueF[k] = cleanObject(v, options, depth + 1);
      }
    });
    return valueF;
  }
  return value;
}, "cleanObject");

// ../lib-shared/src/core/utils/cleanObject/cleanObject.ts
var import_toPlainObject4 = __toESM(require("lodash/toPlainObject"));
var import_mongodb = require("mongodb");
var cleanObject2 = /* @__PURE__ */ __name((...[value, options, depth]) => cleanObject(
  value,
  {
    ...options,
    objectTransformer: (v) => {
      const { beforeCreate } = v;
      beforeCreate && void beforeCreate.bind(v)();
      return (0, import_toPlainObject4.default)(v);
    },
    primitiveTypes: [...options?.primitiveTypes ?? [], import_mongodb.ObjectId]
  },
  depth
), "cleanObject");

// ../lib-backend/src/database/utils/cleanDocument/cleanDocument.ts
var import_isArray2 = __toESM(require("lodash/isArray"));
var import_isEqual = __toESM(require("lodash/isEqual"));
var import_isPlainObject = __toESM(require("lodash/isPlainObject"));
var import_isString = __toESM(require("lodash/isString"));
var import_last = __toESM(require("lodash/last"));
var import_reduce = __toESM(require("lodash/reduce"));
var import_mongodb2 = require("mongodb");
var resolveObjectId = /* @__PURE__ */ __name((value) => (0, import_isString.default)(value) ? new import_mongodb2.ObjectId(value) : (0, import_isPlainObject.default)(value) ? (0, import_reduce.default)(value, (result, v, k) => ({ ...result, [k]: resolveObjectId(v) }), {}) : value, "resolveObjectId");
var cleanDocument = /* @__PURE__ */ __name((value) => cleanObject2(value, {
  keyValueTransformer: (v, k, depth) => {
    let vF = v;
    if (vF.entity) {
      vF = vF.entity;
    }
    return depth === 0 && (0, import_isPlainObject.default)(vF) && (0, import_isEqual.default)(Object.keys(vF), ["_id"]) ? resolveObjectId(vF._id) : (0, import_isString.default)(vF) && (0, import_last.default)(k.split("."))?.startsWith("_") ? (0, import_isArray2.default)(vF) ? vF.map(resolveObjectId) : new import_mongodb2.ObjectId(vF) : vF;
  }
}), "cleanDocument");

// ../lib-backend/src/database/utils/getConnection/getConnection.ts
var import_graphql_relay = require("graphql-relay");
var getConnection = /* @__PURE__ */ __name(async ({
  count,
  getMany,
  input = {},
  pagination = {}
}) => {
  const { after, before, first, last: last3 } = pagination;
  const beforeOffset = (0, import_graphql_relay.getOffsetWithDefault)(before, count);
  const afterOffset = (0, import_graphql_relay.getOffsetWithDefault)(after, -1);
  let startOffset = Math.max(-1, afterOffset) + 1;
  let endOffset = Math.min(beforeOffset, count);
  first && (endOffset = Math.min(endOffset, startOffset + first));
  last3 && (startOffset = Math.max(startOffset, endOffset - last3));
  const skip = Math.max(startOffset, 0);
  const take = Math.max(endOffset - startOffset, 1);
  const { result, root } = await getMany({ ...input, options: { skip, take } });
  if (result && result.length) {
    const edges = result.map((node, index) => ({
      cursor: (0, import_graphql_relay.offsetToCursor)(startOffset + index),
      node
    }));
    const { 0: firstEdge, length, [length - 1]: lastEdge } = edges;
    const lowerBound = after ? afterOffset + 1 : 0;
    const upperBound = before ? Math.min(beforeOffset, count) : count;
    const pageInfo = {
      endCursor: lastEdge.cursor,
      hasNextPage: first ? endOffset < upperBound : false,
      hasPreviousPage: last3 ? startOffset > lowerBound : false,
      startCursor: firstEdge.cursor
    };
    return { result: { edges, pageInfo }, root };
  }
  return {
    result: {
      edges: [],
      pageInfo: { endCursor: "", hasNextPage: false, hasPreviousPage: false, startCursor: "" }
    },
    root
  };
}, "getConnection");

// ../lib-shared/src/core/utils/slug/slug.ts
var slug = /* @__PURE__ */ __name((params) => params.normalize("NFKD").replace(/(.+)([A-Z])/g, "$1-$2").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^(\w|?)-]+/g, "").replace(/_/g, "-").replace(/--+/g, "-").replace(/-$/g, ""), "slug");

// ../lib-frontend/src/route/utils/trimPathname/trimPathname.ts
var import_trim = __toESM(require("lodash/trim"));
var trimPathname = /* @__PURE__ */ __name((value) => {
  const pathname = filterNil(value.split("/")).map((char) => (0, import_trim.default)(char, "/").replace(/\w\S*/g, slug)).join("/");
  return `/${(0, import_trim.default)(pathname, "/")}`;
}, "trimPathname");

// ../lib-shared/src/http/utils/uri/uri.ts
var uri = /* @__PURE__ */ __name(({
  host = "",
  isProtocol = true,
  params,
  pathname,
  port
}) => {
  let uri2 = `${host}${port ? `:${port}` : ""}${pathname ? trimPathname(pathname) : ""}`;
  if (params) {
    const queryParams = Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
    uri2 = `${uri2}?${queryParams}`;
  }
  !isProtocol && ([, uri2] = uri2.split("://"));
  return uri2;
}, "uri");

// ../lib-shared/src/http/http.constants.ts
var HTTP_STATUS_CODE = {
  BAD_REQUEST: 400,
  CONFLICT: 409,
  FORBIDDEN: 403,
  GATEWAY_TIMEOUT: 504,
  INTERNAL_SERVER_ERROR: 500,
  NETWORK_CONNECT_TIMEOUT: 599,
  SERVICE_UNAVAILABLE: 503,
  SUCCESS: 200,
  UNAUTHORIZED: 401
};
var APP_URI = uri({ host: process.env.APP_HOST, port: process.env.APP_PORT });
var SERVER_APP_URI = uri({
  host: process.env.SERVER_APP_HOST,
  port: process.env.SERVER_APP_PORT
});

// ../lib-shared/src/http/errors/HttpError/HttpError.ts
var HttpError = class _HttpError extends Error {
  static {
    __name(this, "HttpError");
  }
  statusCode;
  constructor(statusCode, message, stack) {
    super();
    Object.setPrototypeOf(this, _HttpError.prototype);
    this.statusCode = statusCode ?? HTTP_STATUS_CODE.INTERNAL_SERVER_ERROR;
    this.message = message ?? "HttpError";
    this.stack = stack;
  }
};

// ../lib-shared/src/core/errors/DuplicateError/DuplicateError.ts
var DuplicateError = class extends HttpError {
  static {
    __name(this, "DuplicateError");
  }
  constructor(message) {
    super(HTTP_STATUS_CODE.CONFLICT, message);
  }
};

// ../lib-shared/src/core/errors/UninitializedError/UninitializedError.ts
var UninitializedError = class extends Error {
  static {
    __name(this, "UninitializedError");
  }
  constructor(value) {
    super(`not initialized: ${value}`);
  }
};

// ../lib-shared/src/logging/utils/logger/logger.ts
var import_isArray3 = __toESM(require("lodash/isArray"));
var import_isPlainObject2 = __toESM(require("lodash/isPlainObject"));

// ../lib-shared/src/core/utils/stringify/stringify.ts
var import_isString2 = __toESM(require("lodash/isString"));

// ../lib-shared/src/core/utils/stringify/_stringify.ts
var import_json_stringify_safe = __toESM(require("json-stringify-safe"));
var _stringify = /* @__PURE__ */ __name((...[params, options]) => options?.isMinify ?? true ? (0, import_json_stringify_safe.default)(params) : (0, import_json_stringify_safe.default)(params, null, "  "), "_stringify");

// ../lib-shared/src/core/utils/stringify/stringify.ts
var stringify2 = /* @__PURE__ */ __name((...[params, options]) => (0, import_isString2.default)(params) ? params : params ? _stringify(params, options) : "undefined", "stringify");

// ../lib-shared/src/data/utils/dateTimeFormat/_dateTimeFormat.ts
var import_date_fns = require("date-fns");
var _dateTimeFormat = /* @__PURE__ */ __name((...[value, format2 = "M/d/yyyy" /* DATE */]) => value && (0, import_date_fns.format)(value, format2), "_dateTimeFormat");

// ../lib-shared/src/data/utils/dateTimeFormat/dateTimeFormat.ts
var dateTimeFormat = /* @__PURE__ */ __name((...[value, format2]) => _dateTimeFormat(value, format2), "dateTimeFormat");

// ../lib-shared/src/logging/utils/logger/_logger.node.ts
var import_winston = require("winston");
var enumerateErrorFormat = (0, import_winston.format)((info3) => {
  if (info3 instanceof Error) {
    Object.assign(info3, { message: info3.stack });
  }
  return info3;
});
var logger = (0, import_winston.createLogger)({
  format: import_winston.format.combine(
    enumerateErrorFormat(),
    import_winston.format.colorize(),
    import_winston.format.splat(),
    import_winston.format.printf(
      ({ level, message }) => `[${dateTimeFormat(/* @__PURE__ */ new Date(), "M/d/yy HH:mm:ss" /* DATE_TIME_SECONDS_SHORT */)}] ${level}: ${message}`
    )
  ),
  level: process.env.NODE_ENV === "development" ? "debug" : "info",
  transports: [new import_winston.transports.Console({ stderrLevels: ["error"] })]
});
var { debug, error, info, warn } = {
  debug: (message) => logger.debug.bind(logger)(message),
  error: (message) => logger.error.bind(logger)(message),
  info: (message) => logger.info.bind(logger)(message),
  warn: (message) => logger.warn.bind(logger)(message)
};

// ../lib-shared/src/logging/utils/logger/logger.ts
var stringifyF = /* @__PURE__ */ __name((params) => params.map(
  (value) => (0, import_isPlainObject2.default)(value) ? stringify2(value) : (0, import_isArray3.default)(value) ? value.map((v) => stringifyF([v])) : value
).join(" "), "stringifyF");
var { debug: debug2, error: error2, info: info2, warn: warn2 } = {
  debug: (...params) => debug(stringifyF(params)),
  error: (...params) => error(stringifyF(params)),
  info: (...params) => info(stringifyF(params)),
  warn: (...params) => warn(stringifyF(params))
};

// ../lib-backend/src/database/utils/Database/_Database.ts
var import_core = require("@mikro-orm/core");
var import_isString3 = __toESM(require("lodash/isString"));
var import_last2 = __toESM(require("lodash/last"));
var import_mongodb3 = require("mongodb");
var getFilter = /* @__PURE__ */ __name((filters, prefix) => filters ? filters.reduce((result, v) => {
  const conditionF = v.condition ?? "$eq" /* EQUAL */;
  return {
    ...result,
    [prefix ? `${prefix}.${v.field}` : v.field]: [
      "$contains" /* CONTAINS */,
      "$notcontains" /* NOT_CONTAINS */
    ].includes(conditionF) ? {
      $options: "i",
      $regex: conditionF === "$contains" /* CONTAINS */ ? `${v.value}` : `^((?!${v.value}).)*$`
    } : {
      [conditionF]: (0, import_last2.default)(v.field.split("."))?.startsWith("_") && (0, import_isString3.default)(v.value) ? new import_mongodb3.ObjectId(v.value) : v.value
    }
  };
}, {}) : {}, "getFilter");
var _Database = class {
  static {
    __name(this, "_Database");
  }
  _config;
  _entityManager;
  constructor(config) {
    this._config = config;
  }
  async flush() {
    const em = this._getEntityManager();
    await em.flush();
  }
  async isConnected() {
    return this._entityManager?.getConnection().isConnected() ?? false;
  }
  async connect() {
    if (await this.isConnected()) {
      info2("reusing connection", this._config.clientUrl);
    } else {
      info2("connecting", this._config.clientUrl);
      this._entityManager = (await import_core.MikroORM.init(this._config)).em;
    }
  }
  _getEntityManager = () => {
    const em = this._entityManager;
    if (em) {
      return em.fork();
    }
    throw new UninitializedError("database");
  };
  getRepository = ({
    name
  }) => {
    const implementation = {
      clear: async () => {
        await this._getEntityManager().getRepository(name).nativeDelete({});
      },
      count: async () => this._getEntityManager().getRepository(name).count(),
      create: async ({ form, options } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = cleanDocument(form);
          const result = em.create(name, formF);
          !options?.isCommitted && await em.persistAndFlush(result);
          return { result };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      createMany: async ({ form } = {}) => {
        try {
          const em = this._getEntityManager();
          const formF = form?.map(cleanDocument);
          const result = await em.insertMany(name, formF);
          return { result };
        } catch (e) {
          switch (e.code) {
            case 11e3:
              throw new DuplicateError(name);
            default:
              throw e;
          }
        }
      },
      get: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const collection = em.getCollection(name);
        const result = await (options?.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? filterNil([
            options.project && { $project: options.project },
            ...options.aggregate ?? []
          ]) : []
        ]).next() : collection.findOne(
          filterF,
          options && { projection: options.project }
        ));
        return { result: result ?? void 0 };
      },
      getConnection: async ({ filter, pagination } = {}) => {
        const { result } = await getConnection({
          count: await implementation.count(),
          getMany: implementation.getMany,
          input: { filter },
          pagination
        });
        return { result: result ?? void 0 };
      },
      getMany: async ({ filter, options } = {}) => {
        const em = this._getEntityManager();
        const collection = em.getCollection(name);
        const filterF = cleanDocument(getFilter(filter));
        const result = await (options && options.aggregate ? collection.aggregate([
          { $match: filterF },
          ...options ? [
            options.project && { $project: options.project },
            options.take && { $limit: options.take + (options.skip ?? 0) },
            options.skip && { $skip: options.skip },
            ...options.aggregate ?? []
          ] : []
        ]).toArray() : collection.find(
          filterF,
          options && { limit: options.take, projection: options.project, skip: options.skip }
        ).toArray());
        return { result: result ?? void 0 };
      },
      remove: async ({ filter } = {}) => {
        const em = this._getEntityManager();
        const filterF = getFilter(filter);
        const entity = await implementation.get({ filter });
        await em.getRepository(name).nativeDelete(filterF);
        return entity;
      },
      update: async ({ filter, options, update } = {}) => {
        const em = this._getEntityManager();
        const filterF = cleanDocument(getFilter(filter));
        const updateF = cleanDocument(update);
        updateF && Object.keys(updateF).forEach((key) => {
          const keyF = key;
          if (!key.startsWith("$")) {
            updateF["$set"] = {
              ...updateF["$set"] ?? {},
              [key]: updateF[keyF]
            };
            delete updateF[keyF];
          }
        });
        const { value: result } = await em.getConnection().getCollection(name).findOneAndUpdate(filterF, updateF, {
          projection: options?.project,
          returnDocument: "after",
          upsert: true
        });
        return { result };
      }
    };
    return implementation;
  };
  close = async () => {
    debug2("closing connections", this._config.clientUrl);
    if (await this.isConnected()) {
      await this._getEntityManager().getConnection()?.close();
    }
  };
};

// ../lib-backend/src/database/utils/Database/Database.ts
var Database = class extends _Database {
  static {
    __name(this, "Database");
  }
};

// ../lib-backend/src/setup/utils/initialize/initialize.ts
var initialize = /* @__PURE__ */ __name(async ({ config }) => {
  const result = {};
  if (config) {
    const database = new Database(config);
    await database.connect();
    _Container.set(Database, database, "mongo" /* MONGO */);
    result.database = database;
  }
  return result;
}, "initialize");

// ../lib-backend/src/serverless/utils/createLambdaHandler/_createLambdaHandler.ts
var _createLambdaHandler = /* @__PURE__ */ __name(({
  context: contextDefault = {},
  databaseConfig,
  graphQlConfig,
  handler,
  plugins,
  type,
  websocketUri
}) => {
  const getContext = /* @__PURE__ */ __name(async ({
    context,
    event
  }) => {
    const contextF = { ...contextDefault, ...context };
    contextF.callbackWaitsForEmptyEventLoop = false;
    contextF.pathname = event.requestContext.routeKey;
    if (plugins?.includes("authentication" /* AUTHENTICATION */)) {
      const eventF = event;
      const authorization = eventF.headers?.authorization ?? eventF.queryStringParameters?.Authorization;
      const user = await getUserFromHeader(authorization);
      user && (contextF.user = user);
      eventF.headers?.group && (contextF.group = eventF.headers.group);
    }
    if (databaseConfig && !contextF.database) {
      const { database } = await initialize({ config: databaseConfig() });
      database && (contextDefault.database = database);
    }
    contextF.requestId = type === "websocket" /* WEBSOCKET */ ? event.requestContext.connectionId : contextF.requestId;
    return contextF;
  }, "getContext");
  return async (event, context, callback) => {
    if (type === "graphql" /* GRAPHQL */ && graphQlConfig) {
      const server = new import_server.ApolloServer({
        allowBatchedHttpRequests: true,
        formatError: (e, originalError) => {
          const originalErrorF = originalError?.originalError;
          const errorF = new HttpError(
            originalErrorF?.statusCode,
            e.message ?? originalErrorF?.message,
            e.extensions?.stacktrace ?? e?.stack ?? originalErrorF.stack
          );
          console.error(e);
          console.error(errorF);
          return errorF;
        },
        schema: graphQlConfig()
      });
      const handlerF = (0, import_aws_lambda.startServerAndCreateLambdaHandler)(
        server,
        import_aws_lambda.handlers.createAPIGatewayProxyEventV2RequestHandler(),
        {
          context: async ({ context: context2, event: event2 }) => getContext({ context: context2, event: event2 })
        }
      );
      return handlerF(event, context, callback);
    }
    const contextF = await getContext({ context, event });
    const result = {
      statusCode: HTTP_STATUS_CODE.SUCCESS,
      ...handler && await handler({ body: event.body, context: contextF })
    };
    switch (type) {
      case "websocket" /* WEBSOCKET */: {
        if (contextF.pathname === "$default" && result.requestId && result.body) {
          const api = new import_client_apigatewaymanagementapi.ApiGatewayManagementApiClient({ endpoint: websocketUri });
          const command = new import_client_apigatewaymanagementapi.PostToConnectionCommand({
            ConnectionId: result.requestId,
            Data: Buffer.from(result.body)
          });
          await api.send(command);
          return { statusCode: HTTP_STATUS_CODE.SUCCESS };
        }
        return result;
      }
      default: {
        result.body && (result.body = stringify2(result.body));
        return result;
      }
    }
  };
}, "_createLambdaHandler");

// ../lib-backend/src/serverless/utils/createLambdaHandler/createLambdaHandler.ts
var createLambdaHandler = /* @__PURE__ */ __name(({
  ...params
}) => _createLambdaHandler({
  ...params,
  websocketUri: uri({
    host: process.env.SERVER_APP_HOST,
    port: process.env.SERVER_APP_WEBSOCKET_PORT
  })
}), "createLambdaHandler");

// ../lib-backend/src/serverless/utils/ping/ping.ts
var ping = createLambdaHandler({
  handler: async ({ context }) => {
    const { requestId, user } = context;
    return {
      body: {
        message: "success",
        requestId,
        user: user?.claims.email
      },
      headers: { "Access-Control-Allow-Origin": "*" },
      statusCode: HTTP_STATUS_CODE.SUCCESS
    };
  },
  plugins: ["authentication" /* AUTHENTICATION */]
});

// src/functions/ping/ping.ts
var main = ping;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=ping.js.map
